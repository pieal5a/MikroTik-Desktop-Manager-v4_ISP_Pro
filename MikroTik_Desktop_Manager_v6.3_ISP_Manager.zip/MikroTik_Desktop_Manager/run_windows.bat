@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements-optional.txt >nul 2>nul
py -3 src\mikrotik_manager.py
if errorlevel 1 pause
