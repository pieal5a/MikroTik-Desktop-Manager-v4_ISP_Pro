@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python launcher not found. Install Python 3.11+ from python.org and enable PATH.
  pause
  exit /b 1
)
py -3 -m pip install --upgrade pip
py -3 -m pip install pyinstaller pillow paramiko
py -3 -m pip install opencv-python
if errorlevel 1 (
  echo Failed to install PyInstaller.
  pause
  exit /b 1
)
py -3 -m PyInstaller --noconfirm --clean --onefile --windowed --name MikroTikDesktopManager --paths src --hidden-import cv2 --hidden-import PIL.ImageTk --hidden-import paramiko src\mikrotik_manager.py
if errorlevel 1 (
  echo EXE build failed.
  pause
  exit /b 1
)
echo.
echo Build complete: dist\MikroTikDesktopManager.exe
pause
