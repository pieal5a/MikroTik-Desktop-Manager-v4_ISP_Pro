# MikroTik Desktop Manager v6.3 ISP Pro

## v6.3 — NOC Command Center
সাইডবারের **Command Center**: ISP-র পুরো অবস্থা এক স্ক্রিনে।
* **Health ring (A+ … F)** — ৬টি লাইভ উপাদান থেকে স্কোর: router availability, load, subscribers online, collection pace, arrears, support load; **SYSTEM NOMINAL / DEGRADED / CRITICAL** স্ট্যাটাস।
* **Animated radar** — প্রতিটি রাউটার/ডিভাইস একটি blip (সবুজ ঠিক • কমলা হাই লোড • লাল ডাউন, পালস করে); blip-এ ক্লিক করলে CPU/RAM/uptime/users।
* **KPI কার্ড** (ক্লিক করলে সংশ্লিষ্ট পেজ): Online now, Collected, Net profit, Total due, Open tickets, Active incidents।
* **Live incident feed, Zone heat (জোনভিত্তিক অনলাইন %), 24h online trend, Smart advisor, স্ক্রলিং ticker।**
* **Wall mode** (ফুলস্ক্রিন, Esc দিয়ে বের) ও নতুন ক্রিটিক্যাল ইনসিডেন্টে সাউন্ড (ঐচ্ছিক)।

---

## v6.2 — Graphical Monitor (live traffic)
**Graphical Monitor** এখন যেকোনো রাউটারের যেকোনো Interface বা PPPoE Client-এর লাইভ ট্রাফিক গ্রাফ দেখায়।
* **＋ Add graph** — রাউটার, Interface/Client, টাইটেল, সময়ের উইন্ডো (1 মিনিট–1 ঘণ্টা), fixed max Mbps বেছে নিন; **✎ Edit**, **✕ Remove**, Duplicate, Move (গ্রাফে রাইট-ক্লিক)।
* **＋ All interfaces of router** — এক ক্লিকে রাউটারের সব Interface-এর গ্রাফ; **＋ Top clients** — সবচেয়ে বেশি স্পিডের ক্লায়েন্ট।
* **All interfaces (table)** — সব Interface ও Client-এর লাইভ স্পিড টেবিল; ডাবল-ক্লিকে গ্রাফ যোগ।
* Columns 1–4, Refresh 1–10 সেকেন্ড, Pause/Resume; গ্রাফ সেটিংস settings.json-এ সেভ থাকে। API / SSH / Telnet / SNMP সব প্রোটোকলে চলে।

---

## v6.1 — auto-sync totals & smart features
| Feature | বিবরণ |
|---|---|
| **Network Totals & Insights** (নতুন পেজ) | সব রাউটার/ডিভাইস থেকে অটো-আপডেট: মোট ক্লায়েন্ট, অনলাইন, অফলাইন, সাসপেন্ড, মাসিক রেভিনিউ, মোট DUE, রাউটারভিত্তিক টেবিল, ২৪ ঘণ্টার অনলাইন চার্ট |
| **Auto packages & bills** | রাউটারের PPP profile থেকে প্যাকেজ (speed সহ) অটো তৈরি; প্যাকেজে দাম বসালেই bill=0 ক্লায়েন্টদের বিল অটো ভরে; নতুন ইমপোর্ট হওয়া ক্লায়েন্টের বিল সাথে সাথে জেনারেট |
| **Area outage detection** | কোনো জোন/রাউটারে একসাথে ৬০%+ ক্লায়েন্ট অফলাইন হলে Alert + Telegram, ফিরে এলে Restored মেসেজ |
| **Smart insights** | কালেকশন ফোরকাস্ট, peak hour, নিয়মিত দেরিতে পেমেন্টকারী ক্লায়েন্ট, ডেটা সমস্যার সারসংক্ষেপ |
| Router stats history | প্রতি সিঙ্কে secrets / active / disabled / CPU / RAM সংরক্ষণ |

---

## What is new in v6.0 (বাংলা সারসংক্ষেপ সহ)
| Feature | বিবরণ |
|---|---|
| **Bandwidth Usage** | প্রতিটি PPPoE ক্লায়েন্টের দৈনিক/মাসিক Download-Upload (PPPoE interface counter, API/SSH/Telnet/SNMP), ⚡ ৮-সেকেন্ড Live sample, ক্লায়েন্ট চার্ট, CSV |
| **Analytics & Aging** | Collection efficiency, ARPU, নতুন/বন্ধ ক্লায়েন্ট, বকেয়ার বয়স (current/1/2/3+ মাস), জোনভিত্তিক বকেয়া, ১২ মাসের ট্রেন্ড, প্রিন্ট |
| **Cash Book & Collectors** | কালেক্টর ও মেথডভিত্তিক কালেকশন, ক্যাশ হ্যান্ডওভার (কার কাছে কত জমা বাকি), প্রিন্ট |
| **Inventory** | ONU/Router/Cable স্টক, ক্লায়েন্টকে assign, faulty, স্টক ভ্যালু |
| **Router & Data Audit** | রাউটারে নেই, Package ≠ PPP profile, বকেয়া কিন্তু active, পরিশোধিত কিন্তু suspended, ডুপ্লিকেট ID/ফোন, ফোন/NID নেই, ৩০+ দিন অফলাইন — এক-ক্লিকে Push/Suspend/Enable |
| **Client Extras** | ONU MAC, OLT port, ম্যাপ, নিজস্ব due-day, grace days, exempt (auto-suspend হবে না), installation/ONU বিক্রি/reconnection one-time charge |
| **Automation** | নির্দিষ্ট তারিখে অটো due-reminder SMS; বকেয়া মিটলে অটো re-enable (ডিফল্ট OFF) |
| **Security & PIN** | স্টার্টআপে PIN, Ctrl+L লক, idle auto-lock |

New files: `db_plus.py`, `isp_plus.py`, `lockscreen.py`. Old databases upgrade automatically.

---
# MikroTik Desktop Manager v5.0 ISP Pro
**MikroTik Manager by Arafath Rahman (Pieal) — CEO & CTO, CloudCore Network — www.ccn.isp-bd.com**

RouterOS manager + ISP client & billing system (Python + Tkinter, standard library only; a few optional packages add
camera / JPG preview / SSH-password login).

## What is new in v5.0 (বাংলা সারসংক্ষেপ সহ)
| Feature | বিবরণ |
|---|---|
| **ISP Overview** (নতুন প্রথম পেজ) | এই মাসের কালেকশন / খরচ / নিট লাভ / মোট DUE / খোলা টিকেট, **১২ মাসের চার্ট** (collected vs billed vs expenses), Top-10 DUE ক্লায়েন্ট (ডাবল-ক্লিকে পেমেন্ট), সব রাউটারের হেলথ (CPU/RAM/online), প্যাকেজ ও জোন ভিত্তিক হিসাব |
| **Expenses & Profit** | বিদ্যুৎ, বেতন, ব্যান্ডউইথ, ভাড়া ইত্যাদি খরচ এন্ট্রি, ক্যাটাগরি টোটাল, মাসিক **Profit & Loss রিপোর্ট** (প্রিন্ট), CSV |
| **Support Tickets** | ক্লায়েন্ট অনুযায়ী অভিযোগ / নতুন সংযোগ, priority, status (Open → Resolved), assigned, সমাধান নোট |
| **Multi-month / Advance payment** | একসাথে কয়েক মাসের টাকা নিলে পুরনো DUE আগে মিটবে, বাকিটা পরের মাসগুলোতে **advance** হিসেবে বসবে (preview সহ) |
| **Bulk package change** | একাধিক ক্লায়েন্টের প্যাকেজ + বিল বদলানো এবং রাউটারে PPP profile পুশ |
| **Account statement** | ক্লায়েন্টের সব বিল/পেমেন্টের প্রিন্টযোগ্য স্টেটমেন্ট |
| **Bulk due reminder** | বকেয়াদের সবাইকে **SMS gateway** দিয়ে একসাথে, **WhatsApp** এক-ক্লিকে একজন করে, অথবা Telegram-এ তালিকা |
| **Automation & Alerts** | Telegram bot: রাউটার DOWN / back-online অ্যালার্ট + দৈনিক কালেকশন সামারি; পেমেন্ট পেলে ক্লায়েন্টকে SMS; যেকোনো HTTP SMS gateway (`{phone}` `{text}` URL টেমপ্লেট); মেসেজ লগ |
| **Auto backup** | প্রতিদিন একটি `backups/isp-auto-YYYYMMDD.db`, সর্বশেষ N টি রাখে (ডিফল্ট ১৪) |

SMS URL উদাহরণ: `https://your-gateway/api?api_key=KEY&senderid=ID&number={phone}&message={text}` — Telegram: @BotFather থেকে token, chat id বসান।
নতুন ফাইল: `isp_extra.py` (Overview / Expenses / Tickets / Multi-pay / Statement), `isp_notify.py` (Telegram, SMS, Bulk reminder, Automation page)।

---

## দ্রুত শুরু (Quick start, বাংলা)
1. `run_windows.bat` চালান (Python 3.11+ লাগবে)।
2. **Router Sync → ＋ Add Device** — Protocol বেছে নিন: API 8728 / API-SSL 8729 / SSH 22 / Telnet 23 / SNMP 161। *Test connection* চাপুন, *Save password* টিক দিন (অটো-সিঙ্কের জন্য), Save।
3. একাধিক রাউটার যোগ করুন → **Sync All**। PPPoE secret গুলো আপনাআপনি **Clients** এ ঢুকে যাবে (নতুন = import), online/offline, IP, uptime আপডেট হবে।
4. **Clients → ＋ Add Client**: PPPoE ID/Password, Package, Bill, Name, Phone 1/2, NID, Photo/NID (Upload বা Camera), এবং *Billing & Due* ট্যাবে **Month drop-down** থেকে মাস বেছে বিল/পেইড/DUE দেখে পেমেন্ট নিন।
5. **Billing**: মাসের সব বিল, Due list, Collection report, রিসিট প্রিন্ট। **Packages**: প্যাকেজ ও দাম।

## What is new in v4.0
| Area | Features |
|---|---|
| **Multi-device, multi-protocol** | Any number of routers. Per device choose **API (8728)**, **API-SSL (8729)**, **SSH (22)**, **Telnet (23)** or **SNMP v1/v2c (161)**. Optional SNMP "companion" on API/SSH/Telnet devices adds temperature / voltage. Background **auto-sync** (1-60 min) + Sync Selected / Sync All, state / CPU / RAM / uptime / PPPoE counts / interface counters per device, failure + recovery alerts in the bell. |
| **What each protocol can do** | API / SSH / Telnet: health, interfaces, PPP active **and** PPP secrets (import clients, push / edit / suspend / enable / delete). SNMP: health, interface traffic, temperature and the online PPPoE users (`<pppoe-user>` interfaces) — read-only, cannot read secrets. |
| **Clients** | PPPoE ID, password, package, bill, name, phone 1 & 2, NID, address, zone, join date, status, note. Add / edit / remove, search, filter (router, package, zone, status, online/offline, due, paid, not-on-router), CSV import/export, right-click menu, show/hide passwords. **Client photo, NID front/back, other document: upload or camera.** |
| **Router ↔ client actions** | Push client to router (create/update secret), Pull from router, Suspend / Enable (disables the secret and drops the session), delete on router too, "re-enable after payment" prompt, optional **auto-suspend overdue** (OFF by default). |
| **Billing** | Monthly bills (auto-generated), **month drop-down → bill / paid / DUE**, partial payments, discount, method (Cash / bKash / Nagad / Rocket / Bank / Card), TrxID, payment history, delete payment, **printable receipt** (browser → Print / PDF), due list, collection report, per-day / per-method / per-router totals, WhatsApp due-reminder (editable Bangla template). |
| **Packages** | Name, speed, price, PPP profile; import profiles from a router; apply price to all clients of a package. |
| **Data** | SQLite database (`%APPDATA%\MikroTikDesktopManager\isp.db`), one-click **backup / restore**, audit log of every change, documents in `files/<client id>/`. |

## Security notes (please read)
* Router passwords are saved **only if you tick "Save password"** and are protected with **Windows DPAPI** (decryptable only by the same Windows user on the same PC). On non-Windows systems they are only base64-obfuscated.
* PPPoE client passwords are stored **in plain text inside `isp.db`** (you need to see/print them). Protect the PC / folder, and keep backups private. Device export (JSON) never includes router passwords.
* Create a dedicated RouterOS user for this app; allow API / SSH / SNMP only from your admin PC. Never expose these services to the internet.
* Auto-suspend is OFF by default; turn it on in *ISP Settings & Data* only after checking the due-day rule.

## Optional packages (`pip install -r requirements-optional.txt`)
`pillow` (JPG previews + camera preview), `opencv-python` (camera capture), `paramiko` (SSH with password; without it SSH uses the system `ssh` with key login).

## Test without a router
```
python tools\mock_router.py     # RouterOS API on 127.0.0.1:8728
python tools\mock_devices.py    # Telnet 127.0.0.1:2323 + SNMP 127.0.0.1:1161 (community "public")
```
Add three devices (API 8728, Telnet 2323, SNMP 1161 → host 127.0.0.1) and press **Sync All**.

## New source files (`src/`)
`snmp.py` SNMP client • `clitools.py` Telnet / SSH + terse parser • `transport.py` one interface for all protocols • `sync.py` multi-router auto-sync •
`db.py` SQLite • `secret.py` DPAPI • `isp_clients.py` / `isp_billing.py` / `isp_routers.py` / `isp_app.py` / `isp_common.py` ISP pages

---
# Previous module reference (v3 Pro)

Windows desktop app (Python + Tkinter, **no third-party packages**) that talks to RouterOS v6/v7 over the
RouterOS API (TCP 8728) or API-SSL (TCP 8729). 

## What's new in v3 Pro
| Area | What you get |
|---|---|
| **Look & feel** | Dark navy "digital" theme, gradient KPI cards, neon colours, rounded panels, colourful icon sidebar with active-item highlight |
| **Dashboard** | 6 live KPI cards with sparklines, Network Traffic (Live) area chart (5 min / 15 min / 1 h, per-interface), current speed + TX/RX donut, System Resources ring gauges (CPU / Memory / Disk / Uptime), Device List, BGP peers donut, PPPoE clients donut, Top-5 interface traffic, Recent Logs, Quick Tools, Topology mini-map |
| **WinBox module** | Full WinBox menu tree in the sidebar (Interfaces, Bridge, PPP, IP, IPv6, Firewall, Routing, BGP, Queues, Wireless + CAPsMAN, Switch, MPLS, RADIUS, System, Files, Logs, Tools — ~130 pages). **Shift+click / right-click → opens any page in its own floating WinBox window**; "WinBox mode" in Settings does this for every page; *WinBox Windows ▾* menu: Cascade / Tile / Close all |
| **Quick Connect** | WinBox-loader page: connect by IP without a profile, MNDP Layer-2 neighbour discovery, saved routers |
| **Devices** | Fleet list with TCP reachability probe (every 20 s), live CPU/RAM/uptime/TX-RX for the connected router, Scan Network (finds RouterOS API/WinBox ports in a CIDR), import/export profiles |
| **Graphical Monitor** | 7 live charts (total + busiest 6 interfaces) |
| **Topology Map** | This router + `/ip/neighbor` devices, click a device to add it |
| **Alerts & Notifications** | Bell badge; alerts for CPU ≥ 85 %, memory ≥ 90 %, link down, BGP not established, error/critical log lines; CSV export |
| **Reports** | HTML report (opens in browser) or CSV files of system, interfaces, IPs, routes, DHCP, PPP, queues, firewall, NAT, users, services, packages |
| **Quick Tools** | WinBox, Terminal, Torch, Bandwidth Test, Ping, Traceroute, DNS Lookup, IP Scan, Export Config, Backup, Restore, Reboot |
| **More tools** | IP Scan, CPU Profile, E-mail, Make Supout.rif, Restore backup |
| **Search** | Top bar search (Ctrl+/ or Ctrl+K): pages, devices, interfaces |
| **Extras** | F11 fullscreen, Auto-Refresh switch (pauses live monitoring), Settings page |

> When no router is connected the dashboard shows clearly-flagged **demo data** so you can preview the design
> (Settings → untick the first option to turn it off).

## Run
1. Install Python 3.11+ (tick *Add python.exe to PATH*; the standard installer includes Tkinter).
2. Double-click `run_windows.bat` (or `python src\mikrotik_manager.py`).
3. **＋** add a router → **Connect** → enter password.  (or use **Quick Connect**)

## Build EXE (on Windows)
Double-click `build_windows.bat` → `dist\MikroTikDesktopManager.exe`.

## Router side
- `/ip service enable api` (8728) or `api-ssl` (8729); restrict `address=` to your admin PC/subnet.
- Dedicated user; policies: `read, write, test, reboot, policy, sensitive, api`.
- Never expose the API port to the internet.

## Test without a router
`python tools\mock_router.py` starts a fake API server on 127.0.0.1:8728 (user `admin`, any password).

## Not possible through the RouterOS API (use real WinBox/SSH)
Winbox's proprietary protocol itself, MAC-Winbox / MAC-Telnet, Safe Mode, packet-sniffer streaming, file upload/download
(use SFTP/FTP), Quick Set wizards. "Reset Configuration" is deliberately left out. This app's WinBox module re-creates
the WinBox *menus and windows* on top of the API.

## Source layout (`src/`)
`mikrotik_manager.py` app shell, sidebar, WinBox windows, classic table/tool pages • `pro_pages.py` dashboard & new pages •
`ui_kit.py` canvas widgets • `services.py` telemetry / alerts / fleet / demo • `menu_spec.py` menu tree •
`routeros_api.py` API client • `mndp.py` discovery • `core.py` shared base
