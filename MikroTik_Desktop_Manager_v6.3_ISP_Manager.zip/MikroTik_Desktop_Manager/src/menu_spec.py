"""Winbox-style menu definition. Every entry maps to a RouterOS API menu path.
Menus that do not exist on the connected RouterOS version simply report an error when opened."""


def T(title, path, cols="", fields="", **kw):
    return dict(kind="table", title=title, path=path, cols=cols.split(), fields=fields.split(), **kw)


def S(title, path, **kw):
    return dict(kind="settings", title=title, path=path, **kw)


def fmt_ping(r):
    return (f"seq={r.get('seq', '')}  {r.get('host', '')}  size={r.get('size', '')}  "
            f"ttl={r.get('ttl', '')}  time={r.get('time', 'timeout')}  {r.get('status', '')}").rstrip()


def sum_ping(r):
    return (f"sent={r.get('sent', '?')} received={r.get('received', '?')} loss={r.get('packet-loss', '?')}%  "
            f"min/avg/max = {r.get('min-rtt', '?')}/{r.get('avg-rtt', '?')}/{r.get('max-rtt', '?')}")


FW = ("chain action protocol src-address dst-address src-port dst-port in-interface out-interface "
      "connection-state log comment")
FW_COLS = "chain action protocol src-address dst-address dst-port in-interface out-interface bytes packets comment"

MENU = [
    ("Dashboard", [dict(kind="dashboard", title="Dashboard")]),
    ("Interfaces", [
        T("Interfaces", "/interface", "name type mtu actual-mtu mac-address rx-byte tx-byte last-link-up-time comment",
          "name mtu comment", noadd=True),
        T("Ethernet", "/interface/ethernet", "name default-name mtu mac-address speed auto-negotiation arp comment",
          "name mtu arp comment", noadd=True, nodel=True),
        T("Bridge", "/interface/bridge", "name mtu protocol-mode vlan-filtering mac-address comment",
          "name protocol-mode vlan-filtering mtu comment"),
        T("Bridge Ports", "/interface/bridge/port", "interface bridge pvid edge path-cost hw comment",
          "interface bridge pvid comment"),
        T("Bridge VLANs", "/interface/bridge/vlan", "bridge vlan-ids tagged untagged current-tagged current-untagged",
          "bridge vlan-ids tagged untagged"),
        T("VLAN", "/interface/vlan", "name vlan-id interface mtu comment", "name vlan-id interface mtu comment"),
        T("Bonding", "/interface/bonding", "name mode slaves mtu comment", "name mode slaves mtu comment"),
        T("Interface Lists", "/interface/list", "name include exclude comment", "name comment"),
        T("List Members", "/interface/list/member", "list interface", "list interface"),
        T("WireGuard", "/interface/wireguard", "name listen-port mtu public-key comment", "name listen-port mtu comment"),
        T("WireGuard Peers", "/interface/wireguard/peers",
          "interface public-key allowed-address endpoint-address endpoint-port persistent-keepalive comment",
          "interface public-key allowed-address endpoint-address endpoint-port persistent-keepalive comment"),
        T("PPPoE Client", "/interface/pppoe-client", "name interface user service-name running comment",
          "name interface user password service-name add-default-route use-peer-dns comment"),
        T("PPPoE Server", "/interface/pppoe-server/server", "service-name interface default-profile authentication",
          "service-name interface default-profile authentication"),
        T("L2TP Client", "/interface/l2tp-client", "name connect-to user running comment",
          "name connect-to user password use-ipsec comment"),
        T("SSTP Client", "/interface/sstp-client", "name connect-to user running comment",
          "name connect-to user password comment"),
        T("OpenVPN Client", "/interface/ovpn-client", "name connect-to user running comment",
          "name connect-to user password comment"),
        T("GRE Tunnel", "/interface/gre", "name local-address remote-address running comment",
          "name local-address remote-address comment"),
        T("EoIP Tunnel", "/interface/eoip", "name local-address remote-address tunnel-id running comment",
          "name local-address remote-address tunnel-id comment"),
        T("Wireless (v6)", "/interface/wireless", "name ssid mode band frequency security-profile running comment",
          "name ssid mode band frequency security-profile comment"),
        T("Wireless Clients (v6)", "/interface/wireless/registration-table",
          "interface mac-address signal-strength tx-rate rx-rate uptime", ro=True),
        T("Wireless Security", "/interface/wireless/security-profile", "name mode authentication-types",
          "name mode authentication-types wpa2-pre-shared-key"),
        T("WiFi (v7)", "/interface/wifi", "name configuration.ssid channel.band running comment",
          "name configuration.ssid comment"),
        T("WiFi Clients (v7)", "/interface/wifi/registration-table", "interface mac-address signal uptime", ro=True),
    ]),
    ("IP", [
        T("Addresses", "/ip/address", "address network interface comment", "address interface comment"),
        T("Routes", "/ip/route", "dst-address gateway distance routing-table scope pref-src comment",
          "dst-address gateway distance routing-table comment"),
        T("ARP", "/ip/arp", "address mac-address interface comment", "address mac-address interface comment"),
        T("Pool", "/ip/pool", "name ranges next-pool", "name ranges next-pool comment"),
        S("DNS", "/ip/dns"),
        T("DNS Static", "/ip/dns/static", "name address type ttl comment", "name address type ttl comment"),
        T("DNS Cache", "/ip/dns/cache", "name type data ttl", ro=True),
        T("DHCP Client", "/ip/dhcp-client", "interface status address gateway dhcp-server",
          "interface use-peer-dns add-default-route comment"),
        T("DHCP Server", "/ip/dhcp-server", "name interface address-pool lease-time",
          "name interface address-pool lease-time"),
        T("DHCP Networks", "/ip/dhcp-server/network", "address gateway dns-server",
          "address gateway dns-server netmask comment"),
        T("DHCP Leases", "/ip/dhcp-server/lease", "address mac-address host-name server status expires-after comment",
          "address mac-address server comment", extra=[("Make Static", "make-static")]),
        T("Services", "/ip/service", "name port address certificate", "port address", noadd=True, nodel=True),
        T("Neighbors", "/ip/neighbor", "interface address mac-address identity platform version", ro=True),
        T("Hotspot", "/ip/hotspot", "name interface address-pool profile", "name interface address-pool profile"),
        T("Hotspot Users", "/ip/hotspot/user", "name profile limit-uptime limit-bytes-total comment",
          "name password profile limit-uptime limit-bytes-total comment"),
        T("Hotspot Active", "/ip/hotspot/active", "user address mac-address uptime bytes-in bytes-out",
          noadd=True, notoggle=True),
        T("IPsec Peers", "/ip/ipsec/peer", "name address exchange-mode", "name address exchange-mode"),
        T("IPsec Policies", "/ip/ipsec/policy", "src-address dst-address action", "src-address dst-address action"),
        T("IPsec Active", "/ip/ipsec/active-peers", "id remote-address state uptime", ro=True),
        S("Settings", "/ip/settings"),
        S("Cloud / DDNS", "/ip/cloud"),
        S("Proxy", "/ip/proxy"),
        S("SOCKS", "/ip/socks"),
        S("UPnP", "/ip/upnp"),
        S("Traffic Flow", "/ip/traffic-flow"),
    ]),
    ("IPv6", [
        T("Addresses", "/ipv6/address", "address interface advertise comment", "address interface advertise comment"),
        T("Routes", "/ipv6/route", "dst-address gateway distance comment", "dst-address gateway distance comment"),
        T("Neighbors", "/ipv6/neighbor", "address mac-address interface status", ro=True),
        T("Pool", "/ipv6/pool", "name prefix prefix-length", "name prefix prefix-length"),
        T("Firewall Filter", "/ipv6/firewall/filter", FW_COLS, FW, order=True),
        T("Address Lists", "/ipv6/firewall/address-list", "list address timeout comment", "list address timeout comment"),
    ]),
    ("Firewall", [
        T("Filter Rules", "/ip/firewall/filter", FW_COLS, FW, order=True),
        T("NAT", "/ip/firewall/nat", "chain action protocol src-address dst-address dst-port in-interface out-interface "
          "to-addresses to-ports bytes comment",
          "chain action protocol src-address dst-address src-port dst-port in-interface out-interface "
          "to-addresses to-ports comment", order=True),
        T("Mangle", "/ip/firewall/mangle", "chain action protocol src-address dst-address new-connection-mark "
          "new-packet-mark new-routing-mark bytes comment",
          "chain action protocol src-address dst-address in-interface out-interface connection-mark "
          "new-connection-mark new-packet-mark new-routing-mark passthrough comment", order=True),
        T("Raw", "/ip/firewall/raw", FW_COLS, FW, order=True),
        T("Address Lists", "/ip/firewall/address-list", "list address timeout creation-time comment",
          "list address timeout comment"),
        T("Connections", "/ip/firewall/connection", "protocol src-address dst-address tcp-state timeout orig-bytes repl-bytes",
          noadd=True, notoggle=True),
        T("Layer7 Protocols", "/ip/firewall/layer7-protocol", "name regexp", "name regexp comment"),
        T("Service Ports", "/ip/firewall/service-port", "name ports", "ports", noadd=True, nodel=True),
    ]),
    ("Routing", [
        T("Tables (v7)", "/routing/table", "name fib", "name fib comment"),
        T("BGP Connections (v7)", "/routing/bgp/connection",
          "name remote.address remote.as local.role templates output.redistribute comment",
          "name remote.address remote.as local.role templates output.redistribute comment"),
        T("BGP Sessions (v7)", "/routing/bgp/session", "name remote.address remote.as established uptime", ro=True),
        T("BGP Templates (v7)", "/routing/bgp/template", "name as router-id comment", "name as router-id comment"),
        T("BGP Peers (v6)", "/routing/bgp/peer", "name remote-address remote-as state prefix-count",
          "name remote-address remote-as instance comment"),
        T("OSPF Instances", "/routing/ospf/instance", "name router-id version", "name router-id version"),
        T("OSPF Areas", "/routing/ospf/area", "name area-id instance", "name area-id instance"),
        T("OSPF Interfaces (v7)", "/routing/ospf/interface-template", "area interfaces networks type cost",
          "area interfaces networks type cost"),
        T("OSPF Neighbors", "/routing/ospf/neighbor", "router-id address state adjacency", ro=True),
        T("Route Filters (v7)", "/routing/filter/rule", "chain rule comment", "chain rule comment", order=True),
        T("Routing Rules", "/routing/rule", "src-address dst-address action table", "src-address dst-address action table"),
    ]),
    ("PPP", [
        T("Secrets", "/ppp/secret", "name service profile local-address remote-address last-logged-out comment",
          "name password service profile local-address remote-address comment"),
        T("Profiles", "/ppp/profile", "name local-address remote-address rate-limit dns-server",
          "name local-address remote-address rate-limit dns-server comment"),
        T("Active Connections", "/ppp/active", "name service caller-id address uptime", noadd=True, notoggle=True),
    ]),
    ("Queues", [
        T("Simple Queues", "/queue/simple", "name target max-limit limit-at parent queue bytes comment",
          "name target max-limit limit-at parent queue priority comment", order=True),
        T("Queue Tree", "/queue/tree", "name parent packet-mark max-limit limit-at priority comment",
          "name parent packet-mark max-limit limit-at priority comment"),
        T("Queue Types", "/queue/type", "name kind", "name kind"),
    ]),
    ("System", [
        S("Resources", "/system/resource", ro=True),
        S("Identity", "/system/identity"),
        S("Clock", "/system/clock"),
        S("NTP Client", "/system/ntp/client"),
        S("NTP Server", "/system/ntp/server"),
        S("Health", "/system/health", ro=True),
        S("RouterBOARD", "/system/routerboard", ro=True),
        T("Packages", "/system/package", "name version build-time disabled scheduled", noadd=True, nodel=True),
        T("Users", "/user", "name group address last-logged-in comment", "name group password address comment"),
        T("User Groups", "/user/group", "name policy comment", "name policy comment"),
        T("Active Users", "/user/active", "when name address via group", ro=True),
        T("Scheduler", "/system/scheduler", "name start-date start-time interval on-event next-run run-count comment",
          "name start-date start-time interval on-event comment"),
        T("Scripts", "/system/script", "name owner last-started run-count policy comment",
          "name source policy comment", extra=[("Run", "run")]),
        T("Certificates", "/certificate", "name common-name issuer fingerprint days-valid", noadd=True, notoggle=True),
        T("Files", "/file", "name type size creation-time", noadd=True, notoggle=True),
        T("Logging", "/system/logging", "topics action prefix", "topics action prefix"),
        T("Log", "/log", "time topics message", ro=True),
        dict(kind="system", title="Backup / Reboot / Updates"),
        S("SNMP", "/snmp"),
        T("SNMP Communities", "/snmp/community", "name addresses read-access write-access",
          "name addresses read-access write-access"),
    ]),
    ("Tools", [
        dict(kind="terminal", title="Terminal (API)"),
        dict(kind="tool", title="Ping", path="/ping",
             fields=[("Address", "address", "8.8.8.8"), ("Count", "count", "10"), ("Interval", "interval", "1"),
                     ("Size", "size", "56")], fmt=fmt_ping, summary=sum_ping),
        dict(kind="tool", title="Traceroute", path="/tool/traceroute",
             fields=[("Address", "address", "8.8.8.8"), ("Count", "count", "3")]),
        dict(kind="tool", title="Torch", path="/tool/torch",
             fields=[("Interface", "interface", "ether1"), ("Src", "src-address", "0.0.0.0/0"),
                     ("Dst", "dst-address", "0.0.0.0/0"), ("Protocol", "protocol", "any"), ("Port", "port", "any")],
             cols="src-address dst-address protocol src-port dst-port tx rx",
             key=("src-address", "dst-address", "protocol", "src-port", "dst-port")),
        dict(kind="tool", title="Bandwidth Test", path="/tool/bandwidth-test",
             fields=[("Address", "address", ""), ("User", "user", "admin"), ("Password", "password", ""),
                     ("Direction", "direction", "both"), ("Protocol", "protocol", "tcp"), ("Duration", "duration", "10s")]),
        dict(kind="graph", title="Traffic Graph"),
        T("Netwatch", "/tool/netwatch", "host interval timeout status since up-script down-script",
          "host interval timeout up-script down-script comment"),
        dict(kind="mndp", title="Neighbor Discovery (L2)"),
        dict(kind="any", title="Any Menu (full API browser)"),
    ]),
]


# ======================================================================================
# v4: WinBox-style navigation tree (sidebar) built from the pages above + new pages
# ======================================================================================
_LOOKUP = {(g, s["title"]): s for g, items in MENU for s in items}


def pick(group, *titles):
    return [_LOOKUP[(group, t)] for t in titles]


SWITCH = [
    T("Switch Chips", "/interface/ethernet/switch", "name type l3-hw-offloading mirror-source mirror-target",
      "name l3-hw-offloading mirror-source mirror-target"),
    T("Switch Ports", "/interface/ethernet/switch/port", "name switch vlan-mode vlan-header default-vlan-id",
      "name vlan-mode vlan-header default-vlan-id"),
    T("Switch Hosts", "/interface/ethernet/switch/host", "mac-address ports vlan-id dynamic", ro=True),
    T("Switch VLANs", "/interface/ethernet/switch/vlan", "vlan-id ports switch learn", "vlan-id ports switch learn"),
    T("Switch Rules", "/interface/ethernet/switch/rule", "ports src-address dst-address new-dst-ports comment",
      "ports src-address dst-address new-dst-ports comment"),
]
WIRELESS = pick("Interfaces", "Wireless (v6)", "Wireless Clients (v6)", "Wireless Security", "WiFi (v7)",
                "WiFi Clients (v7)") + [
    T("Access List", "/interface/wireless/access-list", "mac-address interface authentication comment",
      "mac-address interface authentication comment"),
    T("CAPsMAN Interfaces", "/caps-man/interface", "name mac-address master-interface running comment",
      "name master-interface comment"),
    T("CAPsMAN Provisioning", "/caps-man/provisioning", "action master-configuration identity-regexp",
      "action master-configuration identity-regexp"),
    T("CAPsMAN Registrations", "/caps-man/registration-table", "interface ssid mac-address uptime rx-signal",
      ro=True),
]
BRIDGE = pick("Interfaces", "Bridge", "Bridge Ports", "Bridge VLANs") + [
    T("Bridge Hosts", "/interface/bridge/host", "mac-address on-interface bridge age local", ro=True)]
MPLS = [
    T("LDP Instances", "/mpls/ldp", "afi lsr-id transport-addresses", "lsr-id transport-addresses"),
    T("MPLS Interfaces", "/mpls/interface", "interface mpls-mtu", "interface mpls-mtu"),
    T("LDP Neighbors", "/mpls/ldp/neighbor", "transport local-transport state", ro=True),
    T("Forwarding Table", "/mpls/forwarding-table", "in-label out-labels destination interface", ro=True),
]
RADIUS = [T("RADIUS Servers", "/radius", "service address timeout comment", "service address secret timeout comment"),
          S("RADIUS Incoming", "/radius/incoming")]
EXTRA_TOOLS = [
    dict(kind="dns", title="DNS Lookup"),
    dict(kind="tool", title="IP Scan", path="/tool/ip-scan",
         fields=[("Interface", "interface", "ether1"), ("Range", "address-range", "192.168.88.0/24")],
         cols="address mac-address dns time", key=("address",)),
    dict(kind="tool", title="Profile (CPU)", path="/tool/profile",
         fields=[("CPU", "cpu", "all")], cols="name usage", key=("name",)),
    S("E-mail", "/tool/e-mail"),
]

# (title, glyph, accent colour, spec | list-of-specs | list-of-(title, specs) groups)
WINBOX_TREE = [
    ("Interfaces", "⇆", "#a855f7", pick("Interfaces", "Interfaces", "Ethernet", "VLAN", "Bonding", "Interface Lists",
                                         "List Members", "GRE Tunnel", "EoIP Tunnel", "WireGuard", "WireGuard Peers")),
    ("Bridge", "⌘", "#22c55e", BRIDGE),
    ("PPP", "☻", "#3b82f6", pick("Interfaces", "PPPoE Server", "PPPoE Client", "L2TP Client", "SSTP Client",
                                 "OpenVPN Client") + pick("PPP", "Secrets", "Profiles", "Active Connections")),
    ("IP", "⌗", "#06b6d4", [s for g, items in MENU if g == "IP" for s in items]),
    ("IPv6", "⌗", "#0ea5e9", [s for g, items in MENU if g == "IPv6" for s in items]),
    ("Firewall", "▩", "#ef4444", [s for g, items in MENU if g == "Firewall" for s in items]),
    ("Routing", "⤮", "#f59e0b", pick("Routing", "Tables (v7)", "OSPF Instances", "OSPF Areas", "OSPF Interfaces (v7)",
                                    "OSPF Neighbors", "Route Filters (v7)", "Routing Rules")),
    ("BGP", "BGP", "#8b5cf6", pick("Routing", "BGP Connections (v7)", "BGP Sessions (v7)", "BGP Templates (v7)",
                                   "BGP Peers (v6)")),
    ("Queues", "≋", "#f97316", [s for g, items in MENU if g == "Queues" for s in items]),
    ("Wireless", "◉", "#14b8a6", WIRELESS),
    ("Switch", "⊞", "#10b981", SWITCH),
    ("MPLS", "⛓", "#e879f9", MPLS),
    ("RADIUS", "⚿", "#fb7185", RADIUS),
    ("System", "⚙", "#ec4899", [s for g, items in MENU if g == "System" for s in items
                                if s["title"] not in ("Files", "Log")]),
    ("Files", "▭", "#eab308", pick("System", "Files")[0]),
    ("Logs", "☰", "#60a5fa", pick("System", "Log")[0]),
    ("Tools", "✦", "#38bdf8", [s for g, items in MENU if g == "Tools" for s in items] + EXTRA_TOOLS),
]

NAV = [
    ("Dashboard", "▣", "#3b82f6", dict(kind="dashboard", title="Dashboard")),
    ("Command Center", "◉", "#22d3ee", dict(kind="noc", title="Command Center")),
    ("ISP Overview", "◎", "#60a5fa", dict(kind="isp_overview", title="ISP Overview")),
    ("Devices", "▤", "#22d3ee", dict(kind="devices", title="Devices")),
    ("Quick Connect", "ϟ", "#ff9f1c", dict(kind="quickconnect", title="Quick Connect")),
    ("Router Sync", "⇅", "#14b8a6", dict(kind="routers", title="Router Sync")),
    ("Network Totals", "Σ", "#2dd4bf", dict(kind="totals", title="Network Totals & Insights")),
    ("Clients", "☺", "#f472b6", dict(kind="clients", title="Clients")),
    ("Billing", "৳", "#22e08a", dict(kind="billing", title="Billing")),
    ("Packages", "▦", "#fbbf24", dict(kind="packages", title="Packages")),
    ("Expenses & Profit", "৳", "#fb923c", dict(kind="expenses", title="Expenses & Profit")),
    ("Support Tickets", "✉", "#f472b6", dict(kind="tickets", title="Support Tickets")),
    ("Automation & Alerts", "⚑", "#a78bfa", dict(kind="automation", title="Automation & Alerts")),
    ("Bandwidth Usage", "⇵", "#22d3ee", dict(kind="usage", title="Bandwidth Usage")),
    ("Analytics & Aging", "◔", "#60a5fa", dict(kind="analytics", title="Analytics & Aging")),
    ("Cash Book", "৳", "#34d399", dict(kind="cashbook", title="Cash Book & Collectors")),
    ("Inventory", "▣", "#fbbf24", dict(kind="inventory", title="Inventory")),
    ("Router & Data Audit", "✔", "#f87171", dict(kind="audit", title="Router & Data Audit")),
    ("WinBox", "◈", "#38bdf8", "WINBOX"),
    ("Graphical Monitor", "▥", "#22e08a", dict(kind="livemon", title="Graphical Monitor")),
    ("Topology Map", "⌬", "#a3e635", dict(kind="topology", title="Topology Map")),
    ("Alerts & Notifications", "♨", "#ff4d6d", dict(kind="alerts", title="Alerts & Notifications")),
    ("Reports", "▤", "#34d399", dict(kind="reports", title="Reports")),
    ("ISP Settings & Data", "⛁", "#67e8f9", dict(kind="isp_settings", title="ISP Settings & Data")),
    ("Security & PIN", "🔒", "#94a3b8", dict(kind="security", title="Security & PIN")),
    ("Settings", "⚙", "#cbd5e1", dict(kind="settings_app", title="Settings")),
]
