"""Graphical Monitor (v6.2): live traffic graphs for ANY interface or PPPoE client on ANY saved router / device.
Add, edit, duplicate and remove graphs yourself (saved in settings.json); "All interfaces" table shows every interface
and the busiest clients live.  One background thread per router keeps a single connection open and reads the byte
counters every 1-10 s (API / SSH / Telnet / SNMP all supported)."""
import collections
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox

from core import *
from core import PAGE_KINDS
from isp_clients import combo
from isp_common import scrolled_tree
from transport import open_link
from ui_kit import GButton, fmt_rate

WINDOWS = {"1 min": 60, "2 min": 120, "5 min": 300, "10 min": 600, "30 min": 1800, "1 hour": 3600}
KINDS = {"Interface": "iface", "Client (PPPoE)": "client"}
KIND_LABEL = {v: k for k, v in KINDS.items()}


def blend(hex_fg, hex_bg, a):
    f = [int(hex_fg[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(hex_bg[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{int(x * a + y * (1 - a)):02x}" for x, y in zip(f, b))


def nice_max(v):
    v = max(v * 1.15, 1000.0)
    mag = 10 ** (len(str(int(v))) - 1)
    for m in (1, 2, 2.5, 5, 10):
        if m * mag >= v:
            return m * mag
    return 10 * mag


class LiveService:
    """Polls counters per router on worker threads and keeps rate history for every interface / client."""

    def __init__(self, app):
        self.app = app
        self.interval = 2.0
        self.hist = {}                      # (router, kind, name) -> deque[(ts, rx_bps, tx_bps)]
        self.latest = {}                    # router -> dict(ts, iface={name:(rx_bps,tx_bps)}, client={...})
        self.errors = {}
        self.workers = {}                   # router -> Event(stop)
        self.lock = threading.Lock()

    def running(self, router):
        return router in self.workers

    def start(self, router, pw):
        if router in self.workers:
            return
        p = next((x for x in self.app.profiles if x["name"] == router), None)
        if not p:
            return
        stop = threading.Event()
        self.workers[router] = stop
        threading.Thread(target=self._loop, args=(dict(p), pw, stop), daemon=True).start()

    def stop_all(self):
        for ev in self.workers.values():
            ev.set()
        self.workers = {}

    def _loop(self, p, pw, stop):
        router, link, prev = p["name"], None, None
        while not stop.is_set():
            try:
                if link is None:
                    link = open_link(p, pw or "", verify_tls=bool(self.app.settings.get("verify_tls", False)))
                ifs, ppp = link.traffic_counters()
                ts = time.time()
                if prev:
                    dt = max(ts - prev[0], 0.2)
                    lat = dict(ts=ts, iface={}, client={})
                    for kind, cur, old in (("iface", ifs, prev[1]), ("client", ppp, prev[2])):
                        for name, (rx, tx) in cur.items():
                            orx, otx = old.get(name, (rx, tx))
                            r = ((rx - orx) if rx >= orx else 0) * 8 / dt
                            t = ((tx - otx) if tx >= otx else 0) * 8 / dt
                            lat[kind][name] = (r, t)
                            with self.lock:
                                self.hist.setdefault((router, kind, name), collections.deque(maxlen=2400)).append((ts, r, t))
                    self.latest[router] = lat
                prev = (ts, ifs, ppp)
                self.errors.pop(router, None)
            except Exception as e:
                self.errors[router] = str(e) or e.__class__.__name__
                prev = None
                if link:
                    try:
                        link.close()
                    except Exception:
                        pass
                    link = None
            stop.wait(max(self.interval, 0.5))
        if link:
            try:
                link.close()
            except Exception:
                pass

    def series(self, router, kind, name, window):
        cut = time.time() - window
        with self.lock:
            return [x for x in self.hist.get((router, kind, name), ()) if x[0] >= cut]

    def fetch_names(self, p, pw):
        """Blocking: names of all interfaces and PPPoE users currently on the router."""
        link = open_link(p, pw or "", verify_tls=bool(self.app.settings.get("verify_tls", False)))
        try:
            ifs, ppp = link.traffic_counters()
        finally:
            link.close()
        return sorted(ifs), sorted(ppp)


def draw_graph(cv, pts, window, fixed_max, labels, colors=(CYAN, ORANGE), fill=True):
    cv.delete("all")
    w, h = max(cv.winfo_width(), 200), max(cv.winfo_height(), 100)
    left, top, bot, right = 58, 8, 16, 8
    pw_, ph = w - left - right, h - top - bot
    now = time.time()
    peak = max([max(p[1], p[2]) for p in pts] or [0])
    ymax = fixed_max * 1e6 if fixed_max else nice_max(peak)
    for i in range(5):
        y = top + ph * i / 4
        cv.create_line(left, y, w - right, y, fill=BORDER)
        cv.create_text(left - 4, y, text=fmt_rate(ymax * (4 - i) / 4), fill=DIM, font=(FONT, 7), anchor="e")
    for frac, lab in ((0, f"-{int(window)}s"), (0.5, f"-{int(window / 2)}s"), (1, "now")):
        cv.create_text(left + pw_ * frac, h - 6, text=lab, fill=DIM, font=(FONT, 7), anchor="w" if frac == 0 else ("e" if frac == 1 else "center"))
    if not pts:
        cv.create_text(w // 2, h // 2, text="waiting for data …", fill=MUTED, font=(FONT, 9))
        return
    for idx in (1, 2):
        col = colors[idx - 1]
        xy = [(left + pw_ * (1 - (now - p[0]) / window), top + ph * (1 - min(p[idx] / ymax, 1))) for p in pts]
        if len(xy) < 2:
            continue
        if fill:
            poly = [xy[0][0], top + ph] + [c for pt in xy for c in pt] + [xy[-1][0], top + ph]
            cv.create_polygon(poly, fill=blend(col, CARD, 0.22), outline="")
        cv.create_line([c for pt in xy for c in pt], fill=col, width=2, smooth=False)
    for i, (lab, col) in enumerate(zip(labels, colors)):
        cv.create_text(left + 6 + i * 110, top + 8, text=f"■ {lab}", fill=col, font=(FONT, 8, "bold"), anchor="w")


class WidgetDialog(tk.Toplevel):
    def __init__(self, app, svc, widget=None, on_ok=None, preset=None):
        super().__init__(app)
        self.app, self.svc, self.on_ok = app, svc, on_ok
        self.w = dict(widget or preset or {})
        self.wid = (widget or {}).get("id")
        self.title("Edit graph" if widget else "Add graph")
        self.configure(bg=BG)
        self.transient(app)
        names = [p["name"] for p in app.profiles]
        g = lambda k, d="": self.w.get(k, d)
        rows = (("Router / device", "router"), ("Graph type", "kind"), ("Interface or PPPoE user", "name"), ("Title (optional)", "title"),
                ("Time window", "window"), ("Fixed max Mbps (0 = auto)", "max"))
        self.e = {}
        for r, (lab, key) in enumerate(rows):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=6)
            if key == "router":
                wd = combo(self, names, 26)
                wd.set(g("router", names[0] if names else ""))
            elif key == "kind":
                wd = combo(self, list(KINDS), 26)
                wd.set(KIND_LABEL.get(g("kind", "iface")))
            elif key == "name":
                wd = combo(self, [], 30, state="normal")
                wd.set(g("name"))
            elif key == "window":
                wd = combo(self, list(WINDOWS), 12)
                wd.set(next((k for k, v in WINDOWS.items() if v == g("window", 300)), "5 min"))
            else:
                wd = app.entry(self, 30 if key == "title" else 10)
                wd.insert(0, str(g(key, 0 if key == "max" else "")))
            wd.grid(row=r, column=1, sticky="w", padx=14)
            self.e[key] = wd
        GButton(self, "⟳ Load names from router", self.load, "cyan", 190, 28, bg=BG).grid(row=2, column=2, padx=(0, 14))
        self.fill = tk.BooleanVar(value=g("fill", True))
        tk.Checkbutton(self, text="Filled area", variable=self.fill, bg=BG, fg=TEXT, selectcolor=PANEL2, activebackground=BG,
                       activeforeground=CYAN).grid(row=len(rows), column=1, sticky="w", padx=14)
        self.msg = tk.Label(self, text="", bg=BG, fg=MUTED, font=(FONT, 8))
        self.msg.grid(row=len(rows) + 1, column=0, columnspan=3, sticky="w", padx=14)
        app.button(self, "Save graph", self.ok, True).grid(row=len(rows) + 2, column=0, columnspan=3, sticky="ew", padx=14, pady=12)
        self._fill_from_cache()
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def _fill_from_cache(self):
        lat = self.svc.latest.get(self.e["router"].get())
        if lat:
            kind = KINDS[self.e["kind"].get()]
            self.e["name"]["values"] = sorted(lat[kind])

    def load(self):
        p = next((x for x in self.app.profiles if x["name"] == self.e["router"].get()), None)
        if not p:
            return
        pw = self.app.get_router_password(p)
        if pw is None:
            return
        self.msg.configure(text="loading …", fg=ORANGE)

        def done(res):
            ifs, ppp = res
            self.e["name"]["values"] = ppp if KINDS[self.e["kind"].get()] == "client" else ifs
            self.msg.configure(text=f"{len(ifs)} interfaces, {len(ppp)} PPPoE users on {p['name']}", fg=GREEN)
        self.app.run_async(lambda: self.svc.fetch_names(p, pw), done, lambda e: self.msg.configure(text=str(e), fg=RED))

    def ok(self):
        d = {k: w.get().strip() for k, w in self.e.items()}
        if not d["router"] or not d["name"]:
            messagebox.showerror("Graph", "Choose a router and an interface / user name.", parent=self)
            return
        try:
            mx = float(d["max"] or 0)
        except ValueError:
            messagebox.showerror("Graph", "Max must be a number.", parent=self)
            return
        out = dict(id=self.wid or f"w{int(time.time() * 1000)}", router=d["router"], kind=KINDS[d["kind"]], name=d["name"],
                   title=d["title"], window=WINDOWS.get(d["window"], 300), max=mx, fill=bool(self.fill.get()))
        self.on_ok(out)
        self.destroy()


class LiveMonitorPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Graphical Monitor", "live traffic of any interface or client • add / edit / remove your own graphs")
        if not hasattr(app, "live_svc"):
            app.live_svc = LiveService(app)
        self.svc = app.live_svc
        s = app.settings
        self.svc.interval = float(s.get("live_interval", 2))
        self.cols = tk.StringVar(value=str(s.get("live_cols", 2)))
        self.itv = tk.StringVar(value=f"{self.svc.interval:g} s")
        self.view = tk.StringVar(value="My graphs")
        self.trouter = tk.StringVar()
        self.paused = False
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 6))
        for text, fn, col, w in (("＋ Add graph", self.add, "purple", 120), ("＋ All interfaces of router", self.add_all, "blue", 210),
                                 ("＋ Top clients", self.add_top, "cyan", 120), ("⏸ Pause", self.toggle, "orange", 90), ("🗑 Remove all", self.clear, "red", 120)):
            b = GButton(bar, text, fn, col, w, 30, bg=BG)
            b.pack(side="left", padx=(0, 6))
            if text.startswith("⏸"):
                self.pbtn = b
        tk.Label(bar, text="View", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(10, 3))
        vc = combo(bar, ["My graphs", "All interfaces (table)"], 20, var=self.view)
        vc.pack(side="left")
        vc.bind("<<ComboboxSelected>>", lambda _e: self.switch())
        tk.Label(bar, text="Columns", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(10, 3))
        cc = combo(bar, ["1", "2", "3", "4"], 4, var=self.cols)
        cc.pack(side="left")
        cc.bind("<<ComboboxSelected>>", lambda _e: self.set_cols())
        tk.Label(bar, text="Refresh", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(10, 3))
        ic = combo(bar, ["1 s", "2 s", "3 s", "5 s", "10 s"], 5, var=self.itv)
        ic.pack(side="left")
        ic.bind("<<ComboboxSelected>>", lambda _e: self.set_interval())
        self.info = tk.Label(bar, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.info.pack(side="left", padx=10)
        self.holder = tk.Frame(self, bg=BG)
        self.holder.pack(fill="both", expand=True)
        # graphs view (scrollable)
        self.gwrap = tk.Frame(self.holder, bg=BG)
        self.canvas = tk.Canvas(self.gwrap, bg=BG, highlightthickness=0)
        sb = ttk.Scrollbar(self.gwrap, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y")
        self.canvas.pack(side="left", fill="both", expand=True)
        self.grid_f = tk.Frame(self.canvas, bg=BG)
        self.win = self.canvas.create_window(0, 0, window=self.grid_f, anchor="nw")
        self.grid_f.bind("<Configure>", lambda _e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", lambda e: self.canvas.itemconfigure(self.win, width=e.width))
        self.canvas.bind("<Enter>", lambda _e: self.canvas.bind_all("<MouseWheel>", lambda ev: self.canvas.yview_scroll(-1 * (ev.delta // 120), "units")))
        self.canvas.bind("<Leave>", lambda _e: self.canvas.unbind_all("<MouseWheel>"))
        # table view
        self.twrap = tk.Frame(self.holder, bg=BG)
        tb = tk.Frame(self.twrap, bg=BG)
        tb.pack(fill="x", pady=(0, 6))
        tk.Label(tb, text="Router", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.tc = combo(tb, [], 18, var=self.trouter)
        self.tc.pack(side="left", padx=6)
        self.tc.bind("<<ComboboxSelected>>", lambda _e: (self.ensure(), self.refresh_table()))
        GButton(tb, "＋ Graph from selected", self.graph_selected, "purple", 190, 28, bg=BG).pack(side="left", padx=6)
        tk.Label(tb, text="double-click a row to graph it", bg=BG, fg=DIM, font=(FONT, 8)).pack(side="left")
        w, self.tree = scrolled_tree(self.twrap, [("k", "TYPE", 70), ("n", "NAME", 220), ("a", "RX / UPLOAD", 120, "e"), ("b", "TX / DOWNLOAD", 120, "e"),
                                                 ("t", "TOTAL", 120, "e")])
        w.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda _e: self.graph_selected())
        self.cards = {}
        self._job = None
        self.menu = tk.Menu(self, tearoff=0, bg=CARD2, fg=TEXT, activebackground=BLUE)

    # ---- settings --------------------------------------------------------------------------------------------
    @property
    def widgets(self):
        return self.app.settings.setdefault("live_widgets", [])

    def save(self):
        self.app.apply_settings()

    def set_cols(self):
        self.app.settings["live_cols"] = int(self.cols.get())
        self.save()
        self.rebuild()

    def set_interval(self):
        v = float(self.itv.get().split()[0])
        self.svc.interval = v
        self.app.settings["live_interval"] = v
        self.save()

    # ---- lifecycle ----------------------------------------------------------------------------------------------
    def on_show(self):
        self.tc["values"] = [p["name"] for p in self.app.profiles]
        if not self.trouter.get() and self.app.profiles:
            self.trouter.set(self.app.profiles[0]["name"])
        self.paused = False
        self.pbtn.text = "⏸ Pause"
        self.pbtn.draw(False)
        self.switch()
        self.ensure()
        self.tick()

    def on_hide(self):
        if self._job:
            self.after_cancel(self._job)
            self._job = None
        self.svc.stop_all()

    def switch(self):
        self.gwrap.pack_forget()
        self.twrap.pack_forget()
        if self.view.get() == "My graphs":
            self.gwrap.pack(fill="both", expand=True)
            self.rebuild()
        else:
            self.twrap.pack(fill="both", expand=True)
        self.ensure()

    def ensure(self):
        """Start a poller for every router that is needed right now (asks for a password only if it isn't saved)."""
        if self.paused:
            return
        need = {w["router"] for w in self.widgets} if self.view.get() == "My graphs" else {self.trouter.get()}
        for name in need:
            p = next((x for x in self.app.profiles if x["name"] == name), None)
            if not p or self.svc.running(name):
                continue
            pw = self.app.get_router_password(p)
            if pw is None:
                continue
            self.svc.start(name, pw)

    def toggle(self):
        self.paused = not self.paused
        if self.paused:
            self.svc.stop_all()
        else:
            self.ensure()
        self.pbtn.text = "▶ Resume" if self.paused else "⏸ Pause"
        self.pbtn.draw(False)

    def tick(self):
        if not self.winfo_ismapped() and self.app.active is not self:
            return
        try:
            if self.view.get() == "My graphs":
                self.redraw()
            else:
                self.refresh_table()
            errs = [f"{r}: {e}" for r, e in self.svc.errors.items()]
            self.info.configure(text=("⚠ " + errs[0][:70]) if errs else ("paused" if self.paused else f"live • {len(self.svc.workers)} router(s)"),
                                fg=RED if errs else (ORANGE if self.paused else GREEN))
        finally:
            self._job = self.after(max(int(self.svc.interval * 1000), 700), self.tick)

    # ---- graphs ------------------------------------------------------------------------------------------------------
    def rebuild(self):
        for f, *_ in self.cards.values():
            f.destroy()
        self.cards = {}
        cols = max(int(self.cols.get()), 1)
        for c in range(cols):
            self.grid_f.grid_columnconfigure(c, weight=1, uniform="g")
        if not self.widgets:
            hint = tk.Label(self.grid_f, text="No graphs yet.\n\nPress  ＋ Add graph  to watch any interface or PPPoE client,\n"
                                              "or  ＋ All interfaces of router  to graph every port at once.",
                            bg=BG, fg=MUTED, font=(FONT, 11), justify="center")
            hint.grid(row=0, column=0, columnspan=cols, pady=60)
            self.cards["_hint"] = (hint, None, None)
            return
        for i, w in enumerate(self.widgets):
            f = tk.Frame(self.grid_f, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            f.grid(row=i // cols, column=i % cols, sticky="nsew", padx=5, pady=5)
            head = tk.Frame(f, bg=CARD)
            head.pack(fill="x", padx=8, pady=(6, 0))
            kind_icon = "☺" if w["kind"] == "client" else "⇅"
            title = w.get("title") or w["name"]
            tk.Label(head, text=f"{kind_icon} {title}", bg=CARD, fg=TEXT, font=(FONT, 10, "bold")).pack(side="left")
            tk.Label(head, text=f"  {w['router']}", bg=CARD, fg=DIM, font=(FONT, 8)).pack(side="left")
            for sym, fn in (("✕", lambda wid=w["id"]: self.remove(wid)), ("✎", lambda wid=w["id"]: self.edit(wid))):
                b = tk.Label(head, text=sym, bg=CARD, fg=MUTED, cursor="hand2", font=(FONT, 11))
                b.pack(side="right", padx=3)
                b.bind("<Button-1>", lambda _e, fn=fn: fn())
            val = tk.Label(f, text="", bg=CARD, fg=MUTED, font=(FONT, 9), anchor="w")
            val.pack(fill="x", padx=8)
            cv = tk.Canvas(f, height=170, bg=CARD, highlightthickness=0)
            cv.pack(fill="both", expand=True, padx=6, pady=(2, 6))
            for wg in (f, head, cv, val):
                wg.bind("<Button-3>", lambda e, wid=w["id"]: self.popup(e, wid))
            self.cards[w["id"]] = (f, cv, val)
        self.after(80, self.redraw)

    def redraw(self):
        for w in self.widgets:
            card = self.cards.get(w["id"])
            if not card:
                continue
            _f, cv, val = card
            pts = self.svc.series(w["router"], w["kind"], w["name"], w["window"])
            if w["kind"] == "client":                      # router's tx = what the client downloads
                pts = [(t, tx, rx) for t, rx, tx in pts]
                labels = ("Download", "Upload")
            else:
                labels = ("RX", "TX")
            draw_graph(cv, pts, w["window"], w.get("max", 0), labels, fill=w.get("fill", True))
            if pts:
                last, pk = pts[-1], max(max(p[1], p[2]) for p in pts)
                val.configure(text=f"{labels[0]} {fmt_rate(last[1])}   {labels[1]} {fmt_rate(last[2])}   peak {fmt_rate(pk)}", fg=GREEN)
            else:
                err = self.svc.errors.get(w["router"])
                val.configure(text=("⚠ " + err[:80]) if err else "waiting for data …", fg=RED if err else MUTED)

    def popup(self, e, wid):
        self.menu.delete(0, "end")
        for lab, fn in (("✎ Edit", lambda: self.edit(wid)), ("⧉ Duplicate", lambda: self.duplicate(wid)), ("✕ Remove", lambda: self.remove(wid)),
                        ("↑ Move up", lambda: self.move(wid, -1)), ("↓ Move down", lambda: self.move(wid, 1))):
            self.menu.add_command(label=lab, command=fn)
        self.menu.tk_popup(e.x_root, e.y_root)

    def _commit(self):
        self.save()
        self.ensure()
        self.rebuild()

    def add(self, preset=None):
        def ok(w):
            self.widgets.append(w)
            self._commit()
        WidgetDialog(self.app, self.svc, None, ok, preset)

    def edit(self, wid):
        w = next((x for x in self.widgets if x["id"] == wid), None)
        if w:
            def ok(nw):
                self.widgets[self.widgets.index(w)] = nw
                self._commit()
            WidgetDialog(self.app, self.svc, w, ok)

    def duplicate(self, wid):
        w = next((x for x in self.widgets if x["id"] == wid), None)
        if w:
            self.widgets.append(dict(w, id=f"w{int(time.time() * 1000)}"))
            self._commit()

    def remove(self, wid):
        self.app.settings["live_widgets"] = [x for x in self.widgets if x["id"] != wid]
        self._commit()

    def move(self, wid, d):
        ws = self.widgets
        i = next((k for k, x in enumerate(ws) if x["id"] == wid), None)
        if i is not None and 0 <= i + d < len(ws):
            ws[i], ws[i + d] = ws[i + d], ws[i]
            self._commit()

    def clear(self):
        if self.widgets and messagebox.askyesno("Remove all", f"Remove all {len(self.widgets)} graphs?", parent=self.app):
            self.app.settings["live_widgets"] = []
            self._commit()

    def add_all(self):
        names = [p["name"] for p in self.app.profiles]
        if not names:
            return
        from tkinter import simpledialog
        router = self.trouter.get() if self.trouter.get() in names else names[0]
        router = simpledialog.askstring("All interfaces", f"Router name ({', '.join(names)}):", initialvalue=router, parent=self.app)
        p = next((x for x in self.app.profiles if x["name"] == router), None)
        if not p:
            return
        pw = self.app.get_router_password(p)
        if pw is None:
            return
        self.info.configure(text="loading interfaces …", fg=ORANGE)

        def done(res):
            ifs = res[0]
            if len(ifs) > 24 and not messagebox.askyesno("Many interfaces", f"{len(ifs)} interfaces found. Add all as graphs?", parent=self.app):
                return
            have = {(w["router"], w["kind"], w["name"]) for w in self.widgets}
            for i, n in enumerate(ifs):
                if (router, "iface", n) not in have:
                    self.widgets.append(dict(id=f"w{int(time.time() * 1000)}{i}", router=router, kind="iface", name=n, title="", window=300, max=0, fill=True))
            self._commit()
        self.app.run_async(lambda: self.svc.fetch_names(p, pw), done, lambda e: messagebox.showerror("Interfaces", str(e), parent=self.app))

    def add_top(self):
        router = self.trouter.get() or (self.app.profiles[0]["name"] if self.app.profiles else "")
        lat = self.svc.latest.get(router, {}).get("client", {})
        if not lat:
            messagebox.showinfo("Top clients", "Open the “All interfaces (table)” view for this router first so live client data is collected,\n"
                                               "or add a client with ＋ Add graph.", parent=self.app)
            return
        top = sorted(lat, key=lambda n: -(lat[n][0] + lat[n][1]))[:6]
        have = {(w["router"], w["kind"], w["name"]) for w in self.widgets}
        for i, n in enumerate(top):
            if (router, "client", n) not in have:
                self.widgets.append(dict(id=f"w{int(time.time() * 1000)}{i}", router=router, kind="client", name=n, title="", window=300, max=0, fill=True))
        self._commit()

    # ---- all-interfaces table ----------------------------------------------------------------------------------------
    def refresh_table(self):
        lat = self.svc.latest.get(self.trouter.get())
        sel = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        if not lat:
            return
        rows = [("iface", n, v) for n, v in lat["iface"].items()]
        rows.sort(key=lambda r: -(r[2][0] + r[2][1]))
        crow = sorted(((("client", n, v)) for n, v in lat["client"].items()), key=lambda r: -(r[2][0] + r[2][1]))[:150]
        for kind, n, (rx, tx) in rows + crow:
            if kind == "client":                         # show as upload (client→router) / download (router→client)
                a, b = rx, tx
            else:
                a, b = rx, tx
            iid = f"{kind}|{n}"
            self.tree.insert("", "end", iid=iid, tags=("ok",) if a + b > 1e6 else (), values=("Client" if kind == "client" else "Iface", n, fmt_rate(a), fmt_rate(b), fmt_rate(a + b)))
        for s in sel:
            if self.tree.exists(s):
                self.tree.selection_add(s)

    def graph_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        have = {(w["router"], w["kind"], w["name"]) for w in self.widgets}
        added = 0
        for i, s in enumerate(sel):
            kind, name = s.split("|", 1)
            if (self.trouter.get(), kind, name) in have:
                continue
            self.widgets.append(dict(id=f"w{int(time.time() * 1000)}{i}", router=self.trouter.get(), kind=kind, name=name, title="", window=300, max=0, fill=True))
            added += 1
        self.save()
        self.info.configure(text=f"{added} graph(s) added — see “My graphs”", fg=GREEN)


PAGE_KINDS.update({"livemon": LiveMonitorPage})
