"""Shared constants, formatters and the Page base class (imported by every module)."""
import tkinter as tk

from ui_kit import (BG, SIDEBAR, TOPBAR, CARD, CARD2, BORDER, TEXT, MUTED, DIM, BLUE, CYAN, GREEN, ORANGE, RED,
                    PURPLE, PINK, YELLOW, FONT, MONO, fmt_rate)

PANEL, PANEL2 = CARD, CARD2
PAGE_KINDS = {}          # filled by mikrotik_manager (classic pages) and pro_pages / winbox (new pages)


def fmt_bytes(value):
    try:
        n = float(value or 0)
    except (TypeError, ValueError):
        return str(value)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1000:
            return f"{n:.1f} {unit}"
        n /= 1000
    return f"{n:.1f} PB"


def to_int(v, default=0):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return default


class Page(tk.Frame):
    """Base page. `app.host` (set by App.make_page) decides where the page lives: the main content area
    or a floating WinBox window."""

    def __init__(self, app, spec):
        super().__init__(getattr(app, "host", None) or app.content, bg=BG)
        self.app, self.spec = app, spec

    def on_show(self):
        pass

    def on_hide(self):
        pass

    def header(self, text, sub=""):
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 10))
        tk.Frame(bar, bg=BLUE, width=4, height=26).pack(side="left", padx=(0, 10))
        tk.Label(bar, text=text, bg=BG, fg=TEXT, font=(FONT, 17, "bold")).pack(side="left")
        if sub:
            tk.Label(bar, text=sub, bg=BG, fg=MUTED, font=(MONO, 9)).pack(side="left", padx=12, pady=(7, 0))
        return bar
