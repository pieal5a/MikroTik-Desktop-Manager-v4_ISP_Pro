"""Minimal SNMP v1 / v2c manager (GET, GETNEXT, GETBULK, WALK) over UDP — standard library only.
Used to read MikroTik health, interface counters, PPPoE session interfaces ("<pppoe-user>") and system info."""
import os
import socket
import struct

# ---- OIDs ---------------------------------------------------------------------------------------------
SYS_DESCR, SYS_UPTIME, SYS_NAME = "1.3.6.1.2.1.1.1.0", "1.3.6.1.2.1.1.3.0", "1.3.6.1.2.1.1.5.0"
IF_DESCR, IF_ADMIN, IF_OPER = "1.3.6.1.2.1.2.2.1.2", "1.3.6.1.2.1.2.2.1.7", "1.3.6.1.2.1.2.2.1.8"
IF_IN, IF_OUT = "1.3.6.1.2.1.2.2.1.10", "1.3.6.1.2.1.2.2.1.16"
IFX_NAME, IFX_HC_IN, IFX_HC_OUT = "1.3.6.1.2.1.31.1.1.1.1", "1.3.6.1.2.1.31.1.1.1.6", "1.3.6.1.2.1.31.1.1.1.10"
HR_CPU = "1.3.6.1.2.1.25.3.3.1.2"
HR_ST_DESCR, HR_ST_UNITS, HR_ST_SIZE, HR_ST_USED = ("1.3.6.1.2.1.25.2.3.1.3", "1.3.6.1.2.1.25.2.3.1.4",
                                                    "1.3.6.1.2.1.25.2.3.1.5", "1.3.6.1.2.1.25.2.3.1.6")
MT_TEMP, MT_CPU_TEMP, MT_VOLT = "1.3.6.1.4.1.14988.1.1.3.10.0", "1.3.6.1.4.1.14988.1.1.3.11.0", "1.3.6.1.4.1.14988.1.1.3.8.0"
MT_BOARD, MT_FW = "1.3.6.1.4.1.14988.1.1.7.8.0", "1.3.6.1.4.1.14988.1.1.7.4.0"

INT, OCT, NULL, OID, SEQ = 0x02, 0x04, 0x05, 0x06, 0x30
GET, GETNEXT, RESPONSE, GETBULK = 0xA0, 0xA1, 0xA2, 0xA5


class SnmpError(Exception):
    pass


# ---- BER ---------------------------------------------------------------------------------------------
def _len(n):
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _tlv(tag, body):
    return bytes([tag]) + _len(len(body)) + body


def _int(n):
    ln = max(1, (n.bit_length() + 8) // 8)
    return _tlv(INT, n.to_bytes(ln, "big", signed=True))


def _oid(s):
    p = [int(x) for x in s.strip(".").split(".")]
    out = bytearray([40 * p[0] + p[1]])
    for n in p[2:]:
        chunk = [n & 0x7F]
        n >>= 7
        while n:
            chunk.append(0x80 | (n & 0x7F))
            n >>= 7
        out += bytes(reversed(chunk))
    return _tlv(OID, bytes(out))


def _read(buf, i):
    tag = buf[i]
    ln = buf[i + 1]
    i += 2
    if ln & 0x80:
        k = ln & 0x7F
        ln = int.from_bytes(buf[i:i + k], "big")
        i += k
    return tag, buf[i:i + ln], i + ln


def _dec_oid(b):
    parts = [b[0] // 40, b[0] % 40]
    n = 0
    for x in b[1:]:
        n = (n << 7) | (x & 0x7F)
        if not x & 0x80:
            parts.append(n)
            n = 0
    return ".".join(map(str, parts))


def _dec_value(tag, b):
    if tag in (INT,):
        return int.from_bytes(b, "big", signed=True) if b else 0
    if tag in (0x41, 0x42, 0x43, 0x46):            # Counter32 / Gauge32 / TimeTicks / Counter64
        return int.from_bytes(b, "big")
    if tag == OCT or tag == 0x44:
        return b.decode("utf-8", "replace")
    if tag == 0x40:
        return ".".join(str(x) for x in b)
    if tag == OID:
        return _dec_oid(b)
    if tag in (0x80, 0x81, 0x82):
        return None                                # noSuchObject / noSuchInstance / endOfMibView
    return None


def _oid_key(s):
    return tuple(int(x) for x in s.split("."))


class Snmp:
    def __init__(self, host, community="public", port=161, version="2c", timeout=2.0, retries=1):
        self.host, self.port, self.community = host, int(port), community.encode()
        self.v = 0 if str(version) in ("1", "v1") else 1
        self.timeout, self.retries = timeout, retries

    def _request(self, pdu_tag, oids, a=0, b=0):
        rid = int.from_bytes(os.urandom(3), "big")
        binds = b"".join(_tlv(SEQ, _oid(o) + _tlv(NULL, b"")) for o in oids)
        pdu = _tlv(pdu_tag, _int(rid) + _int(a) + _int(b) + _tlv(SEQ, binds))
        msg = _tlv(SEQ, _int(self.v) + _tlv(OCT, self.community) + pdu)
        fam = socket.AF_INET6 if ":" in self.host else socket.AF_INET
        last = None
        for _ in range(self.retries + 1):
            s = socket.socket(fam, socket.SOCK_DGRAM)
            s.settimeout(self.timeout)
            try:
                s.sendto(msg, (self.host, self.port))
                while True:
                    data, _addr = s.recvfrom(65535)
                    out = self._parse(data, rid)
                    if out is not None:
                        return out
            except socket.timeout:
                last = SnmpError(f"SNMP timeout ({self.host}:{self.port}) — check community / allowed address / UDP 161")
            finally:
                s.close()
        raise last

    @staticmethod
    def _parse(data, rid):
        try:
            _t, body, _ = _read(data, 0)
            _t, _ver, i = _read(body, 0)
            _t, _comm, i = _read(body, i)
            tag, pdu, _ = _read(body, i)
            if tag != RESPONSE:
                return None
            _t, r, j = _read(pdu, 0)
            if int.from_bytes(r, "big") != rid:
                return None
            _t, err, j = _read(pdu, j)
            _t, _idx, j = _read(pdu, j)
            _t, vbl, _ = _read(pdu, j)
        except Exception:
            return None
        if int.from_bytes(err, "big"):
            raise SnmpError(f"SNMP error-status {int.from_bytes(err, 'big')}")
        out, i = [], 0
        while i < len(vbl):
            _t, vb, i = _read(vbl, i)
            _t, o, k = _read(vb, 0)
            tag, val, _ = _read(vb, k)
            out.append((_dec_oid(o), _dec_value(tag, val), tag))
        return out

    # ---- public API -----------------------------------------------------------------------------
    def get(self, *oids):
        res = self._request(GET, oids)
        return {o: v for o, v, _t in res}

    def walk(self, base, limit=20000):
        """Return {oid: value} for everything under `base` (GETBULK on v2c, GETNEXT on v1)."""
        base = base.strip(".")
        pref = base + "."
        cur, out = base, {}
        while len(out) < limit:
            res = self._request(GETBULK, [cur], 0, 25) if self.v else self._request(GETNEXT, [cur])
            moved = False
            for o, v, tag in res:
                if not o.startswith(pref) or tag == 0x82:
                    return out
                if _oid_key(o) <= _oid_key(cur):
                    return out
                out[o], cur, moved = v, o, True
            if not moved:
                break
        return out

    def table(self, base):
        """walk() keyed by the trailing index: {'1': value, ...}"""
        n = len(base.strip(".")) + 1
        return {o[n:]: v for o, v in self.walk(base).items()}


# ---- high-level MikroTik collection ---------------------------------------------------------------------
def collect(host, community="public", port=161, version="2c", timeout=2.0):
    """Return a normalised snapshot dict (same shape as the other transports)."""
    s = Snmp(host, community, port, version, timeout)
    sysv = s.get(SYS_DESCR, SYS_UPTIME, SYS_NAME, MT_TEMP, MT_CPU_TEMP, MT_VOLT, MT_BOARD, MT_FW)
    ticks = sysv.get(SYS_UPTIME) or 0
    sec = int(ticks) // 100
    d, h, m = sec // 86400, sec % 86400 // 3600, sec % 3600 // 60
    loads = [v for v in s.table(HR_CPU).values() if isinstance(v, int)]
    cpu = int(sum(loads) / len(loads)) if loads else 0
    mem_pct = disk_pct = 0.0
    descr, units, size, used = (s.table(x) for x in (HR_ST_DESCR, HR_ST_UNITS, HR_ST_SIZE, HR_ST_USED))
    for k, name in descr.items():
        nm = str(name).lower()
        sz = (size.get(k) or 0) * (units.get(k) or 1)
        us = (used.get(k) or 0) * (units.get(k) or 1)
        if sz <= 0:
            continue
        if "main memory" in nm or nm == "memory":
            mem_pct = us * 100 / sz
        elif "disk" in nm or "hdd" in nm or "flash" in nm or "storage" in nm:
            disk_pct = us * 100 / sz
    names = s.table(IFX_NAME) or s.table(IF_DESCR)
    oper, admin = s.table(IF_OPER), s.table(IF_ADMIN)
    rx, tx = s.table(IFX_HC_IN), s.table(IFX_HC_OUT)
    if not rx:
        rx, tx = s.table(IF_IN), s.table(IF_OUT)
    ifaces, pppoe = [], []
    for k, name in names.items():
        name = str(name)
        row = dict(name=name, running=oper.get(k) == 1, disabled=admin.get(k) == 2, rxb=rx.get(k) or 0,
                   txb=tx.get(k) or 0, type="ether")
        if name.startswith("<") and name.endswith(">"):       # dynamic PPP server interface "<pppoe-user1>"
            user = name[1:-1].split("-", 1)[-1]
            pppoe.append(dict(name=user, interface=name, rxb=row["rxb"], txb=row["txb"]))
        else:
            ifaces.append(row)
    temp = sysv.get(MT_TEMP)
    return dict(identity=sysv.get(SYS_NAME) or host, version=sysv.get(MT_FW) or "", board=sysv.get(MT_BOARD) or "",
                descr=sysv.get(SYS_DESCR) or "", uptime=f"{d}d{h:02d}h{m:02d}m", uptime_s=sec, cpu=cpu,
                mem_pct=mem_pct, disk_pct=disk_pct, ifaces=ifaces, ppp_active=pppoe,
                temp=(temp / 10 if isinstance(temp, int) else None),
                volt=(sysv.get(MT_VOLT) / 10 if isinstance(sysv.get(MT_VOLT), int) else None))
