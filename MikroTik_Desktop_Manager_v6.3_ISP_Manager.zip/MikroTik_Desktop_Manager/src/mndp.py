"""MikroTik Neighbor Discovery (MNDP, UDP 5678) helpers — works without logging in."""
import socket
import struct
import time

TLV = {1: "mac", 5: "identity", 7: "version", 8: "platform", 10: "uptime", 11: "software-id", 12: "board",
       15: "ipv6", 16: "interface", 17: "address"}


def parse(data):
    rec, pos = {}, 4
    while pos + 4 <= len(data):
        t, ln = struct.unpack(">HH", data[pos:pos + 4])
        val = data[pos + 4:pos + 4 + ln]
        pos += 4 + ln
        name = TLV.get(t)
        if not name:
            continue
        if name == "mac" and len(val) == 6:
            rec[name] = ":".join(f"{b:02X}" for b in val)
        elif name == "address" and len(val) == 4:
            rec[name] = ".".join(str(b) for b in val)
        elif name == "uptime" and len(val) == 4:
            s = struct.unpack("<I", val)[0]
            rec[name] = f"{s // 86400}d {s % 86400 // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"
        elif name not in ("ipv6", "software-id"):
            rec[name] = val.decode("utf-8", "replace")
    return rec


def scan(seconds=6):
    found = {}
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.bind(("", 5678))
        try:
            s.sendto(b"\x00\x00\x00\x00", ("255.255.255.255", 5678))
        except OSError:
            pass
        end = time.time() + seconds
        while time.time() < end:
            s.settimeout(max(end - time.time(), 0.1))
            try:
                data, addr = s.recvfrom(2048)
            except socket.timeout:
                break
            rec = parse(data)
            if rec.get("mac"):
                rec.setdefault("address", addr[0])
                found[rec["mac"]] = rec
    finally:
        s.close()
    return list(found.values())
