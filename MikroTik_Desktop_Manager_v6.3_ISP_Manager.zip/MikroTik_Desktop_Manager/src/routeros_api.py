"""Minimal RouterOS API client (v6 / v7, plain TCP 8728 or API-SSL 8729). Standard library only."""
import hashlib
import socket
import ssl
import threading


def encode_length(n):
    if n < 0x80:
        return bytes([n])
    if n < 0x4000:
        n |= 0x8000
        return bytes([(n >> 8) & 0xFF, n & 0xFF])
    if n < 0x200000:
        n |= 0xC00000
        return bytes([(n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF])
    if n < 0x10000000:
        n |= 0xE0000000
        return bytes([(n >> 24) & 0xFF, (n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF])
    return b"\xf0" + n.to_bytes(4, "big")


def recv_exact(sock, n):
    data = bytearray()
    while len(data) < n:
        part = sock.recv(n - len(data))
        if not part:
            raise ConnectionError("Router closed the connection.")
        data.extend(part)
    return bytes(data)


def read_length(sock):
    b = recv_exact(sock, 1)[0]
    if b < 0x80:
        return b
    if b < 0xC0:
        return ((b & 0x3F) << 8) | recv_exact(sock, 1)[0]
    if b < 0xE0:
        x = recv_exact(sock, 2)
        return ((b & 0x1F) << 16) | (x[0] << 8) | x[1]
    if b < 0xF0:
        x = recv_exact(sock, 3)
        return ((b & 0x0F) << 24) | (x[0] << 16) | (x[1] << 8) | x[2]
    if b == 0xF0:
        return int.from_bytes(recv_exact(sock, 4), "big")
    raise ValueError("Invalid RouterOS API length prefix.")


def recv_sentence(sock):
    words = []
    while True:
        length = read_length(sock)
        if length == 0:
            return words
        words.append(recv_exact(sock, length).decode("utf-8", "replace"))


def send_sentence(sock, words):
    out = bytearray()
    for w in words:
        raw = w.encode("utf-8")
        out += encode_length(len(raw)) + raw
    out += b"\x00"
    sock.sendall(bytes(out))


def parse_words(words):
    result = {}
    for word in words[1:]:
        if word.startswith("="):
            key, _, value = word[1:].partition("=")
            result[key] = value
    return result


class RouterAPI:
    def __init__(self, host, port, username, password, use_ssl=False, timeout=10, verify_tls=False):
        self.host, self.port = host, int(port)
        self.username, self.password = username, password
        self.use_ssl, self.timeout, self.verify_tls = use_ssl, timeout, verify_tls
        self.sock = None
        self.lock = threading.RLock()

    def clone(self):
        return RouterAPI(self.host, self.port, self.username, self.password,
                         self.use_ssl, self.timeout, self.verify_tls)

    # ---- connection -------------------------------------------------
    def connect(self):
        raw = socket.create_connection((self.host, self.port), timeout=self.timeout)
        raw.settimeout(self.timeout)
        if self.use_ssl:
            ctx = ssl.create_default_context()
            if not self.verify_tls:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                try:  # RouterOS API-SSL commonly uses anonymous / old ciphers
                    ctx.set_ciphers("ALL:@SECLEVEL=0")
                except ssl.SSLError:
                    pass
            self.sock = ctx.wrap_socket(raw, server_hostname=self.host if self.verify_tls else None)
        else:
            self.sock = raw
        try:
            send_sentence(self.sock, ["/login", f"=name={self.username}", f"=password={self.password}"])
            resp = self._read_reply()
            if resp["type"] == "!done" and resp.get("ret"):
                # RouterOS < 6.43: challenge/response login
                challenge = bytes.fromhex(resp["ret"])
                digest = hashlib.md5(b"\x00" + self.password.encode() + challenge).hexdigest()
                send_sentence(self.sock, ["/login", f"=name={self.username}", f"=response=00{digest}"])
                resp = self._read_reply()
            if resp["type"] != "!done":
                raise PermissionError(resp.get("message") or "Login failed. Check username/password and API policy.")
        except Exception:
            self.close()
            raise
        return True

    def close(self):
        s, self.sock = self.sock, None
        if s:
            try:
                s.shutdown(socket.SHUT_RDWR)
            except Exception:
                pass
            try:
                s.close()
            except Exception:
                pass

    # ---- request / reply ---------------------------------------------
    def _read_reply(self):
        rows, trap, done = [], None, {}
        while True:
            words = recv_sentence(self.sock)
            if not words:
                continue
            kind = words[0]
            if kind == "!re":
                rows.append(parse_words(words))
            elif kind == "!trap":
                trap = parse_words(words)
            elif kind == "!fatal":
                raise ConnectionError(" ".join(words[1:]) or "RouterOS closed the session.")
            elif kind == "!done":
                done = parse_words(words)
                break
        out = dict(done)
        out["rows"] = rows
        out["type"] = "!trap" if trap else "!done"
        if trap:
            out["message"] = trap.get("message", "RouterOS command failed.")
        return out

    def command(self, path, *args):
        with self.lock:
            if not self.sock:
                raise ConnectionError("Not connected.")
            send_sentence(self.sock, [path, *args])
            res = self._read_reply()
        if res["type"] == "!trap":
            raise RuntimeError(res["message"])
        if res.get("ret") and not res["rows"]:
            return [{"ret": res["ret"]}]
        return res["rows"]

    def print_rows(self, path, proplist=None, query=None):
        args = []
        if proplist:
            args.append("=.proplist=" + ",".join(proplist))
        for k, v in (query or {}).items():
            args.append(f"?{k}={v}")
        return self.command(path + "/print", *args)

    def stream(self, path, args, on_row):
        """Blocking: run a long-lived command on THIS connection (use a clone), until closed/finished."""
        self.sock.settimeout(None)
        send_sentence(self.sock, [path, *args])
        while True:
            words = recv_sentence(self.sock)
            if not words:
                continue
            kind = words[0]
            if kind == "!re":
                on_row(parse_words(words))
            elif kind == "!trap":
                raise RuntimeError(parse_words(words).get("message", "RouterOS command failed."))
            elif kind == "!fatal":
                raise ConnectionError(" ".join(words[1:]) or "RouterOS closed the session.")
            elif kind == "!done":
                return
