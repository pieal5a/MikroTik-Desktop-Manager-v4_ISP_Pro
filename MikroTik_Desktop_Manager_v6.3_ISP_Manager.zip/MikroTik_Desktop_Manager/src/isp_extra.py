"""v5 additions: ISP Overview dashboard (12-month chart), Expenses & profit, Support tickets, multi-month / advance payment,
bulk package change and the printable client statement."""
import html
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import db as dbm
from core import *
from core import PAGE_KINDS
from isp_clients import combo, month_choices, mkey
from isp_common import *
from ui_kit import GButton, Panel


def kpi_row(parent, items, store):
    row = tk.Frame(parent, bg=BG)
    row.pack(fill="x", pady=(0, 8))
    for key, title, color in items:
        c = tk.Frame(row, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        c.pack(side="left", padx=(0, 8), ipadx=10, ipady=4)
        tk.Frame(c, bg=color, height=3).pack(fill="x")
        v = tk.Label(c, text="0", bg=CARD, fg=color, font=(FONT, 15, "bold"))
        v.pack(anchor="w", padx=10)
        tk.Label(c, text=title, bg=CARD, fg=MUTED, font=(FONT, 8)).pack(anchor="w", padx=10)
        store[key] = v
    return row


# ======================================================================================================
class OverviewPage(Page):
    """Business at a glance: this month's money, 12-month trend, biggest debtors, router health, package / zone mix."""

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("ISP Overview", "revenue • expenses • profit • due • router health")
        self.cards = {}
        kpi_row(self, (("clients", "Clients", BLUE), ("online", "Online now", CYAN), ("collected", "Collected this month ৳", GREEN),
                       ("expenses", "Expenses this month ৳", ORANGE), ("net", "Net profit ৳", GREEN), ("total_due", "Total DUE ৳", RED),
                       ("tickets", "Open tickets", PINK), ("new", "New clients (month)", PURPLE)), self.cards)
        mid = tk.Frame(self, bg=BG)
        mid.pack(fill="both", expand=True)
        left = tk.Frame(mid, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        tk.Label(left, text="Last 12 months — collected ▮  billed ▮  expenses ▮", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        self.cv = tk.Canvas(left, bg=CARD, height=250, highlightbackground=BORDER, highlightthickness=1)
        self.cv.pack(fill="x", pady=(2, 8))
        self.cv.bind("<Configure>", lambda _e: self.draw())
        tk.Label(left, text="Router health", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.rt = scrolled_tree(left, [("n", "ROUTER", 130), ("p", "PROTO", 70), ("s", "STATE", 80), ("cpu", "CPU", 55, "e"),
                                         ("mem", "RAM", 55, "e"), ("on", "ONLINE", 70, "e"), ("cl", "CLIENTS", 65, "e"),
                                         ("up", "UPTIME", 110), ("t", "LAST SYNC", 80)], height=6)
        w.pack(fill="both", expand=True, pady=(2, 0))
        right = tk.Frame(mid, bg=BG)
        right.pack(side="left", fill="both")
        tk.Label(right, text="Top 10 DUE clients (double-click = receive payment)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.dt = scrolled_tree(right, [("c", "PPPOE", 100), ("n", "NAME", 130), ("p", "PHONE", 100), ("m", "MONTHS", 55, "e"),
                                          ("d", "DUE ৳", 80, "e")], height=8)
        w.pack(fill="x", pady=(2, 8))
        self.dt.bind("<Double-1>", self._pay)
        tk.Label(right, text="Package mix", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.pt = scrolled_tree(right, [("k", "PACKAGE", 130), ("n", "CLIENTS", 65, "e"), ("r", "BILL ৳/MONTH", 100, "e")], height=5)
        w.pack(fill="x", pady=(2, 8))
        tk.Label(right, text="Zone collection (this month)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.zt = scrolled_tree(right, [("z", "ZONE", 110), ("n", "CLIENTS", 60, "e"), ("e", "BILLED", 75, "e"), ("p", "PAID", 75, "e")],
                                   height=5)
        w.pack(fill="x", pady=(2, 0))
        self.series = []

    def on_show(self):
        self.refresh()

    def on_sync(self):
        if self.winfo_ismapped():
            self.refresh()

    def _pay(self, _e=None):
        sel = self.dt.selection()
        if sel:
            from isp_clients import PayDialog
            PayDialog(self.app, int(sel[0]), self.refresh)

    def refresh(self):
        db, m = self.app.db, dbm.month_now()
        s, pr = db.summary(m), db.profit(m)
        o, p = db.ticket_counts()
        self.series = db.monthly_series(12)
        vals = dict(clients=s["total"] or 0, online=s["online"] or 0, collected=pr["collected"], expenses=pr["expenses"], net=pr["net"],
                    total_due=s["total_due"], tickets=o + p, new=self.series[-1]["new"])
        for k, lab in self.cards.items():
            lab.configure(text=money(vals[k]), fg=(RED if k == "net" and vals[k] < 0 else lab.cget("fg")))
        self.draw()
        self.rt.delete(*self.rt.get_children())
        counts = {r["router"]: r["n"] for r in db.q("SELECT router, COUNT(*) n FROM clients GROUP BY router")}
        for i, pf in enumerate(self.app.profiles):
            st = self.app.sync.status.get(pf["name"], {})
            state = st.get("state", "—")
            tag = (["odd"] if i % 2 else []) + [{"ok": "ok", "error": "bad", "no-password": "due"}.get(state, "dim")]
            self.rt.insert("", "end", tags=tag, values=(
                pf["name"], pf.get("proto", "api").upper(), {"ok": "● online", "error": "● down"}.get(state, state),
                f"{st['cpu']}%" if "cpu" in st else "", f"{st['mem_pct']:.0f}%" if "mem_pct" in st else "",
                st.get("ppp_active_n", "") if state == "ok" else "", counts.get(pf["name"], 0), st.get("uptime", ""),
                time.strftime("%H:%M:%S", time.localtime(st["ts"])) if st.get("ts") else ""))
        self.dt.delete(*self.dt.get_children())
        for i, r in enumerate(db.top_due(10)):
            self.dt.insert("", "end", iid=str(r["id"]), tags=("due",), values=(r["pppoe_id"], r["name"], r["phone1"], r["months"], money(r["due"])))
        self.pt.delete(*self.pt.get_children())
        for r in db.by_package():
            self.pt.insert("", "end", values=(r["package"], r["n"], money(r["revenue"])))
        self.zt.delete(*self.zt.get_children())
        for r in db.by_zone(m):
            self.zt.insert("", "end", values=(r["zone"], r["clients"], money(r["expected"]), money(r["paid"])))

    def draw(self):
        cv = self.cv
        cv.delete("all")
        data = self.series
        W, H = max(cv.winfo_width(), 400), max(cv.winfo_height(), 200)
        if not data:
            return
        L, R, T, B = 62, 14, 14, 34
        top = max([max(d["collected"], d["expected"], d["expenses"]) for d in data] + [1])
        step = 10 ** (len(str(int(top))) - 1)
        top = ((int(top) // step) + 1) * step
        for i in range(5):                                           # grid + y labels
            y = T + (H - T - B) * i / 4
            cv.create_line(L, y, W - R, y, fill="#17294d")
            cv.create_text(L - 6, y, text=money(top * (4 - i) / 4), fill=MUTED, anchor="e", font=(FONT, 8))
        gw = (W - L - R) / len(data)
        bw = max(min(gw / 4, 22), 4)
        for i, d in enumerate(data):
            x0 = L + gw * i + gw / 2 - bw * 1.5
            for j, (key, color) in enumerate((("collected", GREEN), ("expected", BLUE), ("expenses", ORANGE))):
                h = (H - T - B) * d[key] / top
                x = x0 + j * bw
                cv.create_rectangle(x, H - B - h, x + bw - 1, H - B, fill=color, outline="")
            cv.create_text(L + gw * i + gw / 2, H - B + 12, text=d["month"][2:].replace("-", "/"), fill=MUTED, font=(FONT, 8))
            if d["collected"]:
                cv.create_text(L + gw * i + gw / 2, H - B + 24, text=f"{d['collected'] / 1000:.0f}k", fill=GREEN, font=(FONT, 7))


# ======================================================================================================
class ExpenseDialog(tk.Toplevel):
    def __init__(self, app, on_ok, month=None):
        super().__init__(app)
        self.app, self.on_ok = app, on_ok
        self.title("Add expense")
        self.configure(bg=BG)
        self.transient(app)
        self.e = {}
        day = time.strftime("%Y-%m-%d") if not month or month == dbm.month_now() else month + "-01"
        for r, (lab, key, w) in enumerate((("Date (YYYY-MM-DD)", "day", 16), ("Category", "category", 24), ("Amount ৳ *", "amount", 16),
                                           ("Paid to", "paid_to", 28), ("Router / POP (optional)", "router", 20), ("Note", "note", 34))):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=6)
            if key == "category":
                wd = combo(self, dbm.EXPENSE_CATEGORIES, 24, state="normal")
                wd.set(dbm.EXPENSE_CATEGORIES[0])
            elif key == "router":
                wd = combo(self, [""] + [p["name"] for p in app.profiles], 20)
            else:
                wd = app.entry(self, w)
                if key == "day":
                    wd.insert(0, day)
            wd.grid(row=r, column=1, sticky="w", padx=14)
            self.e[key] = wd
        app.button(self, "Save expense", self.ok, True).grid(row=6, column=0, columnspan=2, sticky="ew", padx=14, pady=14)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def ok(self):
        d = {k: w.get().strip() for k, w in self.e.items()}
        try:
            time.strptime(d["day"], "%Y-%m-%d")
            d["amount"] = float(d["amount"])
            assert d["amount"] > 0
        except Exception:
            messagebox.showerror("Expense", "Enter a valid date (YYYY-MM-DD) and amount.", parent=self)
            return
        self.app.db.add_expense(d)
        self.on_ok()
        self.destroy()


class ExpensesPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Expenses & Profit", "bandwidth • salary • rent • equipment … → monthly profit / loss")
        self.cards = {}
        kpi_row(self, (("collected", "Collected ৳", GREEN), ("expenses", "Expenses ৳", ORANGE), ("net", "Net profit ৳", CYAN),
                       ("margin", "Margin", PURPLE)), self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        tk.Label(f, text="Month", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.month = tk.StringVar(value=month_choices()[2])
        mc = combo(f, month_choices(), 18, var=self.month)
        mc.pack(side="left", padx=6)
        mc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        for text, fn, col, w in (("＋ Add Expense", self.add, "purple", 130), ("− Delete", self.delete, "red", 90),
                                 ("🖨 Profit & Loss report", self.report, "blue", 170), ("⬇ Export CSV", self.export, "cyan", 120)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(8, 0))
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        w, self.tree = scrolled_tree(body, [("d", "DATE", 90), ("c", "CATEGORY", 150), ("a", "AMOUNT ৳", 90, "e"), ("p", "PAID TO", 150),
                                           ("r", "ROUTER", 100), ("n", "NOTE", 260)])
        w.pack(side="left", fill="both", expand=True, padx=(0, 8))
        side = tk.Frame(body, bg=BG)
        side.pack(side="left", fill="y")
        tk.Label(side, text="By category", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w2, self.ct = scrolled_tree(side, [("c", "CATEGORY", 140), ("n", "#", 35, "e"), ("t", "TOTAL ৳", 85, "e")], height=10)
        w2.pack(fill="x")
        self.rows = []

    def on_show(self):
        self.refresh()

    def refresh(self):
        db, m = self.app.db, mkey(self.month.get())
        self.rows = db.expenses(m)
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(self.rows):
            self.tree.insert("", "end", iid=str(r["id"]), tags=("odd",) if i % 2 else (),
                             values=(r["day"], r["category"], money(r["amount"]), r["paid_to"], r["router"], r["note"]))
        self.ct.delete(*self.ct.get_children())
        for r in db.expense_by_category(m):
            self.ct.insert("", "end", values=(r["category"], r["n"], money(r["total"])))
        pr = db.profit(m)
        self.cards["collected"].configure(text=money(pr["collected"]))
        self.cards["expenses"].configure(text=money(pr["expenses"]))
        self.cards["net"].configure(text=money(pr["net"]), fg=GREEN if pr["net"] >= 0 else RED)
        self.cards["margin"].configure(text=f"{pr['net'] * 100 / pr['collected']:.0f}%" if pr["collected"] else "—")

    def add(self):
        ExpenseDialog(self.app, self.refresh, mkey(self.month.get()))

    def delete(self):
        sel = self.tree.selection()
        if sel and messagebox.askyesno("Delete", f"Delete {len(sel)} expense(s)?", parent=self.app):
            for i in sel:
                self.app.db.delete_expense(int(i))
            self.refresh()

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"expenses_{mkey(self.month.get())}.csv", parent=self.app)
        if f:
            self.app.db.export_csv(f, self.rows, ["day", "category", "amount", "paid_to", "router", "note"])

    def report(self):
        db, m, e = self.app.db, mkey(self.month.get()), html.escape
        pr = db.profit(m)
        exp = "".join(f"<tr><td>{r['day']}</td><td>{e(r['category'])}</td><td>{e(r['paid_to'])}</td><td>{e(r['note'])}</td>"
                      f"<td class='r'>{money(r['amount'])}</td></tr>" for r in self.rows)
        cat = "".join(f"<tr><td>{e(r['category'])}</td><td class='r'>{money(r['total'])}</td></tr>" for r in db.expense_by_category(m))
        meth = "".join(f"<tr><td>{e(r['method'])}</td><td class='r'>{money(r['total'])}</td></tr>" for r in db.by_method(m))
        s = self.app.settings
        show_html(
            "<!doctype html><meta charset='utf-8'><title>Profit & Loss</title><style>body{font-family:Segoe UI,Arial;margin:24px}"
            "table{border-collapse:collapse;width:100%;margin-bottom:18px}td,th{border:1px solid #ccc;padding:5px 8px;font-size:13px}"
            "th{background:#1d4ed8;color:#fff}td.r{text-align:right}h1{color:#1d4ed8;margin:0}.net{font-size:20px}</style>"
            f"<h1>{e(s.get('company', BRAND['company']))}</h1><h2>Profit & Loss — {dbm.month_label(m)}</h2>"
            f"<h3>Income (collected)</h3><table>{meth}<tr><th>Total income</th><th class='r'>{money(pr['collected'])}</th></tr></table>"
            f"<h3>Expenses by category</h3><table>{cat}<tr><th>Total expenses</th><th class='r'>{money(pr['expenses'])}</th></tr></table>"
            f"<p class='net'><b>Net profit: ৳ {money(pr['net'])}</b></p>"
            f"<h3>Expense details</h3><table><tr><th>Date</th><th>Category</th><th>Paid to</th><th>Note</th><th>৳</th></tr>{exp}</table>",
            "profit_loss")


# ======================================================================================================
class TicketDialog(tk.Toplevel):
    def __init__(self, app, tid=None, on_ok=None, client_id=None):
        super().__init__(app)
        self.app, self.tid, self.on_ok = app, tid, on_ok
        self.t = next((t for t in app.db.tickets() if t["id"] == tid), {}) if tid else {}
        self.cid = self.t.get("client_id") or client_id
        self.title(f"Ticket #{tid}" if tid else "New support ticket")
        self.configure(bg=BG)
        self.transient(app)
        c = app.db.client(self.cid) if self.cid else None
        r = 0
        tk.Label(self, text="Client (PPPoE ID / name / phone)", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=6)
        self.cl = combo(self, [], 40, state="normal")
        self.cl.grid(row=r, column=1, sticky="w", padx=14)
        self.cl.bind("<KeyRelease>", self._find)
        self.cl.bind("<<ComboboxSelected>>", self._pick)
        self.found = {}
        if c:
            self.cl.set(f"{c['pppoe_id']} — {c['name']}")
        self.w = {}
        for r, (lab, key) in enumerate((("Title *", "title"), ("Category", "category"), ("Priority", "priority"), ("Status", "status"),
                                        ("Assigned to", "assigned")), 1):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=6)
            if key == "category":
                wd = combo(self, dbm.TICKET_CATEGORIES, 24)
            elif key == "priority":
                wd = combo(self, ["Low", "Normal", "High", "Urgent"], 14)
            elif key == "status":
                wd = combo(self, dbm.TICKET_STATUS, 14)
            else:
                wd = app.entry(self, 40 if key == "title" else 24)
            default = {"category": dbm.TICKET_CATEGORIES[0], "priority": "Normal", "status": "Open"}.get(key, "")
            val = self.t.get(key, default)
            wd.set(val) if isinstance(wd, ttk.Combobox) else wd.insert(0, val)
            wd.grid(row=r, column=1, sticky="w", padx=14)
            self.w[key] = wd
        for r, (lab, key) in enumerate((("Problem detail", "detail"), ("Resolution / what was done", "resolution")), 6):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="nw", padx=14, pady=6)
            t = tk.Text(self, height=3, width=44, bg=PANEL2, fg=TEXT, insertbackground=CYAN, relief="flat", font=(FONT, 10))
            t.insert("1.0", self.t.get(key, ""))
            t.grid(row=r, column=1, padx=14, pady=4)
            self.w[key] = t
        app.button(self, "Save ticket", self.ok, True).grid(row=8, column=0, columnspan=2, sticky="ew", padx=14, pady=14)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def _find(self, _e=None):
        q = self.cl.get().strip()
        if len(q) < 2:
            return
        rows = self.app.db.clients(q)[:25]
        self.found = {f"{c['pppoe_id']} — {c['name']}": c["id"] for c in rows}
        self.cl["values"] = list(self.found)

    def _pick(self, _e=None):
        self.cid = self.found.get(self.cl.get(), self.cid)

    def ok(self):
        g = lambda k: self.w[k].get("1.0", "end").strip() if isinstance(self.w[k], tk.Text) else self.w[k].get().strip()
        if not g("title"):
            messagebox.showerror("Ticket", "Title is required.", parent=self)
            return
        d = {k: g(k) for k in self.w} | {"id": self.tid, "client_id": self.cid}
        self.app.db.save_ticket(d)
        if self.on_ok:
            self.on_ok()
        self.destroy()


class TicketsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Support Tickets", "complaints • new connections • follow-up")
        self.cards = {}
        kpi_row(self, (("Open", "Open", RED), ("In progress", "In progress", ORANGE), ("Resolved", "Resolved", GREEN),
                       ("Closed", "Closed", MUTED)), self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        self.q, self.st = tk.StringVar(), tk.StringVar(value="Open + In progress")
        self.q.trace_add("write", lambda *_: self.refresh())
        e = app.entry(f, 26)
        e.configure(textvariable=self.q)
        e.pack(side="left", ipady=3, padx=(0, 8))
        sc = combo(f, ["Open + In progress", "All"] + dbm.TICKET_STATUS, 18, var=self.st)
        sc.pack(side="left", padx=4)
        sc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        for text, fn, col, w in (("＋ New Ticket", self.add, "purple", 120), ("✎ Edit", self.edit, "blue", 90),
                                 ("✔ Mark resolved", self.resolve, "green", 140), ("− Delete", self.delete, "red", 90)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(8, 0))
        w, self.tree = scrolled_tree(self, [("id", "#", 44, "e"), ("t", "TITLE", 230), ("c", "CLIENT", 150), ("ph", "PHONE", 105),
                                           ("k", "CATEGORY", 130), ("p", "PRIORITY", 70), ("s", "STATUS", 90), ("a", "ASSIGNED", 100),
                                           ("cr", "CREATED", 130), ("rs", "RESOLVED", 130)])
        w.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda _e: self.edit())

    def on_show(self):
        self.refresh()

    def refresh(self):
        db, st = self.app.db, self.st.get()
        allrows = db.tickets("", self.q.get().strip())
        for k, lab in self.cards.items():
            lab.configure(text=str(sum(1 for t in allrows if t["status"] == k)))
        rows = allrows if st == "All" else [t for t in allrows if (t["status"] in ("Open", "In progress") if st.startswith("Open +") else t["status"] == st)]
        self.tree.delete(*self.tree.get_children())
        for i, t in enumerate(rows):
            tag = (["odd"] if i % 2 else []) + [{"Open": "bad", "In progress": "due", "Resolved": "ok"}.get(t["status"], "dim")]
            self.tree.insert("", "end", iid=str(t["id"]), tags=tag, values=(
                t["id"], t["title"], f"{t['pppoe_id'] or ''} {t['client_name'] or ''}".strip(), t["phone1"] or "", t["category"],
                t["priority"], t["status"], t["assigned"], t["created"], t["resolved_at"]))

    def add(self):
        TicketDialog(self.app, None, self.refresh)

    def _id(self):
        sel = self.tree.selection()
        return int(sel[0]) if sel else None

    def edit(self):
        if self._id():
            TicketDialog(self.app, self._id(), self.refresh)

    def resolve(self):
        t = next((t for t in self.app.db.tickets() if t["id"] == self._id()), None)
        if t:
            self.app.db.save_ticket(dict(t, status="Resolved"))
            self.refresh()

    def delete(self):
        if self._id() and messagebox.askyesno("Delete", "Delete this ticket?", parent=self.app):
            self.app.db.delete_ticket(self._id())
            self.refresh()


# ======================================================================================================
class MultiPayDialog(tk.Toplevel):
    """One payment covering several months: oldest dues first, the rest becomes ADVANCE for the coming months."""

    def __init__(self, app, cid, on_done=None):
        super().__init__(app)
        self.app, self.cid, self.on_done = app, cid, on_done
        c = app.db.client(cid)
        self.c = c
        self.title(f"Multi-month / advance payment — {c['name'] or c['pppoe_id']}")
        self.configure(bg=BG)
        self.transient(app)
        due = app.db.due_months(cid)
        tk.Label(self, text=f"{c['pppoe_id']} • {c['name']} • monthly bill ৳{money(c['bill'])}", bg=BG, fg=CYAN,
                 font=(FONT, 10, "bold")).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(self, text=f"Current DUE ৳{money(sum(d['due'] for d in due))} for {len(due)} month(s): "
                            + (", ".join(d["month"] for d in due[:8]) or "none"), bg=BG, fg=ORANGE, font=(FONT, 9)).pack(anchor="w", padx=16)
        g = tk.Frame(self, bg=BG)
        g.pack(padx=16, pady=10)
        self.amount, self.trx = app.entry(g, 18), app.entry(g, 18)
        self.method = tk.StringVar(value="Cash")
        tk.Label(g, text="Amount received ৳", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=0, column=0, sticky="w", pady=5)
        self.amount.grid(row=0, column=1, padx=8)
        self.amount.insert(0, f"{sum(d['due'] for d in due):g}")
        self.amount.bind("<KeyRelease>", lambda _e: self.preview())
        tk.Label(g, text="Method", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=1, column=0, sticky="w", pady=5)
        combo(g, METHODS, 14, var=self.method).grid(row=1, column=1, sticky="w", padx=8)
        tk.Label(g, text="Transaction ID", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=2, column=0, sticky="w", pady=5)
        self.trx.grid(row=2, column=1, padx=8)
        self.prev = tk.Label(self, text="", bg=CARD, fg=TEXT, justify="left", anchor="w", font=(FONT, 9), padx=10, pady=8)
        self.prev.pack(fill="x", padx=16, pady=(0, 8))
        app.button(self, "✔ Receive payment", self.ok, True).pack(fill="x", padx=16, pady=(0, 14))
        self.preview()
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def _amt(self):
        try:
            return float(self.amount.get() or 0)
        except ValueError:
            return 0

    def preview(self):
        left, lines = self._amt(), []
        db = self.app.db
        for d in db.due_months(self.cid):
            if left <= 0:
                break
            p = min(left, d["due"])
            lines.append(f"{dbm.month_label(d['month'])}: ৳{money(p)}" + (" (partial)" if p < d["due"] else ""))
            left -= p
        month, bill, n = dbm.add_months(dbm.month_now(), 1), self.c["bill"], 0
        while left > 0.0001 and bill > 0 and n < 36:
            st = db.bill_status(self.cid, month)
            if st["due"] > 0:
                p = min(left, st["due"])
                lines.append(f"{dbm.month_label(month)}: ৳{money(p)} (advance)")
                left -= p
            month, n = dbm.add_months(month, 1), n + 1
        self.prev.configure(text="This payment will be split as:\n" + ("\n".join(lines) if lines else "—"))

    def ok(self):
        amt = self._amt()
        if amt <= 0:
            messagebox.showerror("Payment", "Enter a valid amount.", parent=self)
            return
        res = self.app.db.pay_multi(self.cid, amt, self.method.get(), self.trx.get().strip(), self.app.settings.get("operator", ""))
        self.app.notifier.payment_sms(self.cid, amt, res[-1][0] if res else dbm.month_now())
        self.app.after_payment(self.cid)
        if self.on_done:
            self.on_done()
        self.destroy()
        messagebox.showinfo("Payment", f"Received ৳{money(amt)}.\n" + "\n".join(f"{m}: ৳{money(a)}" for m, a in res), parent=self.app)


class BulkPackageDialog(tk.Toplevel):
    """Move many clients to another package: updates the package + monthly bill and (optionally) the PPP profile on the router."""

    def __init__(self, app, ids, on_done=None):
        super().__init__(app)
        self.app, self.ids, self.on_done = app, ids, on_done
        self.title("Change package")
        self.configure(bg=BG)
        self.transient(app)
        tk.Label(self, text=f"{len(ids)} client(s) selected", bg=BG, fg=CYAN, font=(FONT, 11, "bold")).pack(padx=16, pady=(14, 6), anchor="w")
        names = [p["name"] for p in app.db.packages()]
        self.pk = tk.StringVar(value=names[0] if names else "")
        combo(self, names, 28, var=self.pk).pack(padx=16, anchor="w")
        self.bill = tk.BooleanVar(value=True)
        self.push = tk.BooleanVar(value=True)
        for var, text in ((self.bill, "Set monthly bill to the package price"), (self.push, "Also change the PPP profile on the router")):
            tk.Checkbutton(self, text=text, variable=var, bg=BG, fg=TEXT, selectcolor=PANEL2, activebackground=BG,
                           activeforeground=CYAN).pack(anchor="w", padx=16, pady=2)
        app.button(self, "Apply", self.ok, True).pack(fill="x", padx=16, pady=14)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def ok(self):
        if not self.pk.get():
            return
        self.app.db.change_package(self.ids, self.pk.get(), self.bill.get())
        if self.push.get():
            self.app.push_clients(self.ids, quiet=True)
        if self.on_done:
            self.on_done()
        self.destroy()


# ======================================================================================================
def client_statement(app, cid):
    """Printable account statement: every bill and payment of one client with the running balance."""
    L = app.db.ledger(cid)
    c, e, s = L["client"], html.escape, app.settings
    pays = {}
    for p in L["payments"]:
        pays.setdefault(p["month"], []).append(p)
    rows, bal = "", 0.0
    for b in L["bills"]:
        net = b["amount"] - b["discount"]
        bal += net - b["paid"]
        pl = "<br>".join(f"{p['paid_at'][:10]} {e(p['method'])} ৳{money(p['amount'])} {e(p['trx'])}" for p in pays.get(b["month"], []))
        rows += (f"<tr><td>{dbm.month_label(b['month'])}</td><td class='r'>{money(b['amount'])}</td><td class='r'>{money(b['discount'])}</td>"
                 f"<td class='r'>{money(b['paid'])}</td><td class='r'>{money(max(net - b['paid'], 0))}</td><td>{pl}</td></tr>")
    tk_rows = "".join(f"<tr><td>{t['created'][:10]}</td><td>{e(t['title'])}</td><td>{e(t['status'])}</td></tr>" for t in L["tickets"][:10])
    show_html(
        "<!doctype html><meta charset='utf-8'><title>Statement</title><style>body{font-family:Segoe UI,Arial;max-width:900px;margin:24px auto}"
        "table{border-collapse:collapse;width:100%;margin-bottom:16px}td,th{border:1px solid #ccc;padding:5px 8px;font-size:13px}"
        "th{background:#1d4ed8;color:#fff}td.r{text-align:right}h1{color:#1d4ed8;margin:0}</style>"
        f"<h1>{e(s.get('company', BRAND['company']))}</h1><div>{e(s.get('site', BRAND['site']))}</div><h2>Account statement</h2>"
        f"<p><b>{e(c['name'])}</b> • PPPoE {e(c['pppoe_id'])} • {e(c['phone1'])}<br>{e(c['address'])}<br>"
        f"Package {e(c['package'])} • Monthly bill ৳{money(c['bill'])} • Router {e(c['router'])}<br>Printed {time.strftime('%Y-%m-%d %H:%M')}</p>"
        "<table><tr><th>Month</th><th>Bill</th><th>Discount</th><th>Paid</th><th>Due</th><th>Payments</th></tr>"
        f"{rows}<tr><th colspan=4>Total outstanding</th><th class='r'>{money(max(bal, 0))}</th><th></th></tr></table>"
        + (f"<h3>Recent tickets</h3><table><tr><th>Date</th><th>Title</th><th>Status</th></tr>{tk_rows}</table>" if tk_rows else ""),
        "statement")


PAGE_KINDS.update({"isp_overview": OverviewPage, "expenses": ExpensesPage, "tickets": TicketsPage})
