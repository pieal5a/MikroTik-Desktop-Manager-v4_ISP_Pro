"""SQLite storage (standard library) for ISP clients, packages, bills, payments and the audit log.
Client documents (photo / NID) are copied into  <data dir>/files/<client id>/ ."""
import csv
import shutil
import sqlite3
import threading
import time
from pathlib import Path

from db_plus import PlusMixin

SCHEMA = """
CREATE TABLE IF NOT EXISTS packages(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, speed TEXT DEFAULT '',
  price REAL DEFAULT 0, mt_profile TEXT DEFAULT '', note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY, router TEXT DEFAULT '', pppoe_id TEXT NOT NULL,
  pppoe_pass TEXT DEFAULT '', package TEXT DEFAULT '', bill REAL DEFAULT 0, name TEXT DEFAULT '',
  phone1 TEXT DEFAULT '', phone2 TEXT DEFAULT '', nid TEXT DEFAULT '', address TEXT DEFAULT '', zone TEXT DEFAULT '',
  join_date TEXT DEFAULT '', status TEXT DEFAULT 'active', note TEXT DEFAULT '',
  photo TEXT DEFAULT '', nid_front TEXT DEFAULT '', nid_back TEXT DEFAULT '', other_file TEXT DEFAULT '',
  on_router INTEGER DEFAULT 0, online INTEGER DEFAULT 0, ip TEXT DEFAULT '', uptime TEXT DEFAULT '',
  last_seen TEXT DEFAULT '', router_note TEXT DEFAULT '', created TEXT, updated TEXT,
  UNIQUE(router, pppoe_id));
CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, month TEXT NOT NULL,
  amount REAL DEFAULT 0, discount REAL DEFAULT 0, paid REAL DEFAULT 0, UNIQUE(client_id, month));
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, month TEXT NOT NULL,
  amount REAL NOT NULL, method TEXT DEFAULT 'Cash', trx TEXT DEFAULT '', received_by TEXT DEFAULT '',
  paid_at TEXT, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts TEXT, action TEXT, detail TEXT);
CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, day TEXT NOT NULL, category TEXT DEFAULT 'Other',
  amount REAL NOT NULL, paid_to TEXT DEFAULT '', router TEXT DEFAULT '', note TEXT DEFAULT '', created TEXT);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY, client_id INTEGER, title TEXT NOT NULL, detail TEXT DEFAULT '',
  category TEXT DEFAULT 'Other', priority TEXT DEFAULT 'Normal', status TEXT DEFAULT 'Open', assigned TEXT DEFAULT '',
  created TEXT, updated TEXT, resolved_at TEXT DEFAULT '', resolution TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS sms_log(id INTEGER PRIMARY KEY, ts TEXT, phone TEXT, channel TEXT, text TEXT, result TEXT);
CREATE INDEX IF NOT EXISTS ix_exp_day ON expenses(day);
CREATE INDEX IF NOT EXISTS ix_bills_month ON bills(month);
CREATE INDEX IF NOT EXISTS ix_pay_month ON payments(month);
"""
CLIENT_FIELDS = ("router", "pppoe_id", "pppoe_pass", "package", "bill", "name", "phone1", "phone2", "nid", "address",
                 "zone", "join_date", "status", "note", "photo", "nid_front", "nid_back", "other_file")
DUE_SQL = "COALESCE((SELECT SUM(MAX(b.amount-b.discount-b.paid,0)) FROM bills b WHERE b.client_id=c.id AND b.month<=?),0)"
MONTH_SQL = "(SELECT b.amount-b.discount-b.paid FROM bills b WHERE b.client_id=c.id AND b.month=?)"


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def month_now():
    return time.strftime("%Y-%m")


def add_months(m, n):
    y, mo = int(m[:4]), int(m[5:7]) - 1 + n
    return f"{y + mo // 12:04d}-{mo % 12 + 1:02d}"


EXPENSE_CATEGORIES = ["Bandwidth / Upstream", "Salary", "Office rent", "Electricity", "Equipment", "Fibre / Cable", "Vehicle / Fuel",
                      "Marketing", "Software / Licence", "Tax / BTRC", "Other"]
TICKET_CATEGORIES = ["No internet", "Slow speed", "Frequent disconnect", "Billing question", "New connection", "Relocation",
                     "Package change", "Equipment", "Other"]
TICKET_STATUS = ["Open", "In progress", "Resolved", "Closed"]
MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]


def month_label(m):
    try:
        return f"{MONTH_NAMES[int(m[5:7]) - 1]} {m[:4]}"
    except Exception:
        return m


class DB(PlusMixin):
    def __init__(self, folder):
        self.dir = Path(folder)
        self.files = self.dir / "files"
        self.files.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "isp.db"
        self.lock = threading.RLock()
        self._open()

    def _open(self):
        self.cx = sqlite3.connect(self.path, check_same_thread=False)
        self.cx.row_factory = sqlite3.Row
        self.cx.executescript(SCHEMA)
        self.cx.commit()
        self._migrate_plus()

    def q(self, sql, args=()):
        with self.lock:
            return [dict(r) for r in self.cx.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql, args=()):
        with self.lock:
            cur = self.cx.execute(sql, args)
            self.cx.commit()
            return cur.lastrowid

    # ---- audit -------------------------------------------------------------------------------------
    def log(self, action, detail=""):
        self.x("INSERT INTO audit(ts,action,detail) VALUES(?,?,?)", (now(), action, detail))

    def audit(self, limit=500):
        return self.q("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))

    # ---- packages ----------------------------------------------------------------------------------
    def packages(self):
        return self.q("SELECT * FROM packages ORDER BY price, name")

    def save_package(self, d):
        vals = (d["name"], d.get("speed", ""), float(d.get("price") or 0), d.get("mt_profile", ""), d.get("note", ""))
        if d.get("id"):
            self.x("UPDATE packages SET name=?,speed=?,price=?,mt_profile=?,note=? WHERE id=?", vals + (d["id"],))
            return d["id"]
        self.x("INSERT INTO packages(name,speed,price,mt_profile,note) VALUES(?,?,?,?,?) ON CONFLICT(name) DO UPDATE "
               "SET speed=excluded.speed, mt_profile=excluded.mt_profile", vals)
        return None

    def delete_package(self, pid):
        self.x("DELETE FROM packages WHERE id=?", (pid,))

    # ---- clients -----------------------------------------------------------------------------------
    def clients(self, search="", router="", package="", status="", month=None, zone=""):
        month = month or month_now()
        sql = f"SELECT c.*, {DUE_SQL} AS total_due, {MONTH_SQL} AS month_due FROM clients c WHERE 1=1"
        args = [month, month]
        if search:
            like = f"%{search}%"
            sql += " AND (c.pppoe_id LIKE ? OR c.name LIKE ? OR c.phone1 LIKE ? OR c.phone2 LIKE ? OR c.nid LIKE ? " \
                   "OR c.address LIKE ? OR c.ip LIKE ?)"
            args += [like] * 7
        if router:
            sql += " AND c.router=?"; args.append(router)
        if package:
            sql += " AND c.package=?"; args.append(package)
        if zone:
            sql += " AND c.zone=?"; args.append(zone)
        if status in ("active", "suspended", "disabled"):
            sql += " AND c.status=?"; args.append(status)
        elif status == "online":
            sql += " AND c.online=1"
        elif status == "offline":
            sql += " AND c.online=0 AND c.status='active'"
        elif status == "due":
            sql += f" AND {DUE_SQL}>0"; args.append(month)
        elif status == "paid":
            sql += f" AND {DUE_SQL}<=0 AND c.status!='disabled'"; args.append(month)
        elif status == "not-on-router":
            sql += " AND c.on_router=0"
        sql += " ORDER BY c.router, c.pppoe_id"
        return self.q(sql, args)

    def client(self, cid):
        return self.one("SELECT * FROM clients WHERE id=?", (cid,))

    def find_client(self, router, pppoe):
        return self.one("SELECT * FROM clients WHERE router=? AND pppoe_id=?", (router, pppoe))

    def zones(self):
        return [r["zone"] for r in self.q("SELECT DISTINCT zone FROM clients WHERE zone!='' ORDER BY zone")]

    def save_client(self, d):
        d = {k: d.get(k, "") for k in CLIENT_FIELDS} | {"id": d.get("id")}
        d["bill"] = float(d["bill"] or 0)
        d["status"] = d["status"] or "active"
        ts = now()
        if d["id"]:
            sets = ",".join(f"{k}=?" for k in CLIENT_FIELDS)
            old = self.client(d["id"]) or {}
            self.x(f"UPDATE clients SET {sets}, updated=? WHERE id=?", [d[k] for k in CLIENT_FIELDS] + [ts, d["id"]])
            self._track_disabled(d["id"], old.get("status"), d["status"])
            self.log("client-edit", f"{d['pppoe_id']} ({d['router']})")
            return d["id"]
        cols = ",".join(CLIENT_FIELDS)
        cid = self.x(f"INSERT INTO clients({cols},created,updated) VALUES({','.join('?' * len(CLIENT_FIELDS))},?,?)",
                     [d[k] for k in CLIENT_FIELDS] + [ts, ts])
        self.log("client-add", f"{d['pppoe_id']} ({d['router']})")
        return cid

    def delete_client(self, cid, keep_files=False):
        c = self.client(cid)
        if not c:
            return
        for t in ("bills", "payments"):
            self.x(f"DELETE FROM {t} WHERE client_id=?", (cid,))
        self.forget_client_extras(cid)
        self.x("DELETE FROM clients WHERE id=?", (cid,))
        if not keep_files:
            shutil.rmtree(self.files / str(cid), ignore_errors=True)
        self.log("client-delete", f"{c['pppoe_id']} ({c['router']})")

    def update_files(self, cid, files):
        for k, v in files.items():
            if k in ("photo", "nid_front", "nid_back", "other_file"):
                self.x(f"UPDATE clients SET {k}=? WHERE id=?", (v, cid))

    def set_status(self, cid, status):
        old = (self.client(cid) or {}).get("status")
        self.x("UPDATE clients SET status=?, updated=? WHERE id=?", (status, now(), cid))
        self._track_disabled(cid, old, status)

    def _track_disabled(self, cid, old, new):
        """Remember when a client became Inactive (used for the churn figure in Analytics)."""
        if new == "disabled" and old != "disabled":
            self.x("UPDATE clients SET disabled_at=? WHERE id=?", (now(), cid))
        elif new != "disabled" and old == "disabled":
            self.x("UPDATE clients SET disabled_at='' WHERE id=?", (cid,))

    def attach(self, cid, kind, src):
        """Copy a file into the client's folder; returns the stored relative path."""
        src = Path(src)
        folder = self.files / str(cid)
        folder.mkdir(parents=True, exist_ok=True)
        for old in folder.glob(kind + ".*"):
            if old != src:
                old.unlink(missing_ok=True)
        dest = folder / f"{kind}{src.suffix.lower() or '.jpg'}"
        if src.resolve() != dest.resolve():
            shutil.copyfile(src, dest)
        return f"{cid}/{dest.name}"

    def file_path(self, rel):
        return self.files / rel if rel else None

    # ---- bills / payments ----------------------------------------------------------------------------
    def ensure_bill(self, cid, month, amount=None):
        b = self.one("SELECT * FROM bills WHERE client_id=? AND month=?", (cid, month))
        if b:
            return b
        if amount is None:
            amount = (self.client(cid) or {}).get("bill", 0)
        self.x("INSERT INTO bills(client_id,month,amount) VALUES(?,?,?)", (cid, month, amount))
        return self.one("SELECT * FROM bills WHERE client_id=? AND month=?", (cid, month))

    def generate_bills(self, month):
        """Create the month's bill for every non-disabled client who has joined by then. Returns #created."""
        n = 0
        for c in self.q("SELECT id,bill,join_date FROM clients WHERE status!='disabled' AND bill>0"):
            if (c["join_date"] or "0000-00")[:7] > month:
                continue
            if not self.one("SELECT 1 FROM bills WHERE client_id=? AND month=?", (c["id"], month)):
                self.x("INSERT INTO bills(client_id,month,amount) VALUES(?,?,?)", (c["id"], month, c["bill"]))
                n += 1
        if n:
            self.log("bills-generated", f"{month}: {n}")
        return n

    def pay(self, cid, month, amount, method="Cash", trx="", by="", note="", discount=0.0):
        amount = float(amount)
        b = self.ensure_bill(cid, month)
        if discount:
            self.x("UPDATE bills SET discount=discount+? WHERE id=?", (float(discount), b["id"]))
        self.x("UPDATE bills SET paid=paid+? WHERE id=?", (amount, b["id"]))
        pid = self.x("INSERT INTO payments(client_id,month,amount,method,trx,received_by,paid_at,note) "
                     "VALUES(?,?,?,?,?,?,?,?)", (cid, month, amount, method, trx, by, now(), note))
        c = self.client(cid) or {}
        self.log("payment", f"{c.get('pppoe_id')} {month} {amount:g} {method}")
        return pid

    def delete_payment(self, pid):
        p = self.one("SELECT * FROM payments WHERE id=?", (pid,))
        if p:
            self.x("UPDATE bills SET paid=MAX(paid-?,0) WHERE client_id=? AND month=?", (p["amount"], p["client_id"], p["month"]))
            self.x("DELETE FROM payments WHERE id=?", (pid,))
            self.log("payment-delete", f"#{pid} {p['month']} {p['amount']:g}")

    def bill_status(self, cid, month):
        b = self.one("SELECT * FROM bills WHERE client_id=? AND month=?", (cid, month))
        if not b:
            c = self.client(cid) or {}
            return dict(amount=c.get("bill", 0), discount=0, paid=0, due=c.get("bill", 0), exists=False)
        return dict(amount=b["amount"], discount=b["discount"], paid=b["paid"],
                    due=max(b["amount"] - b["discount"] - b["paid"], 0), exists=True)

    def due_months(self, cid, upto=None):
        return self.q("SELECT month, amount-discount-paid AS due FROM bills WHERE client_id=? AND month<=? "
                      "AND amount-discount-paid>0 ORDER BY month", (cid, upto or month_now()))

    def payments(self, cid=None, month=None, limit=2000):
        sql = "SELECT p.*, c.pppoe_id, c.name, c.router FROM payments p LEFT JOIN clients c ON c.id=p.client_id WHERE 1=1"
        args = []
        if cid:
            sql += " AND p.client_id=?"; args.append(cid)
        if month:
            sql += " AND p.month=?"; args.append(month)
        return self.q(sql + " ORDER BY p.id DESC LIMIT ?", args + [limit])

    def month_bills(self, month, search="", router=""):
        sql = ("SELECT b.*, c.pppoe_id, c.name, c.phone1, c.router, c.package, c.status, "
               "MAX(b.amount-b.discount-b.paid,0) AS due FROM bills b JOIN clients c ON c.id=b.client_id WHERE b.month=?")
        args = [month]
        if search:
            sql += " AND (c.pppoe_id LIKE ? OR c.name LIKE ? OR c.phone1 LIKE ?)"; args += [f"%{search}%"] * 3
        if router:
            sql += " AND c.router=?"; args.append(router)
        return self.q(sql + " ORDER BY c.router, c.pppoe_id", args)

    def summary(self, month):
        r = self.one("SELECT COALESCE(SUM(amount-discount),0) AS expected, COALESCE(SUM(paid),0) AS paid, "
                     "COALESCE(SUM(MAX(amount-discount-paid,0)),0) AS due, COUNT(*) AS bills FROM bills WHERE month=?", (month,))
        cl = self.one("SELECT COUNT(*) AS total, SUM(status='active') AS active, SUM(online=1) AS online, "
                      "SUM(status='suspended') AS suspended FROM clients")
        collected = self.one("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE substr(paid_at,1,7)=?", (month,))["s"]
        total_due = self.one("SELECT COALESCE(SUM(MAX(amount-discount-paid,0)),0) AS s FROM bills WHERE month<=?", (month,))["s"]
        due_clients = self.one("SELECT COUNT(DISTINCT client_id) AS n FROM bills WHERE month<=? AND amount-discount-paid>0", (month,))["n"]
        return dict(r) | dict(cl) | dict(collected=collected, total_due=total_due, due_clients=due_clients)

    def by_method(self, month):
        return self.q("SELECT method, COUNT(*) AS n, SUM(amount) AS total FROM payments WHERE substr(paid_at,1,7)=? "
                      "GROUP BY method ORDER BY total DESC", (month,))

    def by_day(self, month):
        return self.q("SELECT substr(paid_at,1,10) AS day, COUNT(*) AS n, SUM(amount) AS total FROM payments "
                      "WHERE substr(paid_at,1,7)=? GROUP BY day ORDER BY day", (month,))

    def by_router(self, month):
        return self.q("SELECT c.router, COUNT(DISTINCT c.id) AS clients, COALESCE(SUM(b.amount-b.discount),0) AS expected, "
                      "COALESCE(SUM(b.paid),0) AS paid FROM clients c LEFT JOIN bills b ON b.client_id=c.id AND b.month=? "
                      "GROUP BY c.router ORDER BY c.router", (month,))

    # ---- multi-month / advance payment ---------------------------------------------------------------
    def pay_multi(self, cid, amount, method="Cash", trx="", by="", note="", upto=None):
        """Spread one payment over the oldest unpaid bills (up to `upto`, default this month); anything left over is
        booked as ADVANCE on the following months.  Returns [(month, amount), ...]."""
        left, done = float(amount), []
        upto = upto or month_now()
        for d in self.due_months(cid, upto):
            if left <= 0:
                break
            part = min(left, d["due"])
            self.pay(cid, d["month"], part, method, trx, by, (note + " (multi-month)").strip())
            done.append((d["month"], part))
            left -= part
        c = self.client(cid) or {}
        month, guard = add_months(upto, 1), 0
        while left > 0.0001 and c.get("bill", 0) > 0 and guard < 36:
            st = self.bill_status(cid, month)
            if st["due"] > 0:
                part = min(left, st["due"])
                self.pay(cid, month, part, method, trx, by, (note + " (advance)").strip())
                done.append((month, part))
                left -= part
            month, guard = add_months(month, 1), guard + 1
        if left > 0.0001:                                  # client has no bill amount: keep it on the last month
            self.pay(cid, upto, left, method, trx, by, (note + " (extra)").strip())
            done.append((upto, left))
        return done

    def ledger(self, cid):
        return dict(client=self.client(cid),
                    bills=self.q("SELECT * FROM bills WHERE client_id=? ORDER BY month", (cid,)),
                    payments=self.q("SELECT * FROM payments WHERE client_id=? ORDER BY id", (cid,)),
                    tickets=self.q("SELECT * FROM tickets WHERE client_id=? ORDER BY id DESC", (cid,)))

    def change_package(self, ids, package, set_bill=True):
        pk = self.one("SELECT * FROM packages WHERE name=?", (package,)) or {}
        for cid in ids:
            if set_bill and pk:
                self.x("UPDATE clients SET package=?, bill=?, updated=? WHERE id=?", (package, pk["price"], now(), cid))
            else:
                self.x("UPDATE clients SET package=?, updated=? WHERE id=?", (package, now(), cid))
        self.log("package-change", f"{len(ids)} client(s) -> {package}")

    # ---- expenses & profit --------------------------------------------------------------------------
    def add_expense(self, d):
        eid = self.x("INSERT INTO expenses(day,category,amount,paid_to,router,note,created) VALUES(?,?,?,?,?,?,?)",
                     (d["day"], d.get("category", "Other"), float(d["amount"]), d.get("paid_to", ""), d.get("router", ""),
                      d.get("note", ""), now()))
        self.log("expense", f"{d['day']} {d.get('category')} {float(d['amount']):g}")
        return eid

    def delete_expense(self, eid):
        self.x("DELETE FROM expenses WHERE id=?", (eid,))
        self.log("expense-delete", f"#{eid}")

    def expenses(self, month=None):
        if month:
            return self.q("SELECT * FROM expenses WHERE substr(day,1,7)=? ORDER BY day DESC, id DESC", (month,))
        return self.q("SELECT * FROM expenses ORDER BY day DESC, id DESC LIMIT 2000")

    def expense_by_category(self, month):
        return self.q("SELECT category, COUNT(*) AS n, SUM(amount) AS total FROM expenses WHERE substr(day,1,7)=? "
                      "GROUP BY category ORDER BY total DESC", (month,))

    def profit(self, month):
        coll = self.one("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE substr(paid_at,1,7)=?", (month,))["s"]
        exp = self.one("SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE substr(day,1,7)=?", (month,))["s"]
        return dict(collected=coll, expenses=exp, net=coll - exp)

    def monthly_series(self, n=12, upto=None):
        """Last n months: expected bill total, collected cash, expenses, new clients."""
        upto, out = upto or month_now(), []
        for i in range(n - 1, -1, -1):
            m = add_months(upto, -i)
            exp = self.one("SELECT COALESCE(SUM(amount-discount),0) AS s FROM bills WHERE month=?", (m,))["s"]
            pr = self.profit(m)
            new = self.one("SELECT COUNT(*) AS n FROM clients WHERE substr(join_date,1,7)=?", (m,))["n"]
            out.append(dict(month=m, expected=exp, collected=pr["collected"], expenses=pr["expenses"], new=new))
        return out

    def top_due(self, limit=10, upto=None):
        upto = upto or month_now()
        return self.q("SELECT c.id, c.pppoe_id, c.name, c.phone1, c.router, SUM(MAX(b.amount-b.discount-b.paid,0)) AS due, "
                      "COUNT(*) AS months FROM bills b JOIN clients c ON c.id=b.client_id WHERE b.month<=? AND "
                      "b.amount-b.discount-b.paid>0 GROUP BY c.id ORDER BY due DESC LIMIT ?", (upto, limit))

    def by_zone(self, month):
        return self.q("SELECT CASE WHEN c.zone='' THEN '(no zone)' ELSE c.zone END AS zone, COUNT(DISTINCT c.id) AS clients, "
                      "COALESCE(SUM(b.amount-b.discount),0) AS expected, COALESCE(SUM(b.paid),0) AS paid "
                      "FROM clients c LEFT JOIN bills b ON b.client_id=c.id AND b.month=? GROUP BY c.zone ORDER BY c.zone", (month,))

    def by_package(self):
        return self.q("SELECT CASE WHEN package='' THEN '(none)' ELSE package END AS package, COUNT(*) AS n, "
                      "COALESCE(SUM(bill),0) AS revenue FROM clients WHERE status!='disabled' GROUP BY package ORDER BY n DESC")

    # ---- support tickets -------------------------------------------------------------------------------
    def tickets(self, status="", search=""):
        sql = ("SELECT t.*, c.pppoe_id, c.name AS client_name, c.phone1 FROM tickets t LEFT JOIN clients c ON c.id=t.client_id "
               "WHERE 1=1")
        args = []
        if status == "open-all":
            sql += " AND t.status IN ('Open','In progress')"
        elif status:
            sql += " AND t.status=?"; args.append(status)
        if search:
            sql += " AND (t.title LIKE ? OR c.pppoe_id LIKE ? OR c.name LIKE ? OR c.phone1 LIKE ?)"; args += [f"%{search}%"] * 4
        return self.q(sql + " ORDER BY CASE t.status WHEN 'Open' THEN 0 WHEN 'In progress' THEN 1 ELSE 2 END, "
                      "CASE t.priority WHEN 'Urgent' THEN 0 WHEN 'High' THEN 1 ELSE 2 END, t.id DESC", args)

    def save_ticket(self, d):
        ts = now()
        if d.get("id"):
            res = ts if d["status"] in ("Resolved", "Closed") else ""
            self.x("UPDATE tickets SET client_id=?,title=?,detail=?,category=?,priority=?,status=?,assigned=?,resolution=?,"
                   "updated=?,resolved_at=CASE WHEN ?!='' THEN COALESCE(NULLIF(resolved_at,''),?) ELSE '' END WHERE id=?",
                   (d.get("client_id"), d["title"], d.get("detail", ""), d.get("category", "Other"), d.get("priority", "Normal"),
                    d["status"], d.get("assigned", ""), d.get("resolution", ""), ts, res, res, d["id"]))
            self.log("ticket-edit", f"#{d['id']} {d['status']}")
            return d["id"]
        tid = self.x("INSERT INTO tickets(client_id,title,detail,category,priority,status,assigned,created,updated) "
                     "VALUES(?,?,?,?,?,?,?,?,?)", (d.get("client_id"), d["title"], d.get("detail", ""), d.get("category", "Other"),
                                                   d.get("priority", "Normal"), d.get("status", "Open"), d.get("assigned", ""), ts, ts))
        self.log("ticket-add", f"#{tid} {d['title']}")
        return tid

    def delete_ticket(self, tid):
        self.x("DELETE FROM tickets WHERE id=?", (tid,))
        self.log("ticket-delete", f"#{tid}")

    def ticket_counts(self):
        r = self.one("SELECT SUM(status='Open') AS o, SUM(status='In progress') AS p FROM tickets") or {}
        return int(r.get("o") or 0), int(r.get("p") or 0)

    # ---- message log -------------------------------------------------------------------------------------
    def log_msg(self, phone, channel, text, result):
        self.x("INSERT INTO sms_log(ts,phone,channel,text,result) VALUES(?,?,?,?,?)", (now(), phone, channel, text, result))

    def msg_log(self, limit=300):
        return self.q("SELECT * FROM sms_log ORDER BY id DESC LIMIT ?", (limit,))

    # ---- automatic daily backup ----------------------------------------------------------------------------
    def auto_backup(self, keep=14):
        """One database copy per day in <data dir>/backups/ ; keeps the newest `keep`. Returns the path when a new one was made."""
        folder = self.dir / "backups"
        folder.mkdir(exist_ok=True)
        dest = folder / f"isp-auto-{time.strftime('%Y%m%d')}.db"
        made = None
        if not dest.exists():
            self.backup(dest)
            made = dest
        olds = sorted(folder.glob("isp-auto-*.db"))
        for old in olds[:-max(int(keep), 1)]:
            old.unlink(missing_ok=True)
        return made

    # ---- router sync helpers -----------------------------------------------------------------------------
    def apply_router_state(self, router, secrets, active, import_new=True, mark_missing=True):
        """secrets: list of PPP secret dicts (or None when the protocol cannot read them).
        active: {pppoe_name: {address, uptime}}. Returns dict(new=, updated=, missing=, online=)."""
        stat = dict(new=0, updated=0, missing=0, online=0)
        ts = now()
        with self.lock:
            if secrets is not None:
                seen = set()
                for s in secrets:
                    name = s.get("name", "")
                    if not name or s.get("service") not in (None, "", "any", "pppoe"):
                        continue
                    seen.add(name)
                    cur = self.find_client(router, name)
                    st = "suspended" if s.get("disabled") == "true" else "active"
                    if cur:
                        self.x("UPDATE clients SET on_router=1, router_note=?, router_profile=?, updated=updated WHERE id=?",
                               (s.get("comment", ""), s.get("profile", ""), cur["id"]))
                        # router is the source of truth for password / package only when still empty locally
                        if not cur["pppoe_pass"] and s.get("password"):
                            self.x("UPDATE clients SET pppoe_pass=? WHERE id=?", (s["password"], cur["id"]))
                        if not cur["package"] and s.get("profile"):
                            self.x("UPDATE clients SET package=? WHERE id=?", (s["profile"], cur["id"]))
                        if cur["status"] != "disabled" and cur["status"] != st:
                            self.x("UPDATE clients SET status=? WHERE id=?", (st, cur["id"]))
                            stat["updated"] += 1
                    elif import_new:
                        pk = self.one("SELECT price FROM packages WHERE name=? OR mt_profile=?", (s.get("profile", ""), s.get("profile", "")))
                        self.x("INSERT INTO clients(router,pppoe_id,pppoe_pass,package,bill,name,status,on_router,router_note,"
                               "router_profile,join_date,created,updated) VALUES(?,?,?,?,?,?,?,1,?,?,?,?,?)",
                               (router, name, s.get("password", ""), s.get("profile", ""), (pk or {}).get("price", 0),
                                s.get("comment", ""), st, s.get("comment", ""), s.get("profile", ""), ts[:10], ts, ts))
                        stat["new"] += 1
                if mark_missing:
                    for c in self.q("SELECT id,pppoe_id FROM clients WHERE router=? AND on_router=1", (router,)):
                        if c["pppoe_id"] not in seen:
                            self.x("UPDATE clients SET on_router=0 WHERE id=?", (c["id"],))
                            stat["missing"] += 1
            self.x("UPDATE clients SET online=0, ip='', uptime='' WHERE router=?", (router,))
            for name, info in active.items():
                self.x("UPDATE clients SET online=1, ip=?, uptime=?, last_seen=? WHERE router=? AND pppoe_id=?",
                       (info.get("address", ""), info.get("uptime", ""), ts, router, name))
                stat["online"] += 1
        return stat

    # ---- backup / export -------------------------------------------------------------------------------------
    def backup(self, dest):
        with self.lock:
            out = sqlite3.connect(dest)
            self.cx.backup(out)
            out.close()

    def restore(self, src):
        with self.lock:
            self.cx.close()
            shutil.copyfile(src, self.path)
            self._open()

    def export_csv(self, path, rows, cols):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:      # utf-8-sig: opens correctly in Excel (Bangla)
            w = csv.writer(f)
            w.writerow(cols)
            for r in rows:
                w.writerow([r.get(c, "") for c in cols])
