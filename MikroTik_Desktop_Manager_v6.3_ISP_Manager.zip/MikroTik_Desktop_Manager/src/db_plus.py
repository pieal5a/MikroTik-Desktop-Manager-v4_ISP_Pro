"""v6 database additions (mixed into db.DB): per-client bandwidth usage, client extras (ONU / OLT port / map / due-day /
grace / exempt), one-time charges, collector hand-overs (cash book), equipment inventory, aging analysis and the
router / data-health audit queries."""
import time

SCHEMA_PLUS = """
CREATE TABLE IF NOT EXISTS usage(client_id INTEGER NOT NULL, day TEXT NOT NULL, rx REAL DEFAULT 0, tx REAL DEFAULT 0,
  PRIMARY KEY(client_id, day));
CREATE TABLE IF NOT EXISTS client_meta(client_id INTEGER PRIMARY KEY, onu_mac TEXT DEFAULT '', olt_port TEXT DEFAULT '',
  conn_type TEXT DEFAULT '', lat TEXT DEFAULT '', lng TEXT DEFAULT '', referrer TEXT DEFAULT '', due_day INTEGER DEFAULT 0,
  grace_days INTEGER DEFAULT 0, exempt INTEGER DEFAULT 0, install_fee REAL DEFAULT 0, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS charges(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, month TEXT NOT NULL,
  title TEXT DEFAULT '', amount REAL DEFAULT 0, created TEXT);
CREATE TABLE IF NOT EXISTS handovers(id INTEGER PRIMARY KEY, day TEXT NOT NULL, collector TEXT DEFAULT '',
  amount REAL NOT NULL, note TEXT DEFAULT '', created TEXT);
CREATE TABLE IF NOT EXISTS inventory(id INTEGER PRIMARY KEY, item TEXT NOT NULL, kind TEXT DEFAULT 'Other', model TEXT DEFAULT '',
  serial TEXT DEFAULT '', qty INTEGER DEFAULT 1, status TEXT DEFAULT 'In stock', client_id INTEGER, cost REAL DEFAULT 0,
  note TEXT DEFAULT '', created TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS router_stats(id INTEGER PRIMARY KEY, ts TEXT, router TEXT, total INTEGER DEFAULT 0, active INTEGER DEFAULT 0,
  disabled INTEGER DEFAULT 0, cpu INTEGER DEFAULT 0, mem REAL DEFAULT 0);
CREATE INDEX IF NOT EXISTS ix_rs_ts ON router_stats(ts);
CREATE INDEX IF NOT EXISTS ix_usage_day ON usage(day);
CREATE INDEX IF NOT EXISTS ix_pay_by ON payments(received_by);
"""
NEW_CLIENT_COLUMNS = {"router_profile": "TEXT DEFAULT ''", "disabled_at": "TEXT DEFAULT ''"}
META_FIELDS = ("onu_mac", "olt_port", "conn_type", "lat", "lng", "referrer", "due_day", "grace_days", "exempt", "install_fee", "note")
CONN_TYPES = ["", "Fiber (GPON/EPON)", "Fiber (media converter)", "UTP / LAN", "Wireless / Radio", "Other"]
INV_KINDS = ["ONU / ONT", "Router", "Switch", "Media converter", "SFP module", "Fiber cable (m)", "Patch cord", "Splitter", "Other"]
INV_STATUS = ["In stock", "Assigned", "Faulty", "Returned", "Sold"]


def _month_diff(a, b):
    """months from a to b ('YYYY-MM')."""
    return (int(b[:4]) - int(a[:4])) * 12 + int(b[5:7]) - int(a[5:7])


class PlusMixin:
    def _migrate_plus(self):
        self.cx.executescript(SCHEMA_PLUS)
        have = {r[1] for r in self.cx.execute("PRAGMA table_info(clients)").fetchall()}
        for col, decl in NEW_CLIENT_COLUMNS.items():
            if col not in have:
                self.cx.execute(f"ALTER TABLE clients ADD COLUMN {col} {decl}")
        self.cx.commit()

    # ---- router totals, profiles -> packages, auto bill fill, outage detection, insights ------------------------
    def add_router_stat(self, router, total, active, disabled, cpu, mem):
        self.x("INSERT INTO router_stats(ts,router,total,active,disabled,cpu,mem) VALUES(?,?,?,?,?,?,?)",
               (time.strftime("%Y-%m-%d %H:%M:%S"), router, int(total or 0), int(active or 0), int(disabled or 0), int(cpu or 0), float(mem or 0)))
        cut = time.strftime("%Y-%m-%d", time.localtime(time.time() - 60 * 86400))
        self.x("DELETE FROM router_stats WHERE ts<? AND id%20=0", (cut,))

    def online_trend(self, hours=24):
        cut = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - hours * 3600))
        return self.q("SELECT h, SUM(a) AS online FROM (SELECT substr(ts,1,13) AS h, router, AVG(active) AS a FROM router_stats "
                      "WHERE ts>=? GROUP BY h, router) GROUP BY h ORDER BY h", (cut,))

    def totals(self):
        c = self.one("SELECT COUNT(*) AS total, SUM(status='active') AS active, SUM(status='suspended') AS suspended, "
                     "SUM(status='disabled') AS disabled, SUM(online=1) AS online, SUM(on_router=0 AND router!='' AND status!='disabled') AS missing, "
                     "COALESCE(SUM(CASE WHEN status='active' THEN bill ELSE 0 END),0) AS mrr FROM clients")
        return {k: (v or 0) for k, v in c.items()}

    def per_router_counts(self):
        return {r["router"]: r for r in self.q(
            "SELECT router, COUNT(*) AS clients, SUM(status='active') AS active, SUM(status='suspended') AS suspended, SUM(online=1) AS online, "
            "COALESCE(SUM(CASE WHEN status='active' THEN bill ELSE 0 END),0) AS mrr FROM clients GROUP BY router")}

    def sync_profiles(self, profiles):
        """PPP profiles on the router -> packages (new ones get price 0; existing price is never touched). Returns #new."""
        n = 0
        for p in profiles or []:
            name = (p.get("name") or "").strip()
            if not name or name in ("default", "default-encryption"):
                continue
            rate = (p.get("rate-limit") or "").strip()
            speed = (rate.split(" ")[0].split("/")[-1]) if rate else ""
            cur = self.one("SELECT * FROM packages WHERE name=? OR mt_profile=?", (name, name))
            if cur:
                if speed and not cur["speed"]:
                    self.x("UPDATE packages SET speed=? WHERE id=?", (speed, cur["id"]))
                if not cur["mt_profile"]:
                    self.x("UPDATE packages SET mt_profile=? WHERE id=?", (name, cur["id"]))
            else:
                self.x("INSERT INTO packages(name,speed,price,mt_profile) VALUES(?,?,0,?)", (name, speed, name))
                n += 1
        if n:
            self.log("packages-imported", f"{n} new from router profiles")
        return n

    def fill_missing_bills(self):
        """Clients with bill 0 whose package now has a price get that price (router profile -> package -> bill)."""
        self.x("UPDATE clients SET bill=(SELECT p.price FROM packages p WHERE p.price>0 AND (p.name=clients.package OR p.mt_profile=clients.package) LIMIT 1) "
               "WHERE bill<=0 AND package!='' AND EXISTS(SELECT 1 FROM packages p WHERE p.price>0 AND (p.name=clients.package OR p.mt_profile=clients.package))")

    def online_by_zone(self, router):
        return {r["z"]: (r["n"], r["o"] or 0) for r in self.q(
            "SELECT CASE WHEN zone='' THEN '(no zone)' ELSE zone END AS z, COUNT(*) AS n, SUM(online) AS o FROM clients "
            "WHERE router=? AND status='active' GROUP BY 1", (router,))}

    def payer_scores(self, due_day=10):
        """Clients who usually pay late: average day-of-month of their last 6 payments is well past the due day."""
        cut = time.strftime("%Y-%m-%d", time.localtime(time.time() - 190 * 86400))
        rows = self.q("SELECT c.id, c.pppoe_id, c.name, c.phone1, COUNT(*) AS n, AVG(CAST(substr(p.paid_at,9,2) AS INTEGER)) AS avg_day "
                      "FROM payments p JOIN clients c ON c.id=p.client_id WHERE substr(p.paid_at,1,10)>=? AND p.method!='' AND c.status!='disabled' "
                      "GROUP BY c.id HAVING n>=3", (cut,))
        late = [r for r in rows if r["avg_day"] > due_day + 4]
        return sorted(late, key=lambda r: -r["avg_day"])

    def insights(self, due_day=10):
        """[(level, text)] smart observations: forecast, peak hour, late payers, outages, data problems."""
        out, cur = [], time.strftime("%Y-%m")
        t = self.totals()
        effs = []
        for i in (1, 2, 3):
            m = f"{int(cur[:4]) + (int(cur[5:7]) - 1 - i) // 12:04d}-{(int(cur[5:7]) - 1 - i) % 12 + 1:02d}"
            a = self.analytics(m)
            if a["expected"]:
                effs.append(a["efficiency"])
        if effs:
            eff = sum(effs) / len(effs)
            out.append(("info", f"Forecast: monthly recurring revenue ৳{t['mrr']:,.0f}; at your last-3-month collection rate ({eff:.0f}%) "
                                f"expect about ৳{t['mrr'] * eff / 100:,.0f} collected, ৳{t['mrr'] * (100 - eff) / 100:,.0f} left as due."))
        tr = self.q("SELECT substr(ts,12,2) AS hr, AVG(s) AS a FROM (SELECT ts, SUM(active) AS s FROM router_stats WHERE ts>=? GROUP BY ts) GROUP BY hr "
                    "ORDER BY a DESC LIMIT 1", (time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400)),))
        if tr and tr[0]["a"] >= 1:
            out.append(("info", f"Peak hour: around {tr[0]['hr']}:00 with ~{tr[0]['a']:.0f} users online (last 7 days)."))
        late = self.payer_scores(due_day)
        if late:
            names = ", ".join(f"{r['pppoe_id']} (~day {r['avg_day']:.0f})" for r in late[:5])
            out.append(("warn", f"{len(late)} client(s) usually pay late — remind them early. Top: {names}"))
        for r in self.q("SELECT ts, detail FROM audit WHERE action IN ('outage','outage-restored') AND ts>=? ORDER BY id DESC LIMIT 5",
                        (time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400)),)):
            out.append(("bad" if True else "", f"{r['ts'][5:16]}  {r['detail']}"))
        if t["missing"]:
            out.append(("warn", f"{t['missing']} client(s) exist here but not on their router (see Router & Data Audit)."))
        z = self.one("SELECT COUNT(*) AS n FROM clients WHERE status='active' AND bill<=0")["n"]
        if z:
            out.append(("warn", f"{z} active client(s) have bill 0 — set the package price in Packages; bills fill in automatically."))
        z = self.one("SELECT COUNT(*) AS n FROM packages WHERE price<=0")["n"]
        if z:
            out.append(("warn", f"{z} package(s) imported from router profiles still have price 0."))
        if not out:
            out.append(("ok", "Nothing to flag yet — insights appear after a few syncs."))
        return out

    # ---- bandwidth usage ---------------------------------------------------------------------------------
    def add_usage_many(self, rows):
        """rows: [(client_id, day, rx_bytes, tx_bytes)] — one transaction, accumulates into the day's total."""
        if not rows:
            return
        with self.lock:
            self.cx.executemany("INSERT INTO usage(client_id,day,rx,tx) VALUES(?,?,?,?) ON CONFLICT(client_id,day) "
                                "DO UPDATE SET rx=rx+excluded.rx, tx=tx+excluded.tx", rows)
            self.cx.commit()

    def usage_month(self, month, router="", search=""):
        sql = ("SELECT c.id, c.pppoe_id, c.name, c.router, c.package, c.online, SUM(u.rx) AS rx, SUM(u.tx) AS tx "
               "FROM usage u JOIN clients c ON c.id=u.client_id WHERE substr(u.day,1,7)=?")
        args = [month]
        if router:
            sql += " AND c.router=?"; args.append(router)
        if search:
            sql += " AND (c.pppoe_id LIKE ? OR c.name LIKE ?)"; args += [f"%{search}%"] * 2
        return self.q(sql + " GROUP BY c.id ORDER BY SUM(u.rx)+SUM(u.tx) DESC", args)

    def usage_today(self, router=""):
        day = time.strftime("%Y-%m-%d")
        sql = ("SELECT c.id, c.pppoe_id, c.name, c.router, u.rx, u.tx FROM usage u JOIN clients c ON c.id=u.client_id "
               "WHERE u.day=?")
        args = [day]
        if router:
            sql += " AND c.router=?"; args.append(router)
        return self.q(sql + " ORDER BY u.rx+u.tx DESC", args)

    def usage_series(self, cid, days=31):
        return self.q("SELECT day, rx, tx FROM usage WHERE client_id=? ORDER BY day DESC LIMIT ?", (cid, days))[::-1]

    def usage_totals_by_day(self, month):
        return self.q("SELECT day, SUM(rx) AS rx, SUM(tx) AS tx FROM usage WHERE substr(day,1,7)=? GROUP BY day ORDER BY day", (month,))

    def purge_usage(self, keep_days=400):
        cut = time.strftime("%Y-%m-%d", time.localtime(time.time() - keep_days * 86400))
        self.x("DELETE FROM usage WHERE day<?", (cut,))

    # ---- client extras / one-time charges -------------------------------------------------------------------
    def meta(self, cid):
        m = self.one("SELECT * FROM client_meta WHERE client_id=?", (cid,))
        return m or {"client_id": cid, "onu_mac": "", "olt_port": "", "conn_type": "", "lat": "", "lng": "", "referrer": "",
                     "due_day": 0, "grace_days": 0, "exempt": 0, "install_fee": 0, "note": ""}

    def save_meta(self, cid, d):
        vals = [d.get(k, "") for k in META_FIELDS]
        for k in ("due_day", "grace_days", "exempt"):
            vals[META_FIELDS.index(k)] = int(float(d.get(k) or 0))
        vals[META_FIELDS.index("install_fee")] = float(d.get("install_fee") or 0)
        cols = ",".join(META_FIELDS)
        self.x(f"INSERT INTO client_meta(client_id,{cols}) VALUES(?,{','.join('?' * len(META_FIELDS))}) "
               f"ON CONFLICT(client_id) DO UPDATE SET " + ",".join(f"{k}=excluded.{k}" for k in META_FIELDS), [cid] + vals)
        c = self.client(cid) or {}
        self.log("client-extras", f"{c.get('pppoe_id')} ({c.get('router')})")

    def add_charge(self, cid, month, title, amount):
        """One-time charge (installation, ONU / router sale, reconnection fee …) added on top of that month's bill."""
        amount = float(amount)
        b = self.ensure_bill(cid, month)
        self.x("UPDATE bills SET amount=amount+? WHERE id=?", (amount, b["id"]))
        cid_ = self.x("INSERT INTO charges(client_id,month,title,amount,created) VALUES(?,?,?,?,?)",
                      (cid, month, title, amount, time.strftime("%Y-%m-%d %H:%M:%S")))
        self.log("charge", f"client#{cid} {month} {title} {amount:g}")
        return cid_

    def delete_charge(self, chid):
        ch = self.one("SELECT * FROM charges WHERE id=?", (chid,))
        if ch:
            self.x("UPDATE bills SET amount=MAX(amount-?,0) WHERE client_id=? AND month=?", (ch["amount"], ch["client_id"], ch["month"]))
            self.x("DELETE FROM charges WHERE id=?", (chid,))
            self.log("charge-delete", f"#{chid} {ch['title']} {ch['amount']:g}")

    def charges(self, cid):
        return self.q("SELECT * FROM charges WHERE client_id=? ORDER BY id DESC", (cid,))

    def forget_client_extras(self, cid):
        for t in ("usage", "client_meta", "charges"):
            self.x(f"DELETE FROM {t} WHERE client_id=?", (cid,))
        self.x("UPDATE inventory SET client_id=NULL, status='Returned' WHERE client_id=?", (cid,))

    # ---- collectors & cash book -------------------------------------------------------------------------------
    def collector_names(self):
        names = {r["n"] for r in self.q("SELECT DISTINCT received_by AS n FROM payments WHERE received_by!=''")}
        names |= {r["n"] for r in self.q("SELECT DISTINCT collector AS n FROM handovers WHERE collector!=''")}
        return sorted(names)

    def cashbook(self, day_from, day_to):
        """Per-collector, per-method collection between two dates (inclusive)."""
        return self.q("SELECT CASE WHEN received_by='' THEN '(unknown)' ELSE received_by END AS collector, method, COUNT(*) AS n, "
                      "SUM(amount) AS total FROM payments WHERE substr(paid_at,1,10) BETWEEN ? AND ? GROUP BY 1,2 ORDER BY 1,2",
                      (day_from, day_to))

    def cash_balance(self):
        """Cash payments collected − cash handed over, per collector (all time). Only the 'Cash' method needs hand-over."""
        coll = {r["c"]: r["s"] for r in self.q("SELECT CASE WHEN received_by='' THEN '(unknown)' ELSE received_by END AS c, "
                                                "SUM(amount) AS s FROM payments WHERE method='Cash' GROUP BY 1")}
        hand = {r["c"]: r["s"] for r in self.q("SELECT CASE WHEN collector='' THEN '(unknown)' ELSE collector END AS c, "
                                                "SUM(amount) AS s FROM handovers GROUP BY 1")}
        out = []
        for name in sorted(set(coll) | set(hand)):
            out.append(dict(collector=name, collected=coll.get(name, 0.0), handed=hand.get(name, 0.0),
                            pending=coll.get(name, 0.0) - hand.get(name, 0.0)))
        return out

    def add_handover(self, day, collector, amount, note=""):
        hid = self.x("INSERT INTO handovers(day,collector,amount,note,created) VALUES(?,?,?,?,?)",
                     (day, collector, float(amount), note, time.strftime("%Y-%m-%d %H:%M:%S")))
        self.log("handover", f"{collector} {float(amount):g} on {day}")
        return hid

    def handovers(self, month=None):
        if month:
            return self.q("SELECT * FROM handovers WHERE substr(day,1,7)=? ORDER BY day DESC, id DESC", (month,))
        return self.q("SELECT * FROM handovers ORDER BY day DESC, id DESC LIMIT 500")

    def delete_handover(self, hid):
        self.x("DELETE FROM handovers WHERE id=?", (hid,))
        self.log("handover-delete", f"#{hid}")

    def day_payments(self, day):
        return self.q("SELECT p.*, c.pppoe_id, c.name FROM payments p LEFT JOIN clients c ON c.id=p.client_id "
                      "WHERE substr(p.paid_at,1,10)=? ORDER BY p.id", (day,))

    # ---- inventory ----------------------------------------------------------------------------------------------
    def inventory(self, status="", search=""):
        sql = ("SELECT i.*, c.pppoe_id, c.name AS client_name FROM inventory i LEFT JOIN clients c ON c.id=i.client_id WHERE 1=1")
        args = []
        if status:
            sql += " AND i.status=?"; args.append(status)
        if search:
            sql += " AND (i.item LIKE ? OR i.model LIKE ? OR i.serial LIKE ? OR c.pppoe_id LIKE ? OR c.name LIKE ?)"
            args += [f"%{search}%"] * 5
        return self.q(sql + " ORDER BY i.kind, i.item, i.id", args)

    def save_inventory(self, d):
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        vals = (d["item"], d.get("kind", "Other"), d.get("model", ""), d.get("serial", ""), int(float(d.get("qty") or 1)),
                d.get("status", "In stock"), d.get("client_id") or None, float(d.get("cost") or 0), d.get("note", ""))
        if d.get("id"):
            self.x("UPDATE inventory SET item=?,kind=?,model=?,serial=?,qty=?,status=?,client_id=?,cost=?,note=?,updated=? WHERE id=?",
                   vals + (ts, d["id"]))
            self.log("inventory-edit", f"#{d['id']} {d['item']}")
            return d["id"]
        iid = self.x("INSERT INTO inventory(item,kind,model,serial,qty,status,client_id,cost,note,created,updated) "
                     "VALUES(?,?,?,?,?,?,?,?,?,?,?)", vals + (ts, ts))
        self.log("inventory-add", f"#{iid} {d['item']}")
        return iid

    def delete_inventory(self, iid):
        self.x("DELETE FROM inventory WHERE id=?", (iid,))
        self.log("inventory-delete", f"#{iid}")

    def inventory_summary(self):
        return self.q("SELECT kind, status, COUNT(*) AS rows, COALESCE(SUM(qty),0) AS qty, COALESCE(SUM(cost*qty),0) AS value "
                      "FROM inventory GROUP BY kind, status ORDER BY kind, status")

    # ---- aging & analytics -----------------------------------------------------------------------------------------
    def aging(self, upto=None):
        """Outstanding amount by age of the bill month: current, 1, 2, 3+ months old. Returns (buckets, per-client rows)."""
        upto = upto or time.strftime("%Y-%m")
        rows = self.q("SELECT b.client_id, b.month, MAX(b.amount-b.discount-b.paid,0) AS due FROM bills b WHERE b.month<=? "
                      "AND b.amount-b.discount-b.paid>0", (upto,))
        buckets = {"Current month": [0.0, set()], "1 month old": [0.0, set()], "2 months old": [0.0, set()], "3+ months old": [0.0, set()]}
        per = {}
        for r in rows:
            age = _month_diff(r["month"], upto)
            key = ("Current month", "1 month old", "2 months old")[age] if age < 3 else "3+ months old"
            buckets[key][0] += r["due"]
            buckets[key][1].add(r["client_id"])
            p = per.setdefault(r["client_id"], dict(client_id=r["client_id"], total=0.0, oldest=r["month"], months=0))
            p["total"] += r["due"]
            p["months"] += 1
            p["oldest"] = min(p["oldest"], r["month"])
        out = [dict(bucket=k, amount=v[0], clients=len(v[1])) for k, v in buckets.items()]
        info = {c["id"]: c for c in self.q("SELECT id,pppoe_id,name,phone1,router,status FROM clients")}
        det = []
        for cid, p in per.items():
            c = info.get(cid)
            if c:
                det.append(c | p | dict(age=_month_diff(p["oldest"], upto)))
        det.sort(key=lambda x: (-x["age"], -x["total"]))
        return out, det

    def analytics(self, month):
        s = self.one("SELECT COALESCE(SUM(amount-discount),0) AS expected, COALESCE(SUM(paid),0) AS paid, COUNT(*) AS bills "
                     "FROM bills WHERE month=?", (month,))
        active = self.one("SELECT COUNT(*) AS n FROM clients WHERE status='active'")["n"]
        new = self.one("SELECT COUNT(*) AS n FROM clients WHERE substr(join_date,1,7)=?", (month,))["n"]
        lost = self.one("SELECT COUNT(*) AS n FROM clients WHERE substr(disabled_at,1,7)=?", (month,))["n"]
        coll = self.one("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE substr(paid_at,1,7)=?", (month,))["s"]
        exp = self.one("SELECT COALESCE(SUM(amount),0) AS s FROM expenses WHERE substr(day,1,7)=?", (month,))["s"]
        return dict(expected=s["expected"], paid=s["paid"], bills=s["bills"], active=active, new=new, lost=lost, collected=coll,
                    expenses=exp, efficiency=(s["paid"] * 100 / s["expected"]) if s["expected"] else 0,
                    arpu=(s["expected"] / s["bills"]) if s["bills"] else 0, cost_per_client=(exp / active) if active else 0)

    def top_zones_due(self, upto=None):
        upto = upto or time.strftime("%Y-%m")
        return self.q("SELECT CASE WHEN c.zone='' THEN '(no zone)' ELSE c.zone END AS zone, COUNT(DISTINCT c.id) AS clients, "
                      "SUM(MAX(b.amount-b.discount-b.paid,0)) AS due FROM bills b JOIN clients c ON c.id=b.client_id "
                      "WHERE b.month<=? AND b.amount-b.discount-b.paid>0 GROUP BY c.zone ORDER BY due DESC", (upto,))

    # ---- router / data health audit -------------------------------------------------------------------------------------
    def audit_checks(self, due_day=10):
        """Dictionary: check name -> list of client rows (dicts with id,pppoe_id,name,router,detail)."""
        month, today = time.strftime("%Y-%m"), time.localtime().tm_mday
        mk = lambda rows, f: [dict(id=r["id"], pppoe_id=r["pppoe_id"], name=r["name"], router=r["router"], detail=f(r)) for r in rows]
        cl = "SELECT id,pppoe_id,name,router,package,bill,phone1,nid,status,on_router,router_profile,ip FROM clients "
        out = {}
        out["Not on router (create with Push)"] = mk(self.q(cl + "WHERE router!='' AND on_router=0 AND status!='disabled'"),
                                                        lambda r: "exists here, not found on the router's PPP secrets")
        prof = {p["name"]: (p["mt_profile"] or p["name"]) for p in self.packages()}
        mism = []
        for r in self.q(cl + "WHERE on_router=1 AND router_profile!='' AND package!='' AND status!='disabled'"):
            want = prof.get(r["package"], r["package"])
            if want != r["router_profile"]:
                mism.append(r | {"want": want})
        out["Package ≠ router PPP profile"] = mk(mism, lambda r: f"package '{r['package']}' → profile '{r['want']}' but router has '{r['router_profile']}'")
        out["Overdue but still active"] = mk(self.q(
            cl + "WHERE status='active' AND id IN (SELECT client_id FROM bills WHERE amount-discount-paid>0 AND (month<? OR (month=? AND ?>?)))",
            (month, month, today, due_day)), lambda r: "has unpaid bill past due day — not suspended")
        out["Suspended but fully paid"] = mk(self.q(
            cl + "WHERE status='suspended' AND id NOT IN (SELECT client_id FROM bills WHERE amount-discount-paid>0 AND month<=?)", (month,)),
            lambda r: "no due left — can be re-enabled")
        out["Same PPPoE ID on several routers"] = mk(self.q(
            cl + "WHERE pppoe_id IN (SELECT pppoe_id FROM clients GROUP BY pppoe_id HAVING COUNT(DISTINCT router)>1) ORDER BY pppoe_id"),
            lambda r: "duplicate ID across routers")
        out["No phone number"] = mk(self.q(cl + "WHERE phone1='' AND status!='disabled'"), lambda r: "phone 1 empty")
        out["No NID"] = mk(self.q(cl + "WHERE nid='' AND status!='disabled'"), lambda r: "NID empty")
        out["Active with bill = 0 or no package"] = mk(self.q(cl + "WHERE status='active' AND (bill<=0 OR package='')"),
                                                        lambda r: f"bill {r['bill']:g}, package '{r['package']}'")
        out["Duplicate phone number"] = mk(self.q(
            cl + "WHERE phone1!='' AND phone1 IN (SELECT phone1 FROM clients WHERE phone1!='' GROUP BY phone1 HAVING COUNT(*)>1) ORDER BY phone1"),
            lambda r: f"phone {r['phone1']} used by more than one client")
        out["Not seen online for 30+ days"] = mk(self.q(
            cl + "WHERE status='active' AND online=0 AND last_seen!='' AND last_seen<?",
            (time.strftime("%Y-%m-%d", time.localtime(time.time() - 30 * 86400)),)), lambda r: "inactive line — maybe disconnect?")
        return out
