"""Shared helpers for the ISP pages: media (photo / NID / camera), receipts, small dialogs."""
import html
import tempfile
import time
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import ttk, messagebox, filedialog

from core import *

BRAND = dict(owner="Arafath Rahman (Pieal)", title="CEO & CTO", company="CloudCore Network", site="www.ccn.isp-bd.com")
METHODS = ["Cash", "bKash", "Nagad", "Rocket", "Bank", "Card", "Other"]
STATUS_LABEL = {"active": "Active", "suspended": "Suspended", "disabled": "Inactive"}


def money(v):
    try:
        v = float(v or 0)
    except (TypeError, ValueError):
        return str(v)
    return f"{v:,.0f}" if abs(v - round(v)) < 0.005 else f"{v:,.2f}"


def try_pil():
    try:
        from PIL import Image, ImageTk
        return Image, ImageTk
    except ImportError:
        return None, None


def load_photo(path, box=(150, 150)):
    """Return a Tk image for a picture file, or None. Uses Pillow when installed (jpg/png/…), else tk.PhotoImage (png/gif)."""
    if not path or not Path(path).exists():
        return None
    Image, ImageTk = try_pil()
    try:
        if Image:
            im = Image.open(path)
            im.thumbnail(box)
            return ImageTk.PhotoImage(im)
        img = tk.PhotoImage(file=str(path))
        f = max(img.width() // box[0], img.height() // box[1], 1)
        return img.subsample(f, f) if f > 1 else img
    except Exception:
        return None


def capture_camera(parent, app, dest_stem):
    """Live camera preview + capture (needs: pip install opencv-python pillow). Returns the saved path or None."""
    try:
        import cv2
    except ImportError:
        messagebox.showinfo("Camera not available", "Camera capture needs two optional packages:\n\n"
                            "    pip install opencv-python pillow\n\nYou can still use ‘Upload file’.", parent=parent)
        return None
    Image, ImageTk = try_pil()
    if not Image:
        messagebox.showinfo("Pillow missing", "Run:  pip install pillow", parent=parent)
        return None
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW) if hasattr(cv2, "CAP_DSHOW") else cv2.VideoCapture(0)
    if not cap.isOpened():
        messagebox.showerror("Camera", "No camera found (or it is used by another program).", parent=parent)
        return None
    win = tk.Toplevel(parent)
    win.title("Camera")
    win.configure(bg=BG)
    win.transient(parent)
    lab = tk.Label(win, bg="black")
    lab.pack(padx=10, pady=10)
    state = {"frame": None, "path": None, "stop": False}

    def tick():
        if state["stop"]:
            return
        ok, fr = cap.read()
        if ok:
            state["frame"] = fr
            rgb = cv2.cvtColor(fr, cv2.COLOR_BGR2RGB)
            im = Image.fromarray(rgb)
            im.thumbnail((640, 480))
            tkimg = ImageTk.PhotoImage(im)
            lab.configure(image=tkimg)
            lab.image = tkimg
        win.after(40, tick)

    def snap():
        if state["frame"] is None:
            return
        path = Path(tempfile.gettempdir()) / f"{dest_stem}_{int(time.time())}.jpg"
        cv2.imwrite(str(path), state["frame"])
        state["path"] = path
        close()

    def close():
        state["stop"] = True
        cap.release()
        win.destroy()
    bar = tk.Frame(win, bg=BG)
    bar.pack(pady=(0, 10))
    app.button(bar, "● Capture", snap, True).pack(side="left", padx=6)
    app.button(bar, "Cancel", close).pack(side="left", padx=6)
    win.protocol("WM_DELETE_WINDOW", close)
    tick()
    win.grab_set()
    parent.wait_window(win)
    return state["path"]


def pick_file(parent, title, images_only=True):
    types = [("Images", "*.jpg *.jpeg *.png *.gif *.bmp *.webp")] if images_only else \
        [("Images / PDF", "*.jpg *.jpeg *.png *.gif *.bmp *.webp *.pdf"), ("All files", "*.*")]
    return filedialog.askopenfilename(title=title, filetypes=types, parent=parent) or None


def open_path(path):
    import os
    import subprocess
    import sys
    try:
        if sys.platform == "win32":
            os.startfile(str(path))
        elif sys.platform == "darwin":
            subprocess.Popen(["open", str(path)])
        else:
            subprocess.Popen(["xdg-open", str(path)])
    except Exception as e:
        messagebox.showerror("Open file", str(e))


def receipt_html(client, pay, bill, settings):
    """A printable HTML receipt (open in browser → Print / Save as PDF)."""
    co = html.escape(settings.get("company", BRAND["company"]))
    e = lambda v: html.escape(str(v or ""))
    return f"""<!doctype html><meta charset="utf-8"><title>Receipt #{pay['id']}</title>
<style>body{{font-family:Segoe UI,Arial,sans-serif;max-width:560px;margin:24px auto;color:#111}}
.h{{text-align:center;border-bottom:2px solid #1d4ed8;padding-bottom:10px}}.h h1{{margin:0;color:#1d4ed8}}
table{{width:100%;border-collapse:collapse;margin-top:14px}}td{{padding:7px 4px;border-bottom:1px solid #ddd}}
td:first-child{{color:#555;width:42%}}.tot td{{font-weight:bold;font-size:1.15em;border-top:2px solid #111}}
.f{{text-align:center;color:#666;font-size:.85em;margin-top:22px}}@media print{{button{{display:none}}}}</style>
<div class="h"><h1>{co}</h1><div>{e(settings.get('site', BRAND['site']))}</div><div>Payment Receipt</div></div>
<table><tr><td>Receipt no.</td><td>#{pay['id']}</td></tr><tr><td>Date</td><td>{e(pay['paid_at'])}</td></tr>
<tr><td>Client</td><td>{e(client.get('name'))}</td></tr><tr><td>PPPoE ID</td><td>{e(client.get('pppoe_id'))}</td></tr>
<tr><td>Phone</td><td>{e(client.get('phone1'))}</td></tr><tr><td>Package</td><td>{e(client.get('package'))}</td></tr>
<tr><td>Bill month</td><td>{e(pay['month'])}</td></tr><tr><td>Monthly bill</td><td>{money(bill['amount'])}</td></tr>
<tr><td>Method</td><td>{e(pay['method'])} {e(pay['trx'])}</td></tr><tr><td>Received by</td><td>{e(pay['received_by'])}</td></tr>
<tr class="tot"><td>Amount paid</td><td>{money(pay['amount'])}</td></tr>
<tr><td>Remaining due ({e(pay['month'])})</td><td>{money(bill['due'])}</td></tr></table>
<div class="f">Thank you for staying with {co}.<br>{e(BRAND['owner'])} — {e(BRAND['title'])}</div>
<p style="text-align:center"><button onclick="print()">Print</button></p>"""


def show_html(content, stem="report"):
    f = Path(tempfile.gettempdir()) / f"{stem}_{int(time.time())}.html"
    f.write_text(content, encoding="utf-8")
    webbrowser.open(f.as_uri())


def reminder_text(client, due, month, settings):
    tpl = settings.get("sms_template") or ("প্রিয় {name}, আপনার {month} মাসের ইন্টারনেট বিল বকেয়া {due} টাকা। "
                                           "অনুগ্রহ করে পরিশোধ করুন। — {company}")
    return tpl.format(name=client.get("name") or client.get("pppoe_id"), due=money(due), month=month,
                      id=client.get("pppoe_id"), company=settings.get("company", BRAND["company"]))


def wa_link(phone, text):
    import urllib.parse
    p = "".join(ch for ch in (phone or "") if ch.isdigit())
    if p.startswith("01") and len(p) == 11:
        p = "88" + p                                           # Bangladesh mobile → international format
    return f"https://wa.me/{p}?text={urllib.parse.quote(text)}"


def scrolled_tree(parent, columns, widths=None, height=None, **kw):
    """ttk.Treeview with both scrollbars inside a bordered frame. Returns (frame, tree)."""
    wrap = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
    tree = ttk.Treeview(wrap, columns=[c[0] for c in columns], show="headings", height=height or 10, **kw)
    ys = ttk.Scrollbar(wrap, orient="vertical", command=tree.yview)
    xs = ttk.Scrollbar(wrap, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
    ys.pack(side="right", fill="y")
    xs.pack(side="bottom", fill="x")
    tree.pack(fill="both", expand=True)
    for key, title, w, *anc in columns:
        tree.heading(key, text=title)
        tree.column(key, width=w, anchor=(anc[0] if anc else "w"), stretch=False)
    tree.tag_configure("odd", background="#0e1f3d")
    tree.tag_configure("due", foreground=ORANGE)
    tree.tag_configure("bad", foreground=RED)
    tree.tag_configure("ok", foreground=GREEN)
    tree.tag_configure("dim", foreground="#6c8397")
    return wrap, tree
