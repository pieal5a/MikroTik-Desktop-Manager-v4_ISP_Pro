"""Router Sync page (multi-device, API / SSH / Telnet / SNMP), the Add/Edit device dialog, ISP settings & backup page."""
import time
import tkinter as tk
import webbrowser
from tkinter import ttk, messagebox, filedialog

import secret
from core import *
from core import PAGE_KINDS
from isp_common import *
from transport import PROTOS, PROTO_LABEL, DEFAULT_PORT, open_link
from ui_kit import GButton, Panel


def proto_of(p):
    return p.get("proto") or ("api-ssl" if p.get("ssl") else "api")


class DeviceDialog(tk.Toplevel):
    def __init__(self, app, cur=None, prefill=None):
        super().__init__(app)
        self.app, self.cur = app, cur
        self.title("Edit device" if cur else "Add device")
        self.configure(bg=BG)
        self.transient(app)
        self.resizable(False, False)
        b = dict(cur or {})
        b.update(prefill or {})
        b.setdefault("proto", proto_of(b))
        self.e = {}
        f = tk.Frame(self, bg=BG)
        f.pack(padx=16, pady=14)

        def lab(r, t):
            tk.Label(f, text=t, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", pady=6, padx=(0, 10))

        def ent(r, key, default="", show=None, width=30):
            lab(r, {"name": "Device name", "host": "Host / IP", "port": "Port", "username": "Username", "pw": "Password",
                    "location": "Location", "snmp_community": "SNMP community", "snmp_port": "SNMP port"}[key])
            w = app.entry(f, width, show=show)
            w.insert(0, str(b.get(key, default)) if key != "pw" else secret.unprotect(b.get("pw", "")))
            w.grid(row=r, column=1, sticky="w", pady=6)
            self.e[key] = w
        ent(0, "name")
        ent(1, "host")
        lab(2, "Connect with")
        self.proto = ttk.Combobox(f, values=list(PROTOS), state="readonly", width=28)
        self.proto.set(PROTO_LABEL.get(b["proto"], "API (8728)"))
        self.proto.grid(row=2, column=1, sticky="w")
        self.proto.bind("<<ComboboxSelected>>", self._proto_changed)
        ent(3, "port", DEFAULT_PORT.get(b["proto"], 8728))
        ent(4, "username", "admin")
        ent(5, "pw", show="•")
        self.save_pw = tk.BooleanVar(value=bool(b.get("save_pw", cur is None)))
        tk.Checkbutton(f, text="Save password (encrypted for this Windows user) — needed for automatic sync", variable=self.save_pw,
                       bg=BG, fg=TEXT, selectcolor=PANEL2, activebackground=BG, activeforeground=CYAN).grid(row=6, column=1, sticky="w")
        ent(7, "location")
        self.sn_title = tk.Label(f, text="SNMP (optional companion — temperature, voltage, per-user traffic)", bg=BG, fg=CYAN,
                                 font=(FONT, 9, "bold"))
        self.sn_title.grid(row=8, column=0, columnspan=2, sticky="w", pady=(12, 0))
        ent(9, "snmp_community", "")
        ent(10, "snmp_port", 161)
        lab(11, "SNMP version")
        self.snv = ttk.Combobox(f, values=["2c", "1"], state="readonly", width=8)
        self.snv.set(b.get("snmp_version", "2c"))
        self.snv.grid(row=11, column=1, sticky="w")
        self.auto = tk.BooleanVar(value=b.get("auto_sync", True))
        tk.Checkbutton(f, text="Include in automatic sync", variable=self.auto, bg=BG, fg=TEXT, selectcolor=PANEL2,
                       activebackground=BG, activeforeground=CYAN).grid(row=12, column=1, sticky="w", pady=6)
        self.result = tk.Label(self, text="", bg=BG, fg=MUTED, font=(FONT, 9), wraplength=430, justify="left")
        self.result.pack(padx=16, anchor="w")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=16, pady=12)
        app.button(bar, "Save device", self.save, True).pack(side="right")
        app.button(bar, "Test connection", self.test).pack(side="right", padx=8)
        self._proto_changed(init=True)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def key(self):
        return PROTOS[self.proto.get()][0]

    def _proto_changed(self, _e=None, init=False):
        k = self.key()
        if not init or not self.e["port"].get():
            self.e["port"].delete(0, "end")
            self.e["port"].insert(0, str(DEFAULT_PORT[k]))
        snmp_main = k == "snmp"
        self.e["username"].configure(state="disabled" if snmp_main else "normal")
        self.e["pw"].configure(state="disabled" if snmp_main else "normal")
        self.sn_title.configure(text="SNMP settings (required)" if snmp_main else
                                "SNMP (optional companion — temperature, voltage, per-user traffic)")
        self.e["snmp_port"].configure(state="disabled" if snmp_main else "normal")
        if snmp_main and not self.e["snmp_community"].get():
            self.e["snmp_community"].insert(0, "public")

    def profile(self):
        g = lambda k: self.e[k].get().strip()
        k = self.key()
        try:
            port = int(g("port"))
            assert 1 <= port <= 65535
        except Exception:
            raise ValueError("Enter a valid port (1-65535).")
        if not g("host"):
            raise ValueError("Host / IP is required.")
        if k != "snmp" and not g("username"):
            raise ValueError("Username is required.")
        p = dict(name=g("name") or g("host"), host=g("host"), port=port, username=g("username"), proto=k, ssl=(k == "api-ssl"),
                 location=g("location"), snmp_community=g("snmp_community"), snmp_version=self.snv.get(),
                 snmp_port=int(g("snmp_port") or 161) if k != "snmp" else port, auto_sync=bool(self.auto.get()),
                 save_pw=bool(self.save_pw.get()))
        if k != "snmp" and self.save_pw.get():
            p["pw"] = secret.protect(self.e["pw"].get())
        return p

    def test(self):
        try:
            p = self.profile()
        except ValueError as e:
            self.result.configure(text=str(e), fg=RED)
            return
        pw = self.e["pw"].get() if p["proto"] != "snmp" else ""
        self.result.configure(text="Testing …", fg=YELLOW)

        def work():
            link = open_link(p, pw, verify_tls=False, timeout=6)
            try:
                s = link.snapshot()
                try:
                    n = len(link.secrets())
                except Exception:
                    n = None
                return s, n
            finally:
                link.close()

        def ok(res):
            s, n = res
            ppp = f"{n} PPP secrets" if n is not None else f"{len(s.get('ppp_active', []))} PPPoE sessions (SNMP)"
            self.result.configure(fg=GREEN, text=f"✔ Connected — {s.get('identity')} • {s.get('board') or s.get('descr', '')[:30]} • "
                                                 f"v{s.get('version') or '?'} • CPU {s.get('cpu')}% • {ppp}")
        self.app.run_async(work, ok, lambda e: self.result.configure(text=f"✘ {e}", fg=RED))

    def save(self):
        try:
            p = self.profile()
        except ValueError as e:
            messagebox.showerror("Device", str(e), parent=self)
            return
        a = self.app
        if self.cur and self.cur in a.profiles:
            if not self.save_pw.get() and "pw" in self.cur:
                pass
            a.profiles[a.profiles.index(self.cur)] = p
            if self.cur["name"] != p["name"]:
                a.db.x("UPDATE clients SET router=? WHERE router=?", (p["name"], self.cur["name"]))
        else:
            a.profiles = [x for x in a.profiles if x["name"] != p["name"]] + [p]
        a.save_profiles()
        a.refresh_profiles(p["name"])
        a.on_sync()
        self.destroy()


# ======================================================================================================
class RoutersPage(Page):
    COLS = [("name", "DEVICE", 130), ("host", "HOST", 115), ("proto", "PROTOCOL", 95), ("state", "STATE", 85), ("ident", "IDENTITY", 120),
            ("ver", "ROUTEROS", 80), ("board", "BOARD", 110), ("cpu", "CPU", 50, "e"), ("mem", "MEM", 50, "e"), ("up", "UPTIME", 90),
            ("ppp", "PPPoE ACT/TOTAL", 105, "e"), ("temp", "TEMP", 55, "e"), ("last", "LAST SYNC", 75), ("msg", "RESULT", 380)]

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Router Sync", "multiple routers • API 8728/8729 • SSH 22 • Telnet 23 • SNMP 161 • automatic sync")
        b = tk.Frame(self, bg=BG)
        b.pack(fill="x", pady=(0, 8))
        for text, fn, col, w in (("＋ Add Device", lambda: DeviceDialog(app), "purple", 115), ("✎ Edit", self.edit, "blue", 80),
                                 ("− Delete", self.delete, "red", 85), ("⟳ Sync Selected", self.sync_sel, "green", 125),
                                 ("⟳ Sync All", self.sync_all, "cyan", 100), ("◎ Scan Network", app.scan_network_dialog, "orange", 125),
                                 ("🔌 WinBox Connect", self.connect, "blue", 135)):
            GButton(b, text, fn, col, max(w, 26 + 7 * len(text)), 30, bg=BG).pack(side="left", padx=(0, 6))
        self.auto = tk.BooleanVar(value=app.settings.get("auto_sync", True))
        tk.Checkbutton(b, text="Auto-sync every", variable=self.auto, command=self.save_auto, bg=BG, fg=TEXT, selectcolor=PANEL2,
                       activebackground=BG, activeforeground=CYAN).pack(side="left", padx=(14, 2))
        self.mins = ttk.Combobox(b, values=["1", "2", "5", "10", "15", "30", "60"], width=4, state="readonly")
        self.mins.set(str(int(app.settings.get("sync_minutes", 5))))
        self.mins.pack(side="left")
        self.mins.bind("<<ComboboxSelected>>", lambda _e: self.save_auto())
        tk.Label(b, text="min", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=4)
        wrap, self.tree = scrolled_tree(self, self.COLS, height=9)
        wrap.pack(fill="both", expand=True)
        self.tree.configure(selectmode="browse")
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self.detail())
        self.tree.bind("<Double-1>", lambda _e: self.edit())
        tk.Label(self, text="Interfaces of the selected router (last sync)", bg=BG, fg=CYAN, font=(FONT, 9, "bold")).pack(anchor="w", pady=(8, 2))
        w2, self.itree = scrolled_tree(self, [("n", "INTERFACE", 170), ("s", "STATE", 80), ("rx", "RX TOTAL", 110, "e"),
                                              ("tx", "TX TOTAL", 110, "e"), ("e", "", 400)], height=6)
        w2.pack(fill="x")
        tk.Label(self, text="SNMP cannot read PPP secrets — use API / SSH / Telnet to import clients. SNMP still gives health, "
                            "traffic and the online PPPoE users.", bg=BG, fg=DIM, font=(FONT, 8)).pack(anchor="w", pady=(6, 0))

    def save_auto(self):
        self.app.settings["auto_sync"] = bool(self.auto.get())
        self.app.settings["sync_minutes"] = float(self.mins.get())
        self.app.apply_settings()

    def on_show(self):
        self.refresh()

    def on_sync(self):
        if self.winfo_ismapped():
            self.refresh()

    def refresh(self):
        sel = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for i, p in enumerate(self.app.profiles):
            s = self.app.sync.status.get(p["name"], {})
            st = s.get("state", "—")
            tag = ["odd"] if i % 2 else []
            tag.append({"ok": "ok", "error": "bad", "no-password": "due"}.get(st, "dim"))
            self.tree.insert("", "end", iid=p["name"], tags=tag, values=(
                p["name"], p["host"], PROTO_LABEL.get(proto_of(p), proto_of(p)), {"ok": "● online", "error": "● error"}.get(st, st),
                s.get("identity", ""), s.get("version", "").split(" ")[0], s.get("board", ""),
                f"{s['cpu']}%" if "cpu" in s else "", f"{s['mem_pct']:.0f}%" if "mem_pct" in s else "", s.get("uptime", ""),
                f"{s.get('ppp_active_n', 0)} / {s.get('ppp_total', 0)}" if st == "ok" else "",
                f"{s['temp']:.0f}°C" if s.get("temp") is not None else "",
                time.strftime("%H:%M:%S", time.localtime(s["ts"])) if s.get("ts") else "", s.get("msg", "")))
        if sel and self.tree.exists(sel[0]):
            self.tree.selection_set(sel[0])
        elif self.tree.get_children():
            self.tree.selection_set(self.tree.get_children()[0])
        self.detail()

    def detail(self):
        self.itree.delete(*self.itree.get_children())
        sel = self.tree.selection()
        s = self.app.sync.status.get(sel[0], {}) if sel else {}
        for i in s.get("ifaces", []):
            self.itree.insert("", "end", values=(i["name"], "up" if i["running"] else ("disabled" if i["disabled"] else "down"),
                                                 fmt_bytes(i["rxb"]), fmt_bytes(i["txb"]), ""), tags=("ok" if i["running"] else "dim",))

    def _cur(self):
        sel = self.tree.selection()
        p = self.app.profile_by_name(sel[0]) if sel else None
        if not p:
            messagebox.showinfo("Select", "Select a device first.", parent=self.app)
        return p

    def edit(self):
        p = self._cur()
        if p:
            DeviceDialog(self.app, p)

    def delete(self):
        p = self._cur()
        if p and messagebox.askyesno("Delete device", f"Delete '{p['name']}'?\nClients stay in the database (router name kept).", parent=self.app):
            self.app.profiles.remove(p)
            self.app.save_profiles()
            self.app.refresh_profiles()
            self.refresh()

    def sync_sel(self):
        p = self._cur()
        if p:
            self.app.sync_now(p)

    def sync_all(self):
        n = 0
        for p in self.app.profiles:
            pw = self.app.get_router_password(p)
            if pw is None:
                continue
            n += bool(self.app.sync.sync(p, password=pw))
        if not self.app.profiles:
            messagebox.showinfo("Sync", "Add a device first.", parent=self.app)

    def connect(self):
        p = self._cur()
        if p:
            self.app.combo.set(p["name"])
            self.app.connect_dialog()


# ======================================================================================================
class ISPSettingsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("ISP Settings & Data", "business details • billing rules • backup • audit log")
        self.vars = {}
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x")
        p1 = Panel(top, "Business & billing", "৳", GREEN, height=330, width=560)
        p1.pack(side="left", fill="y", padx=(0, 10))
        b = p1.body

        def row(r, label, key, default="", width=30):
            tk.Label(b, text=label, bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 10))
            e = app.entry(b, width)
            e.insert(0, str(app.settings.get(key, default)))
            e.grid(row=r, column=1, sticky="w")
            e.bind("<FocusOut>", lambda _e: self.save())
            self.vars[key] = e
        row(0, "Company name", "company", BRAND["company"])
        row(1, "Website", "site", BRAND["site"])
        row(2, "Operator name (on receipts)", "operator", "")
        row(3, "Bills due after day of month", "due_day", 10, 8)
        self.flags = {}
        for r, (k, t, d) in enumerate((("auto_bills", "Create next month's bills automatically", True),
                                       ("auto_suspend", "Auto-SUSPEND overdue clients on the router during sync (careful!)", False)), 4):
            v = tk.BooleanVar(value=app.settings.get(k, d))
            self.flags[k] = v
            tk.Checkbutton(b, text=t, variable=v, command=self.save, bg=CARD, fg=TEXT, selectcolor=CARD2, activebackground=CARD,
                           activeforeground=CYAN).grid(row=r, column=0, columnspan=2, sticky="w", pady=2)
        tk.Label(b, text="Reminder / SMS template  ({name} {due} {month} {id} {company})", bg=CARD, fg=MUTED,
                 font=(FONT, 9)).grid(row=6, column=0, columnspan=2, sticky="w", pady=(8, 2))
        self.tpl = tk.Text(b, height=3, width=56, bg=CARD2, fg=TEXT, insertbackground=CYAN, relief="flat", font=(FONT, 9))
        self.tpl.insert("1.0", app.settings.get("sms_template") or "প্রিয় {name}, আপনার {month} মাসের ইন্টারনেট বিল বকেয়া {due} টাকা। "
                                                                  "অনুগ্রহ করে পরিশোধ করুন। — {company}")
        self.tpl.grid(row=7, column=0, columnspan=2, sticky="w")
        self.tpl.bind("<FocusOut>", lambda _e: self.save())
        p2 = Panel(top, "Data & backup", "⛁", CYAN, height=330)
        p2.pack(side="left", fill="both", expand=True)
        d = p2.body
        tk.Label(d, text=f"Database: {app.db.path}", bg=CARD, fg=MUTED, font=(FONT, 8), wraplength=420, justify="left").pack(anchor="w")
        for text, fn, col in (("💾 Backup database", self.backup, "green"), ("♻ Restore database", self.restore, "orange"),
                              ("📂 Open data folder", lambda: open_path(app.db.dir), "blue")):
            GButton(d, text, fn, col, 190, 30, bg=CARD).pack(anchor="w", pady=4)
        about = (f"MikroTik Manager by  {BRAND['owner']}\n{BRAND['title']} — {BRAND['company']}")
        tk.Label(d, text=about, bg=CARD, fg=TEXT, font=(FONT, 9, "bold"), justify="left").pack(anchor="w", pady=(14, 2))
        link = tk.Label(d, text=BRAND["site"], bg=CARD, fg=BLUE, cursor="hand2", font=(FONT, 9, "underline"))
        link.pack(anchor="w")
        link.bind("<Button-1>", lambda _e: webbrowser.open("https://" + BRAND["site"]))
        tk.Label(self, text="Audit log (latest 500)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w", pady=(10, 2))
        w, self.tree = scrolled_tree(self, [("t", "TIME", 150), ("a", "ACTION", 140), ("d", "DETAIL", 700)])
        w.pack(fill="both", expand=True)

    def on_show(self):
        self.tree.delete(*self.tree.get_children())
        for r in self.app.db.audit():
            self.tree.insert("", "end", values=(r["ts"], r["action"], r["detail"]))

    def save(self):
        s = self.app.settings
        for k, e in self.vars.items():
            v = e.get().strip()
            s[k] = int(v) if k == "due_day" and v.isdigit() else v
        for k, v in self.flags.items():
            s[k] = bool(v.get())
        s["sms_template"] = self.tpl.get("1.0", "end").strip()
        self.app.apply_settings()
        self.app.update_branding()

    def backup(self):
        f = filedialog.asksaveasfilename(defaultextension=".db", initialfile=f"isp-backup-{time.strftime('%Y%m%d-%H%M')}.db", parent=self.app)
        if f:
            self.app.db.backup(f)
            messagebox.showinfo("Backup", "Database saved.\n(Client photos / NID files are in the data folder → files/.)", parent=self.app)

    def restore(self):
        f = filedialog.askopenfilename(filetypes=[("Database", "*.db")], parent=self.app)
        if f and messagebox.askyesno("Restore", "Replace ALL current client / billing data with this backup?", parent=self.app):
            self.app.db.restore(f)
            self.app.db.log("restore", f)
            messagebox.showinfo("Restore", "Done.", parent=self.app)
            self.app.on_sync()


PAGE_KINDS.update({"routers": RoutersPage, "isp_settings": ISPSettingsPage})
