"""Clients page + Add/Edit client dialog (info, documents with upload/camera, billing) + payment form."""
import csv
import random
import string
import threading
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog, simpledialog

import db as dbm
from core import *
from core import PAGE_KINDS
from isp_common import *
from transport import NotSupported
from ui_kit import GButton

CSV_COLS = ["router", "pppoe_id", "pppoe_pass", "package", "bill", "name", "phone1", "phone2", "nid", "address", "zone",
            "join_date", "status", "note"]


def month_choices(back=18, ahead=2):
    cur = dbm.month_now()
    return [f"{m}  {dbm.month_label(m)}" for m in (dbm.add_months(cur, i) for i in range(ahead, -back - 1, -1))]


def mkey(text):
    return (text or "")[:7]


def combo(parent, values, width=22, state="readonly", var=None):
    c = ttk.Combobox(parent, values=values, width=width, state=state, textvariable=var)
    return c


def gen_password(n=8):
    return "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(n))


def supports_secrets(p):
    return bool(p) and p.get("proto", "api") in ("api", "api-ssl", "ssh", "telnet")


# ======================================================================================================
class PayForm(tk.Frame):
    """Month drop-down → shows bill / paid / DUE; amount, discount, method, trx → Receive."""

    def __init__(self, parent, app, cid, on_done=None, month=None):
        super().__init__(parent, bg=BG)
        self.app, self.cid, self.on_done = app, cid, on_done
        db = app.db
        self.c = db.client(cid)
        g = tk.Frame(self, bg=BG)
        g.pack(fill="x", padx=4, pady=4)
        self.month = tk.StringVar()
        opts = month_choices()
        want = month or dbm.month_now()
        self.month.set(next((o for o in opts if o.startswith(want)), opts[2]))
        rows = [("Bill month", None), ("Monthly bill", "bill"), ("Already paid", "paid"), ("DUE", "due")]
        tk.Label(g, text="Bill month", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=0, column=0, sticky="w", pady=4)
        self.mc = combo(g, opts, 26, var=self.month)
        self.mc.grid(row=0, column=1, sticky="w", padx=8)
        self.mc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self.lbl = {}
        for i, (t, k) in enumerate(rows[1:], 1):
            tk.Label(g, text=t, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=i, column=0, sticky="w", pady=2)
            self.lbl[k] = tk.Label(g, text="", bg=BG, fg=TEXT if k != "due" else ORANGE,
                                   font=(FONT, 11 if k != "due" else 13, "bold"))
            self.lbl[k].grid(row=i, column=1, sticky="w", padx=8)
        self.amount, self.disc, self.trx, self.note = (app.entry(g, 16) for _ in range(4))
        self.method = tk.StringVar(value="Cash")
        for r, (t, w) in enumerate((("Amount received", self.amount), ("Discount", self.disc), ("Transaction ID", self.trx),
                                    ("Note", self.note)), 4):
            tk.Label(g, text=t, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", pady=4)
            w.grid(row=r, column=1, sticky="w", padx=8)
        tk.Label(g, text="Method", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=8, column=0, sticky="w", pady=4)
        combo(g, METHODS, 14, var=self.method).grid(row=8, column=1, sticky="w", padx=8)
        self.receipt = tk.BooleanVar(value=True)
        tk.Checkbutton(g, text="Open receipt after saving", variable=self.receipt, bg=BG, fg=TEXT, selectcolor=PANEL2,
                       activebackground=BG, activeforeground=CYAN).grid(row=9, column=0, columnspan=2, sticky="w", pady=2)
        app.button(g, "✔ Receive payment", self.pay, True).grid(row=10, column=0, columnspan=2, sticky="ew", pady=8)
        self.refresh()

    def refresh(self):
        st = self.app.db.bill_status(self.cid, mkey(self.month.get()))
        self.lbl["bill"].configure(text=money(st["amount"]))
        self.lbl["paid"].configure(text=money(st["paid"]))
        self.lbl["due"].configure(text=money(st["due"]), fg=ORANGE if st["due"] else GREEN)
        self.amount.delete(0, "end")
        self.amount.insert(0, f"{st['due']:g}")

    def pay(self):
        try:
            amt, disc = float(self.amount.get() or 0), float(self.disc.get() or 0)
            assert amt > 0 or disc > 0
        except Exception:
            messagebox.showerror("Payment", "Enter a valid amount.", parent=self)
            return
        m = mkey(self.month.get())
        pid = self.app.db.pay(self.cid, m, amt, self.method.get(), self.trx.get().strip(),
                              self.app.settings.get("operator", ""), self.note.get().strip(), disc)
        if self.receipt.get():
            pay = next(p for p in self.app.db.payments(self.cid) if p["id"] == pid)
            show_html(receipt_html(self.c, pay, self.app.db.bill_status(self.cid, m), self.app.settings), "receipt")
        self.refresh()
        self.app.notifier.payment_sms(self.cid, amt, m)
        self.app.after_payment(self.cid)
        if self.on_done:
            self.on_done()


class PayDialog(tk.Toplevel):
    def __init__(self, app, cid, on_done=None, month=None):
        super().__init__(app)
        c = app.db.client(cid)
        self.title(f"Receive payment — {c['name'] or c['pppoe_id']}")
        self.configure(bg=BG)
        self.transient(app)
        tk.Label(self, text=f"{c['pppoe_id']}  •  {c['name']}  •  {c['phone1']}", bg=BG, fg=CYAN,
                 font=(FONT, 10, "bold")).pack(padx=16, pady=(14, 4), anchor="w")
        PayForm(self, app, cid, lambda: (on_done and on_done(), self.destroy()), month).pack(padx=16, pady=8)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)


# ======================================================================================================
class ClientDialog(tk.Toplevel):
    SLOTS = (("photo", "Client Photo"), ("nid_front", "NID — Front"), ("nid_back", "NID — Back"),
             ("other_file", "Other document"))

    def __init__(self, app, cid=None, on_saved=None, prefill=None):
        super().__init__(app)
        self.app, self.cid, self.on_saved = app, cid, on_saved
        self.c = dict(app.db.client(cid) or {}) if cid else dict(prefill or {})
        self.title("Edit client" if cid else "Add client")
        self.configure(bg=BG)
        self.transient(app)
        self.geometry("940x640")
        self.media = {k: None for k, _ in self.SLOTS}        # staged (not yet copied) file paths
        self.removed = set()
        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=12, pady=(12, 4))
        self.t_info, self.t_docs, self.t_bill = (tk.Frame(self.nb, bg=BG) for _ in range(3))
        self.nb.add(self.t_info, text="  👤 Client info  ")
        self.nb.add(self.t_docs, text="  🖼 Photo & NID  ")
        self.nb.add(self.t_bill, text="  💰 Billing & Due  ")
        self._info()
        self._docs()
        self._billing()
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=14, pady=(2, 12))
        app.button(bar, "Save & Close", lambda: self.save(True), True).pack(side="right")
        app.button(bar, "Save", lambda: self.save(False)).pack(side="right", padx=8)
        app.button(bar, "Cancel", self.destroy).pack(side="right")
        self.bind("<Escape>", lambda _e: self.destroy())
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    # -- tab 1 ---------------------------------------------------------------------------------------------------
    def _info(self):
        app, c = self.app, self.c
        f = tk.Frame(self.t_info, bg=BG)
        f.pack(fill="both", expand=True, padx=18, pady=14)
        self.v = {}
        names = [p["name"] for p in app.profiles]
        pk = [p["name"] for p in app.db.packages()]

        def row(r, col, label, key, widget="entry", values=None, width=26, **kw):
            tk.Label(f, text=label, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=col * 3, sticky="w", pady=6, padx=(0, 8))
            if widget == "entry":
                w = app.entry(f, width, **kw)
                w.insert(0, str(c.get(key, "") if c.get(key) is not None else ""))
            else:
                w = ttk.Combobox(f, values=values or [], width=width - 2, state="readonly" if widget == "ro" else "normal")
                w.set(str(c.get(key, "") or ""))
            w.grid(row=r, column=col * 3 + 1, sticky="w", padx=(0, 18))
            self.v[key] = w
            return w
        row(0, 0, "Router", "router", "ro", names)
        row(0, 1, "Status", "status", "ro", ["active", "suspended", "disabled"])
        row(1, 0, "PPPoE ID *", "pppoe_id")
        pw = row(1, 1, "PPPoE Password", "pppoe_pass")
        gen = tk.Label(f, text="⚄ generate", bg=BG, fg=BLUE, cursor="hand2", font=(FONT, 8, "bold"))
        gen.grid(row=2, column=4, sticky="w")
        gen.bind("<Button-1>", lambda _e: (pw.delete(0, "end"), pw.insert(0, gen_password())))
        pkc = row(2, 0, "Package", "package", "combo", pk)
        pkc.bind("<<ComboboxSelected>>", self._pick_package)
        row(2, 1, "Monthly Bill (৳)", "bill")
        row(3, 0, "Client Name *", "name")
        row(3, 1, "Join date (YYYY-MM-DD)", "join_date")
        row(4, 0, "Phone 1", "phone1")
        row(4, 1, "Phone 2", "phone2")
        row(5, 0, "NID number", "nid")
        row(5, 1, "Zone / Area", "zone", "combo", app.db.zones())
        row(6, 0, "Address", "address", width=26)
        row(6, 1, "Note", "note")
        if not self.cid and not self.v["join_date"].get():
            self.v["join_date"].insert(0, time.strftime("%Y-%m-%d"))
        if not self.cid and not self.v["status"].get():
            self.v["status"].set("active")
        if not self.v["router"].get() and len(names) == 1:
            self.v["router"].set(names[0])
        self.push = tk.BooleanVar(value=not self.cid)
        tk.Checkbutton(f, text="Also create / update this PPPoE secret on the router when saving",
                       variable=self.push, bg=BG, fg=TEXT, selectcolor=PANEL2, activebackground=BG,
                       activeforeground=CYAN).grid(row=8, column=0, columnspan=6, sticky="w", pady=(14, 2))
        tk.Label(f, text="(needs API / SSH / Telnet — SNMP is read-only)  •  * required", bg=BG, fg=DIM,
                 font=(FONT, 8)).grid(row=9, column=0, columnspan=6, sticky="w")

    def _pick_package(self, _e=None):
        pk = next((p for p in self.app.db.packages() if p["name"] == self.v["package"].get()), None)
        if pk:
            self.v["bill"].delete(0, "end")
            self.v["bill"].insert(0, f"{pk['price']:g}")

    # -- tab 2 ---------------------------------------------------------------------------------------------------
    def _docs(self):
        self.prev, self.plabels = {}, {}
        grid = tk.Frame(self.t_docs, bg=BG)
        grid.pack(fill="both", expand=True, padx=14, pady=12)
        for i, (key, title) in enumerate(self.SLOTS):
            box = tk.Frame(grid, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            box.grid(row=i // 2, column=i % 2, padx=8, pady=8, sticky="nsew")
            tk.Label(box, text=title, bg=CARD, fg=CYAN, font=(FONT, 10, "bold")).pack(pady=(8, 2))
            lab = tk.Label(box, bg=CARD2, fg=DIM, width=26, height=8, text="no file", font=(FONT, 9))
            lab.pack(padx=10, pady=4)
            self.plabels[key] = lab
            b = tk.Frame(box, bg=CARD)
            b.pack(pady=(2, 8))
            for text, fn in (("⬆ Upload", lambda k=key: self.upload(k)), ("📷 Camera", lambda k=key: self.camera(k)),
                             ("👁 View", lambda k=key: self.view(k)), ("✕", lambda k=key: self.remove(k))):
                self.app.button(b, text, fn).pack(side="left", padx=2)
            self.show(key)
        for i in (0, 1):
            grid.columnconfigure(i, weight=1)
        msg = "Files are copied to the app's data folder (files/<client id>/). Camera needs: pip install opencv-python pillow"
        tk.Label(self.t_docs, text=msg, bg=BG, fg=DIM, font=(FONT, 8)).pack(pady=(0, 6))

    def current(self, key):
        if key in self.removed:
            return None
        if self.media.get(key):
            return Path(self.media[key])
        return self.app.db.file_path(self.c.get(key)) if self.c.get(key) else None

    def show(self, key):
        lab, p = self.plabels[key], self.current(key)
        img = load_photo(p, (190, 130)) if p and p.suffix.lower() not in (".pdf",) else None
        self.prev[key] = img
        if img:
            lab.configure(image=img, text="", width=190, height=130)
        else:
            lab.configure(image="", text=(p.name if p else "no file"), width=26, height=8)

    def upload(self, key):
        f = pick_file(self, "Choose file", images_only=key != "other_file")
        if f:
            self.media[key] = f
            self.removed.discard(key)
            self.show(key)

    def camera(self, key):
        p = capture_camera(self, self.app, key)
        if p:
            self.media[key] = str(p)
            self.removed.discard(key)
            self.show(key)

    def view(self, key):
        p = self.current(key)
        if p and p.exists():
            open_path(p)

    def remove(self, key):
        self.media[key] = None
        self.removed.add(key)
        self.show(key)

    # -- tab 3 ---------------------------------------------------------------------------------------------------
    def _billing(self):
        for w in self.t_bill.winfo_children():
            w.destroy()
        if not self.cid:
            tk.Label(self.t_bill, text="Press “Save” first — then the month drop-down, payments and due list appear here.",
                     bg=BG, fg=MUTED, font=(FONT, 10)).pack(pady=40)
            return
        left = tk.Frame(self.t_bill, bg=BG)
        left.pack(side="left", fill="y", padx=14, pady=10)
        self.pf = PayForm(left, self.app, self.cid, self._billing_changed)
        self.pf.pack()
        right = tk.Frame(self.t_bill, bg=BG)
        right.pack(side="left", fill="both", expand=True, padx=(0, 14), pady=10)
        tk.Label(right, text="Unpaid months (DUE)", bg=BG, fg=ORANGE, font=(FONT, 10, "bold")).pack(anchor="w")
        w1, self.due_tree = scrolled_tree(right, [("m", "MONTH", 150), ("d", "DUE", 90, "e")], height=4)
        w1.pack(fill="x", pady=(2, 8))
        tk.Label(right, text="Payment history", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w2, self.pay_tree = scrolled_tree(right, [("id", "#", 40), ("at", "DATE", 130), ("m", "MONTH", 70), ("a", "AMOUNT", 70, "e"),
                                                  ("me", "METHOD", 70), ("t", "TRX", 90)], height=8)
        w2.pack(fill="both", expand=True, pady=2)
        bb = tk.Frame(right, bg=BG)
        bb.pack(fill="x", pady=4)
        self.app.button(bb, "🖨 Receipt", self.receipt).pack(side="left")
        self.app.button(bb, "🗑 Delete payment", self.del_pay).pack(side="left", padx=6)
        self._billing_changed()

    def _billing_changed(self):
        self.due_tree.delete(*self.due_tree.get_children())
        for d in self.app.db.due_months(self.cid):
            self.due_tree.insert("", "end", values=(dbm.month_label(d["month"]), money(d["due"])), tags=("due",))
        self.pay_tree.delete(*self.pay_tree.get_children())
        for p in self.app.db.payments(self.cid):
            self.pay_tree.insert("", "end", iid=str(p["id"]), values=(p["id"], p["paid_at"][:16], p["month"], money(p["amount"]),
                                                                       p["method"], p["trx"]))
        if self.on_saved:
            self.on_saved()

    def receipt(self):
        sel = self.pay_tree.selection()
        if not sel:
            return
        pay = next(p for p in self.app.db.payments(self.cid) if str(p["id"]) == sel[0])
        show_html(receipt_html(self.app.db.client(self.cid), pay, self.app.db.bill_status(self.cid, pay["month"]),
                               self.app.settings), "receipt")

    def del_pay(self):
        sel = self.pay_tree.selection()
        if sel and messagebox.askyesno("Delete payment", "Delete this payment record? The bill becomes due again.", parent=self):
            self.app.db.delete_payment(int(sel[0]))
            self.pf.refresh()
            self._billing_changed()

    # -- save ------------------------------------------------------------------------------------------------------
    def save(self, close):
        d = {k: (w.get().strip() if hasattr(w, "get") else "") for k, w in self.v.items()}
        if not d["pppoe_id"]:
            messagebox.showerror("Missing", "PPPoE ID is required.", parent=self)
            self.nb.select(self.t_info)
            return
        try:
            d["bill"] = float(d["bill"] or 0)
        except ValueError:
            messagebox.showerror("Invalid", "Monthly bill must be a number.", parent=self)
            return
        db = self.app.db
        clash = db.find_client(d["router"], d["pppoe_id"])
        if clash and clash["id"] != self.cid:
            messagebox.showerror("Duplicate", f"PPPoE ID '{d['pppoe_id']}' already exists on router '{d['router'] or '—'}'.", parent=self)
            return
        for k in ("photo", "nid_front", "nid_back", "other_file"):
            d[k] = "" if k in self.removed else self.c.get(k, "")
        d["id"] = self.cid
        cid = db.save_client(d)
        files = {}
        for k, src in self.media.items():                # copy staged files now that we have an id
            if src and k not in self.removed:
                files[k] = db.attach(cid, k, src)
                self.media[k] = None
        if files:
            db.update_files(cid, files)
        new = self.cid is None
        self.cid, self.c = cid, db.client(cid)
        if self.push.get() and d["router"]:
            self.app.push_clients([cid], quiet=True)
        if self.on_saved:
            self.on_saved()
        if close:
            self.destroy()
        else:
            self.title("Edit client")
            self._billing()
            if new:
                self.nb.select(self.t_bill)


# ======================================================================================================
class ClientsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Clients", "PPPoE customers across all routers • billing • documents")
        self.show_pw = tk.BooleanVar(value=False)
        self.cards = {}
        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", pady=(0, 8))
        for key, title, color in (("total", "Total clients", BLUE), ("active", "Active", GREEN), ("online", "Online now", CYAN),
                                  ("suspended", "Suspended", RED), ("due_clients", "Clients with DUE", ORANGE),
                                  ("total_due", "Total DUE (৳)", ORANGE), ("collected", "Collected this month (৳)", GREEN)):
            c = tk.Frame(row, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            c.pack(side="left", padx=(0, 8), ipadx=10, ipady=4)
            tk.Frame(c, bg=color, height=3).pack(fill="x")
            v = tk.Label(c, text="0", bg=CARD, fg=color, font=(FONT, 15, "bold"))
            v.pack(anchor="w", padx=10)
            tk.Label(c, text=title, bg=CARD, fg=MUTED, font=(FONT, 8)).pack(anchor="w", padx=10)
            self.cards[key] = v
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        self.q = tk.StringVar()
        self.q.trace_add("write", lambda *_: self._later())
        tk.Label(f, text="⌕", bg=BG, fg=MUTED, font=(FONT, 12)).pack(side="left")
        e = app.entry(f, 26)
        e.configure(textvariable=self.q)
        e.pack(side="left", padx=(2, 8), ipady=3)
        self.f_router, self.f_pkg, self.f_zone, self.f_status = (tk.StringVar() for _ in range(4))
        self.f_month = tk.StringVar(value=month_choices()[2])
        self.cb = {}
        for key, var, w in (("router", self.f_router, 14), ("pkg", self.f_pkg, 12), ("zone", self.f_zone, 12)):
            cbx = combo(f, [], w, var=var)
            cbx.pack(side="left", padx=3)
            cbx.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
            self.cb[key] = cbx
        st = combo(f, ["All status", "active", "online", "offline", "suspended", "disabled", "due", "paid", "not-on-router"], 13,
                   var=self.f_status)
        self.f_status.set("All status")
        st.pack(side="left", padx=3)
        st.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        tk.Label(f, text="Due month", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(10, 3))
        mc = combo(f, month_choices(), 18, var=self.f_month)
        mc.pack(side="left")
        mc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        tk.Checkbutton(f, text="show passwords", variable=self.show_pw, command=self.refresh, bg=BG, fg=MUTED, selectcolor=PANEL2,
                       activebackground=BG, activeforeground=CYAN).pack(side="right")
        b = tk.Frame(self, bg=BG)
        b.pack(fill="x", pady=(0, 6))
        for text, fn, col in (("＋ Add Client", self.add, "purple"), ("✎ Edit", self.edit, "blue"), ("💰 Receive Payment", self.pay, "green"),
                              ("⏸ Suspend", lambda: self.set_state(False), "orange"), ("▶ Enable", lambda: self.set_state(True), "cyan"),
                              ("⬆ Push to Router", self.push, "blue"), ("⬇ Pull from Router", self.pull, "cyan"),
                              ("− Remove", self.remove, "red")):
            GButton(b, text, fn, col, 26 + 7 * len(text), 30, bg=BG).pack(side="left", padx=(0, 6))
        mb = tk.Menubutton(b, text="More ▾", bg=PANEL2, fg=TEXT, relief="flat", font=(FONT, 9, "bold"), cursor="hand2",
                           activebackground=BLUE, activeforeground="white")
        m = tk.Menu(mb, tearoff=0, bg=CARD2, fg=TEXT, activebackground=BLUE)
        for label, fn in (("📱 WhatsApp due reminder", self.remind), ("✉ Bulk due reminder (SMS / WhatsApp)", self.bulk_remind),
                          ("💰 Multi-month / advance payment", self.multi_pay), ("📦 Change package (selected)", self.change_pkg),
                          ("📄 Account statement (print)", self.statement), ("🎫 New support ticket", self.new_ticket),
                          ("🧾 Generate bills for month", self.gen_bills),
                          ("⛔ Suspend all overdue (on router)", self.suspend_overdue), ("⬇ Export CSV", self.export),
                          ("⬆ Import CSV", self.import_csv), ("🔧 Client extras (ONU / map / due-day / charges)", self.extras), ("📂 Open documents folder", self.open_docs)):
            m.add_command(label=label, command=fn)
        mb["menu"] = m
        mb.pack(side="left", ipady=3, ipadx=6)
        cols = [("id", "#", 44, "e"), ("pppoe", "PPPOE ID", 120), ("pw", "PASSWORD", 100), ("name", "CLIENT NAME", 160),
                ("p1", "PHONE 1", 105), ("p2", "PHONE 2", 105), ("nid", "NID", 120), ("pkg", "PACKAGE", 95),
                ("bill", "BILL", 70, "e"), ("router", "ROUTER", 110), ("st", "STATUS", 80), ("on", "ONLINE", 80),
                ("ip", "IP", 105), ("mdue", "MONTH DUE", 85, "e"), ("tdue", "TOTAL DUE", 85, "e")]
        wrap, self.tree = scrolled_tree(self, cols)
        wrap.pack(fill="both", expand=True)
        self.tree.configure(selectmode="extended")
        self.tree.bind("<Double-1>", lambda _e: self.edit())
        self.tree.bind("<Button-3>", self._ctx)
        self.menu = tk.Menu(self, tearoff=0, bg=CARD2, fg=TEXT, activebackground=BLUE)
        for label, fn in (("Edit", self.edit), ("Receive payment", self.pay), ("Suspend", lambda: self.set_state(False)),
                          ("Enable", lambda: self.set_state(True)), ("Push to router", self.push), ("WhatsApp reminder", self.remind),
                          ("Multi-month / advance payment", self.multi_pay), ("Change package", self.change_pkg),
                          ("Account statement", self.statement), ("Client extras / charges", self.extras), ("Bandwidth usage", self.usage),
                          ("New support ticket", self.new_ticket), ("Remove", self.remove)):
            self.menu.add_command(label=label, command=fn)
        self.foot = tk.Label(self, text="", bg=BG, fg=MUTED, anchor="w", font=(FONT, 9))
        self.foot.pack(fill="x", pady=(6, 0))
        self._job, self.rows = None, []

    def _ctx(self, e):
        it = self.tree.identify_row(e.y)
        if it:
            if it not in self.tree.selection():
                self.tree.selection_set(it)
            self.menu.tk_popup(e.x_root, e.y_root)

    def _later(self):
        if self._job:
            self.after_cancel(self._job)
        self._job = self.after(250, self.refresh)

    def on_show(self):
        self.refresh()

    def on_sync(self):
        if self.winfo_ismapped():
            self.refresh()

    # -- data ---------------------------------------------------------------------------------------------------------
    def refresh(self):
        app, db = self.app, self.app.db
        names = [p["name"] for p in app.profiles]
        for key, vals, first in (("router", names, "All routers"), ("pkg", [p["name"] for p in db.packages()], "All packages"),
                                 ("zone", db.zones(), "All zones")):
            var = {"router": self.f_router, "pkg": self.f_pkg, "zone": self.f_zone}[key]
            self.cb[key]["values"] = [first] + vals
            if var.get() not in vals:
                var.set(first)
        pick = lambda v: "" if v.startswith("All") else v
        month = mkey(self.f_month.get())
        self.rows = db.clients(self.q.get().strip(), pick(self.f_router.get()), pick(self.f_pkg.get()), pick(self.f_status.get()),
                               month, pick(self.f_zone.get()))
        sel = set(self.tree.selection())
        self.tree.delete(*self.tree.get_children())
        for i, c in enumerate(self.rows):
            tag = ["odd"] if i % 2 else []
            if c["status"] == "disabled":
                tag.append("dim")
            elif c["status"] == "suspended":
                tag.append("bad")
            elif c["total_due"] > 0:
                tag.append("due")
            self.tree.insert("", "end", iid=str(c["id"]), tags=tag, values=(
                c["id"], c["pppoe_id"], c["pppoe_pass"] if self.show_pw.get() else ("•" * min(len(c["pppoe_pass"]), 8) if c["pppoe_pass"] else ""),
                c["name"], c["phone1"], c["phone2"], c["nid"], c["package"], money(c["bill"]), c["router"],
                STATUS_LABEL.get(c["status"], c["status"]), "● online" if c["online"] else "—", c["ip"],
                "" if c["month_due"] is None else money(max(c["month_due"], 0)), money(c["total_due"]) if c["total_due"] else "—"))
        keep = [i for i in self.tree.get_children() if i in sel]
        if keep:
            self.tree.selection_set(keep)
        s = db.summary(month)
        for k, lab in self.cards.items():
            lab.configure(text=money(s.get(k) or 0))
        self.foot.configure(text=f"{len(self.rows)} clients shown  •  bills {money(sum(c['bill'] for c in self.rows))} ৳  •  "
                                 f"total due {money(sum(c['total_due'] for c in self.rows))} ৳  •  month: {dbm.month_label(month)}")

    def selected_ids(self):
        return [int(i) for i in self.tree.selection()]

    def _need(self, many=False):
        ids = self.selected_ids()
        if not ids:
            messagebox.showinfo("Select client", "Select one or more clients first.", parent=self.app)
        return ids

    # -- actions ----------------------------------------------------------------------------------------------------------
    def add(self):
        pre = {}
        if self.f_router.get() and not self.f_router.get().startswith("All"):
            pre["router"] = self.f_router.get()
        ClientDialog(self.app, None, self.refresh, pre)

    def edit(self):
        ids = self.selected_ids()
        if ids:
            ClientDialog(self.app, ids[0], self.refresh)

    def pay(self):
        ids = self.selected_ids()
        if ids:
            PayDialog(self.app, ids[0], self.refresh, mkey(self.f_month.get()))
        else:
            self._need()

    def remove(self):
        ids = self._need()
        if not ids:
            return
        r = messagebox.askyesnocancel("Remove clients", f"Remove {len(ids)} client(s) from this manager?\n\n"
                                      "Yes  = also delete the PPPoE secret on the router\nNo   = remove here only\nCancel = keep",
                                      parent=self.app)
        if r is None:
            return
        if r:
            self.app.router_op(ids, lambda link, c: link.secret_remove(c["pppoe_id"]), "Delete on router",
                               done=lambda ok: self._delete(ids, ok))
        else:
            self._delete(ids, set(ids))

    def _delete(self, ids, ok_ids):
        for i in ids:
            if i in ok_ids:
                self.app.db.delete_client(i)
        self.refresh()

    def set_state(self, enable):
        ids = self._need()
        if not ids:
            return
        status = "active" if enable else "suspended"

        def op(link, c):
            link.secret_enable(c["pppoe_id"], enable)
            if not enable:
                link.kick(c["pppoe_id"])

        def done(ok):
            for i in ids:
                c = self.app.db.client(i)
                if i in ok or not c["on_router"]:          # clients not on any router: just change the status here
                    self.app.db.set_status(i, status)
            self.refresh()
        self.app.router_op(ids, op, "Enable" if enable else "Suspend", done=done, skip_not_on_router=True)

    def push(self):
        ids = self._need()
        if ids:
            self.app.push_clients(ids)

    def pull(self):
        name = self.f_router.get()
        targets = [p for p in self.app.profiles if p["name"] == name] if name and not name.startswith("All") else list(self.app.profiles)
        if not targets:
            messagebox.showinfo("Pull", "Add a router first (Router Sync page).", parent=self.app)
            return
        for p in targets:
            self.app.sync_now(p)
        messagebox.showinfo("Sync started", f"Syncing {len(targets)} router(s) — new PPPoE secrets are imported as clients.\n"
                            "Watch progress on the Router Sync page.", parent=self.app)

    def remind(self):
        ids = self._need()
        if not ids:
            return
        c = self.app.db.client(ids[0])
        month = mkey(self.f_month.get())
        due = sum(d["due"] for d in self.app.db.due_months(c["id"], month))
        if due <= 0:
            messagebox.showinfo("No due", f"{c['name'] or c['pppoe_id']} has no due up to {month}.", parent=self.app)
            return
        if not c["phone1"]:
            messagebox.showinfo("No phone", "This client has no Phone 1.", parent=self.app)
            return
        webbrowser_open(wa_link(c["phone1"], reminder_text(c, due, dbm.month_label(month), self.app.settings)))

    def gen_bills(self):
        m = mkey(self.f_month.get())
        n = self.app.db.generate_bills(m)
        messagebox.showinfo("Bills", f"{n} new bill(s) created for {dbm.month_label(m)}.", parent=self.app)
        self.refresh()

    def suspend_overdue(self):
        ids = []
        for p in self.app.profiles:
            ids += [r["id"] for r in self.app.sync.overdue_ids(p["name"])]
        if not ids:
            messagebox.showinfo("Overdue", f"No overdue active clients (grace: day {self.app.settings.get('due_day', 10)}).", parent=self.app)
            return
        if not messagebox.askyesno("Suspend overdue", f"Disable the PPPoE secret and drop the session of {len(ids)} overdue client(s)?",
                                   parent=self.app):
            return

        def op(link, c):
            link.secret_enable(c["pppoe_id"], False)
            link.kick(c["pppoe_id"])
        self.app.router_op(ids, op, "Suspend overdue", skip_not_on_router=True,
                           done=lambda ok: ([self.app.db.set_status(i, "suspended") for i in ok], self.refresh()))

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="clients.csv", parent=self.app)
        if f:
            self.app.db.export_csv(f, self.rows, CSV_COLS + ["total_due", "online", "ip"])

    def import_csv(self):
        f = filedialog.askopenfilename(filetypes=[("CSV", "*.csv")], parent=self.app)
        if not f:
            return
        n = u = 0
        try:
            with open(f, newline="", encoding="utf-8-sig") as fh:
                for r in csv.DictReader(fh):
                    if not r.get("pppoe_id"):
                        continue
                    cur = self.app.db.find_client(r.get("router", ""), r["pppoe_id"])
                    d = dict(cur or {})
                    d.update({k: (r.get(k) or "").strip() for k in CSV_COLS if k in r})
                    self.app.db.save_client(d)
                    u, n = (u + 1, n) if cur else (u, n + 1)
        except Exception as e:
            messagebox.showerror("Import failed", str(e), parent=self.app)
            return
        messagebox.showinfo("Import", f"{n} added, {u} updated.", parent=self.app)
        self.refresh()

    # ---- v5 actions ---------------------------------------------------------------------------------------------
    def bulk_remind(self):
        from isp_notify import BulkReminderDialog
        BulkReminderDialog(self.app, mkey(self.f_month.get()), "" if self.f_router.get() in ("", "All routers") else self.f_router.get())

    def multi_pay(self):
        ids = self._need()
        if ids:
            import isp_extra
            isp_extra.MultiPayDialog(self.app, ids[0], self.refresh)

    def change_pkg(self):
        ids = self._need(many=True)
        if ids:
            import isp_extra
            isp_extra.BulkPackageDialog(self.app, ids, self.refresh)

    def statement(self):
        ids = self._need()
        if ids:
            import isp_extra
            isp_extra.client_statement(self.app, ids[0])

    def extras(self):
        ids = self._need()
        if ids:
            import isp_plus
            isp_plus.ClientExtrasDialog(self.app, ids[0], self.refresh)

    def usage(self):
        ids = self._need()
        if ids:
            import isp_plus
            isp_plus.UsageDialog(self.app, ids[0])

    def new_ticket(self):
        ids = self._need()
        if ids:
            import isp_extra
            isp_extra.TicketDialog(self.app, None, None, ids[0])

    def open_docs(self):
        ids = self.selected_ids()
        p = self.app.db.files / (str(ids[0]) if ids else "")
        p.mkdir(parents=True, exist_ok=True)
        open_path(p)


def webbrowser_open(url):
    import webbrowser
    webbrowser.open(url)


PAGE_KINDS.update({"clients": ClientsPage})
