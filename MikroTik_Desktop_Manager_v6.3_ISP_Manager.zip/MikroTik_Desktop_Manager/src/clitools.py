"""RouterOS CLI transports: Telnet (TCP 23, pure sockets) and SSH (TCP 22 via paramiko if installed, otherwise
the system `ssh` client with key authentication). Both expose  run(cmd) -> str  and  close()."""
import re
import shutil
import socket
import subprocess
import time

ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b[=>()][A-Za-z0-9]?|\r")
PROMPT = re.compile(r"\[[^\]\r\n]*@[^\]\r\n]*\][^\r\n>]*> ?$")
IAC, DONT, DO, WONT, WILL, SB, SE = 255, 254, 253, 252, 251, 250, 240


class CliError(Exception):
    pass


class TelnetSession:
    def __init__(self, host, port, user, password, timeout=8):
        self.host, self.port, self.user, self.password, self.timeout = host, int(port), user, password, timeout
        self.sock = None

    def connect(self):
        self.sock = socket.create_connection((self.host, self.port), timeout=self.timeout)
        self.sock.settimeout(self.timeout)
        # "+ct512w" = no colours, no terminal detection, wide lines (RouterOS login suffix options)
        self._until(re.compile(r"[Ll]ogin: ?$"))
        self._send(self.user + "+ct512w")
        self._until(re.compile(r"[Pp]assword: ?$"))
        self._send(self.password)
        txt = self._until(PROMPT, fail=re.compile(r"[Ll]ogin: ?$|incorrect|invalid", re.I))
        if re.search(r"incorrect|invalid|failed", txt, re.I):
            raise PermissionError("Telnet login failed — check username / password.")
        return True

    def _send(self, line):
        self.sock.sendall(line.encode() + b"\r\n")

    def _read_chunk(self):
        data = self.sock.recv(4096)
        if not data:
            raise ConnectionError("Router closed the Telnet connection.")
        out, i = bytearray(), 0
        while i < len(data):
            b = data[i]
            if b == IAC and i + 1 < len(data):
                cmd = data[i + 1]
                if cmd in (DO, DONT, WILL, WONT) and i + 2 < len(data):
                    reply = WONT if cmd in (DO, DONT) else DONT
                    self.sock.sendall(bytes([IAC, reply, data[i + 2]]))
                    i += 3
                    continue
                if cmd == SB:
                    j = data.find(bytes([IAC, SE]), i)
                    i = (j + 2) if j >= 0 else len(data)
                    continue
                i += 2
                continue
            out.append(b)
            i += 1
        return out.decode("utf-8", "replace")

    def _until(self, rx, fail=None, limit=60):
        buf, end = "", time.time() + max(self.timeout, limit if limit < 15 else 15)
        while time.time() < end:
            try:
                buf += self._read_chunk()
            except socket.timeout:
                continue
            clean = ANSI.sub("", buf)
            if rx.search(clean.split("\n")[-1] if "\n" in clean else clean):
                return clean
            if fail and fail.search(clean) and clean.rstrip().endswith(":"):
                return clean
        raise CliError("Timed out waiting for the router prompt.")

    def run(self, cmd, timeout=None):
        if timeout:
            self.sock.settimeout(timeout)
        self._send(cmd)
        out = self._until(PROMPT, limit=14)
        lines = out.split("\n")
        body = [ln for ln in lines[1:-1]]          # drop echoed command and trailing prompt
        return "\n".join(body).strip()

    def close(self):
        try:
            if self.sock:
                self._send("/quit")
        except Exception:
            pass
        try:
            if self.sock:
                self.sock.close()
        finally:
            self.sock = None


class SshSession:
    def __init__(self, host, port, user, password, timeout=10):
        self.host, self.port, self.user, self.password, self.timeout = host, int(port), user, password, timeout
        self.cli, self.mode = None, None

    def connect(self):
        try:
            import paramiko
        except ImportError:
            paramiko = None
        if paramiko:
            self.cli = paramiko.SSHClient()
            self.cli.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            try:
                self.cli.connect(self.host, self.port, self.user, self.password, timeout=self.timeout,
                                 allow_agent=False, look_for_keys=not self.password, banner_timeout=self.timeout)
            except paramiko.AuthenticationException:
                raise PermissionError("SSH login failed — check username / password.")
            self.mode = "paramiko"
            return True
        if not shutil.which("ssh"):
            raise CliError("SSH needs the optional 'paramiko' package (pip install paramiko) or the OpenSSH client.")
        self.mode = "system"
        self.run("/system identity print")          # key-auth probe; fails fast if keys are not set up
        return True

    def run(self, cmd, timeout=None):
        if self.mode == "paramiko":
            _i, o, e = self.cli.exec_command(cmd, timeout=timeout or self.timeout)
            return (o.read().decode("utf-8", "replace") or e.read().decode("utf-8", "replace")).strip()
        p = subprocess.run(["ssh", "-o", "BatchMode=yes", "-o", "StrictHostKeyChecking=accept-new",
                            "-o", f"ConnectTimeout={int(self.timeout)}", "-p", str(self.port),
                            f"{self.user}@{self.host}", cmd], capture_output=True, text=True, timeout=timeout or 30)
        if p.returncode and not p.stdout:
            raise CliError(p.stderr.strip() or "ssh failed (system ssh only supports key authentication)")
        return p.stdout.strip()

    def close(self):
        if self.cli:
            self.cli.close()
        self.cli = None


# ---- RouterOS "print terse" parsing ------------------------------------------------------------------------
KV = re.compile(r'([A-Za-z0-9_.\-]+)=("(?:[^"\\]|\\.)*"|\S*)')


def parse_terse(text):
    """'/ppp secret print terse' output -> list of dicts (adds 'disabled'/'dynamic' booleans from flag letters)."""
    rows = []
    for line in text.splitlines():
        line = line.strip()
        m = re.match(r"^(\d+)?\s*([A-Z]{0,6})\s*([a-z][\w.\-]*=.*)$", line)
        if not m:
            continue
        row = {}
        for k, v in KV.findall(m.group(3)):
            row[k] = v[1:-1].replace('\\"', '"') if v.startswith('"') else v
        flags = m.group(2)
        row["disabled"] = "true" if "X" in flags else "false"
        row["dynamic"] = "true" if "D" in flags else "false"
        row["running"] = "true" if "R" in flags else "false"
        rows.append(row)
    return rows


def quote(v):
    return '"' + str(v).replace("\\", "\\\\").replace('"', '\\"') + '"'
