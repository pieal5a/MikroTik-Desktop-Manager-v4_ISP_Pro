"""NOC Command Center (v6.3): one wall-screen view of the whole ISP.
  • Health score ring (A+ … F) built from 6 live components, SYSTEM NOMINAL / DEGRADED / CRITICAL pill
  • Animated radar – every router / device is a blip (green ok • orange high load • red down, pulsing); click a blip for details
  • KPI cards (click = open the page): online now, collected, net profit, total due, open tickets, active incidents
  • Live incident feed (alerts + outages + auto actions), zone heat (online % per zone), 24 h online trend,
    smart advisor (forecast, late payers, data problems) and a scrolling ticker
  • Wall mode (full screen, Esc to leave) and optional sound on new critical incidents"""
import math
import time
import tkinter as tk
import zlib

import db as dbm
from core import *
from core import PAGE_KINDS
from isp_common import BRAND, money
from live_monitor import blend
from menu_spec import NAV
from ui_kit import GButton

LEVEL_COL = {"critical": RED, "error": RED, "warning": ORANGE, "info": CYAN, "ok": GREEN}


def grade(score):
    for lim, g in ((97, "A+"), (90, "A"), (80, "B"), (70, "C"), (55, "D")):
        if score >= lim:
            return g
    return "F"


def score_color(score):
    return GREEN if score >= 85 else (ORANGE if score >= 60 else RED)


class NocCenterPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.sel_router, self.sweep, self.blips, self.health = None, 0.0, [], {}
        self.sound = tk.BooleanVar(value=bool(app.settings.get("noc_sound", False)))
        self._jobs, self._last_crit, self._ticker_x, self._ticker_txt = [], 0, 0, ""
        self._down_prev, self._slow = set(), 0
        # ---------------- header --------------------------------------------------------------------------------
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x")
        left = tk.Frame(top, bg=BG)
        left.pack(side="left")
        tk.Label(left, text="◉ NOC COMMAND CENTER", bg=BG, fg=CYAN, font=(FONT, 20, "bold")).pack(anchor="w")
        self.sub = tk.Label(left, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.sub.pack(anchor="w")
        self.pill = tk.Label(top, text="SYSTEM NOMINAL", bg=blend(GREEN, BG, 0.18), fg=GREEN, font=(FONT, 11, "bold"), padx=60, pady=7,
                             highlightthickness=1, highlightbackground=GREEN)
        self.pill.pack(side="left", expand=True)
        right = tk.Frame(top, bg=BG)
        right.pack(side="right")
        self.clock = tk.Label(right, text="", bg=BG, fg=TEXT, font=(FONT, 22, "bold"))
        self.clock.pack(anchor="e")
        self.date = tk.Label(right, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.date.pack(anchor="e")
        tools = tk.Frame(self, bg=BG)
        tools.pack(fill="x", pady=(4, 2))
        GButton(tools, "⛶ Wall mode", self.wall, "purple", 120, 26, bg=BG).pack(side="left")
        tk.Checkbutton(tools, text="🔊 Sound on critical", variable=self.sound, command=self._save_sound, bg=BG, fg=MUTED, selectcolor=PANEL2,
                       activebackground=BG, activeforeground=CYAN).pack(side="left", padx=10)
        self.stamp = tk.Label(tools, text="", bg=BG, fg=DIM, font=(FONT, 8))
        self.stamp.pack(side="right")
        # ---------------- main grid -------------------------------------------------------------------------------
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        body.grid_columnconfigure(1, weight=1)
        body.grid_rowconfigure(0, weight=1)
        # health panel
        hp = tk.Frame(body, bg=CARD, highlightbackground=BORDER, highlightthickness=1, width=290)
        hp.grid(row=0, column=0, sticky="ns", padx=(0, 8), pady=4)
        hp.pack_propagate(False)
        self.ring = tk.Canvas(hp, width=270, height=250, bg=CARD, highlightthickness=0)
        self.ring.pack(pady=(10, 0))
        self.bars = tk.Canvas(hp, width=270, height=170, bg=CARD, highlightthickness=0)
        self.bars.pack()
        # radar
        mid = tk.Frame(body, bg=BG)
        mid.grid(row=0, column=1, sticky="nsew", pady=4)
        self.radar = tk.Canvas(mid, bg=BG, highlightthickness=0)
        self.radar.pack(fill="both", expand=True)
        self.radar.bind("<Button-1>", self._radar_click)
        self.detail = tk.Label(mid, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.detail.pack()
        # KPI column
        kp = tk.Frame(body, bg=BG, width=250)
        kp.grid(row=0, column=2, sticky="ns", padx=(8, 0), pady=4)
        self.k = {}
        for key, title, color, target in (("online", "ONLINE NOW", GREEN, "totals"), ("collected", "COLLECTED (MONTH)", BLUE, "billing"),
                                          ("profit", "NET PROFIT", CYAN, "expenses"), ("due", "TOTAL DUE", ORANGE, "analytics"),
                                          ("tickets", "OPEN TICKETS", PURPLE, "tickets"), ("incidents", "ACTIVE INCIDENTS", RED, "alerts")):
            c = tk.Frame(kp, bg=CARD, highlightbackground=BORDER, highlightthickness=1, cursor="hand2")
            c.pack(fill="x", pady=3, ipady=2)
            tk.Frame(c, bg=color, width=3).pack(side="left", fill="y")
            inner = tk.Frame(c, bg=CARD)
            inner.pack(side="left", fill="x", expand=True, padx=10, pady=2)
            t = tk.Label(inner, text=title, bg=CARD, fg=MUTED, font=(FONT, 8))
            t.pack(anchor="w")
            v = tk.Label(inner, text="—", bg=CARD, fg=TEXT, font=(FONT, 20, "bold"))
            v.pack(side="left")
            s = tk.Label(inner, text="", bg=CARD, fg=color, font=(FONT, 8, "bold"))
            s.pack(side="right")
            self.k[key] = (v, s)
            for w in (c, inner, t, v, s):
                w.bind("<Button-1>", lambda _e, tg=target: self.goto(tg))
        # ---------------- bottom panels ---------------------------------------------------------------------------
        bot = tk.Frame(self, bg=BG)
        bot.pack(fill="x", pady=(4, 0))
        for c in range(4):
            bot.grid_columnconfigure(c, weight=1, uniform="b")
        self.feed = self._panel(bot, 0, "LIVE INCIDENT FEED", RED, text=True)
        self.zone = self._panel(bot, 1, "ZONE HEAT (online %)", ORANGE)
        self.trend = self._panel(bot, 2, "ONLINE USERS — 24 H", CYAN)
        self.adv = self._panel(bot, 3, "SMART ADVISOR", PURPLE, text=True)
        for tag, col in LEVEL_COL.items():
            self.feed.tag_configure(tag, foreground=col)
            self.adv.tag_configure(tag, foreground=col)
        self.adv.tag_configure("warn", foreground=ORANGE)
        self.adv.tag_configure("bad", foreground=RED)
        self.ticker = tk.Canvas(self, height=26, bg=CARD2, highlightthickness=0)
        self.ticker.pack(fill="x", pady=(6, 0))
        self.tk_text = self.ticker.create_text(10, 13, text="", fill=TEXT, font=(FONT, 10, "bold"), anchor="w")
        self.ticker.create_rectangle(0, 0, 62, 26, fill=CARD2, outline="", tags="live")
        self.ticker.create_text(8, 13, text="► LIVE", fill=GREEN, font=(FONT, 8, "bold"), anchor="w", tags="live")

    def _panel(self, parent, col, title, color, text=False):
        f = tk.Frame(parent, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
        f.grid(row=0, column=col, sticky="nsew", padx=3)
        tk.Label(f, text=title, bg=CARD, fg=color, font=(FONT, 8, "bold")).pack(anchor="w", padx=8, pady=(5, 0))
        if text:
            w = tk.Text(f, height=8, bg=CARD, fg=TEXT, relief="flat", wrap="word", font=(FONT, 8), highlightthickness=0, padx=8, pady=2, cursor="arrow")
            w.pack(fill="both", expand=True, padx=2, pady=(0, 4))
            w.configure(state="disabled")
        else:
            w = tk.Canvas(f, height=128, bg=CARD, highlightthickness=0)
            w.pack(fill="both", expand=True, padx=4, pady=(0, 4))
        return w

    # ---- lifecycle -----------------------------------------------------------------------------------------------
    def on_show(self):
        self._stop()
        self.refresh()
        self._jobs = [self.after(80, self._animate), self.after(4000, self._data_loop)]
        self.bind_all("<Escape>", self._esc)

    def on_hide(self):
        self._stop()
        self.unbind_all("<Escape>")
        if self.app.attributes("-fullscreen"):
            self.app.attributes("-fullscreen", False)

    def _stop(self):
        for j in self._jobs:
            try:
                self.after_cancel(j)
            except Exception:
                pass
        self._jobs = []

    def _alive(self):
        return self.winfo_exists() and (self.app.active is self or self.winfo_ismapped())

    def _data_loop(self):
        if self._alive():
            self.refresh()
            self._jobs.append(self.after(4000, self._data_loop))

    def on_sync(self):
        if self._alive():
            self.refresh()

    def goto(self, kind):
        spec = next((n[3] for n in NAV if isinstance(n, tuple) and isinstance(n[3], dict) and n[3].get("kind") == kind), None)
        if spec:
            self.app.open_spec(spec, f"{spec['kind']}|{spec.get('path', '')}|{spec['title']}")

    def wall(self):
        self.app.attributes("-fullscreen", not bool(self.app.attributes("-fullscreen")))

    def _esc(self, _e=None):
        if self.app.attributes("-fullscreen"):
            self.app.attributes("-fullscreen", False)

    def _save_sound(self):
        self.app.settings["noc_sound"] = bool(self.sound.get())
        self.app.apply_settings()

    # ---- data -------------------------------------------------------------------------------------------------------
    def compute(self):
        app, db = self.app, self.app.db
        month, lt = dbm.month_now(), time.localtime()
        sm = db.summary(month)
        t = db.totals()
        st = app.sync.status
        routers = []
        for p in app.profiles:
            s = st.get(p["name"], {})
            state = s.get("state", "idle")
            cpu, mem = s.get("cpu", 0) or 0, s.get("mem_pct", 0) or 0
            level = "down" if state in ("error", "no-password") else ("warn" if cpu >= 80 or mem >= 90 else ("ok" if state == "ok" else "idle"))
            routers.append(dict(name=p["name"], proto=p.get("proto", "api").upper(), state=state, level=level, cpu=cpu, mem=mem,
                                uptime=s.get("uptime", ""), users=s.get("ppp_active_n", 0), ts=s.get("ts", 0), msg=s.get("msg", "")))
        tracked = [r for r in routers if r["state"] != "idle"]
        avail = (100 * sum(1 for r in tracked if r["level"] != "down") / len(tracked)) if tracked else 100
        worst = max([max(r["cpu"], r["mem"] * 0.9) for r in tracked] or [0])
        load = max(0, 100 - max(0, worst - 60) * 2.5)
        ratio = (t["online"] / t["active"]) if t["active"] else 1
        online = min(100, ratio / 0.85 * 100)
        target = sm["expected"] * min(1, lt.tm_mday / 20)
        pace = min(100, sm["paid"] * 100 / target) if target > 0 else 100
        arrears = 100 - min(100, (sm["total_due"] / t["mrr"] * 200)) if t["mrr"] else 100
        op, ip = db.ticket_counts()
        support = max(0, 100 - op * 4 - ip * 2)
        comps = (("Router availability", avail, 30), ("Router load", load, 15), ("Subscribers online", online, 20),
                 ("Collection pace", pace, 15), ("Arrears exposure", arrears, 10), ("Support load", support, 10))
        score = sum(v * w for _n, v, w in comps) / sum(w for *_x, w in comps)
        down = [r for r in routers if r["level"] == "down"]
        outages = list(app.sync.outages)
        if down or outages:
            score = min(score, 60 if (down and len(down) == len(tracked)) or outages else 78)
        expenses = db.analytics(month)["expenses"]
        return dict(score=score, comps=comps, routers=routers, down=down, outages=outages, sm=sm, t=t, expenses=expenses, op=op, ip=ip, month=month)

    def refresh(self):
        try:
            h = self.compute()
        except Exception as e:           # never let the wall display die
            self.stamp.configure(text=f"data error: {e}")
            return
        self.health, app = h, self.app
        score = h["score"]
        status = "SYSTEM CRITICAL" if score < 60 else ("SYSTEM DEGRADED" if score < 85 or h["down"] or h["outages"] else "SYSTEM NOMINAL")
        col = RED if "CRITICAL" in status else (ORANGE if "DEGRADED" in status else GREEN)
        self.pill.configure(text=status, fg=col, bg=blend(col, BG, 0.18), highlightbackground=col)
        s = app.settings
        self.sub.configure(text=f"{s.get('company', BRAND['company'])}  •  {s.get('noc_name', 'Network Operations')}")
        sm, t = h["sm"], h["t"]
        self.k["online"][0].configure(text=str(t["online"]))
        self.k["online"][1].configure(text=f"of {t['active']} active")
        self.k["collected"][0].configure(text=money(sm["collected"]))
        self.k["collected"][1].configure(text=f"{(sm['paid'] * 100 / sm['expected']) if sm['expected'] else 0:.0f}% of billed")
        self.k["profit"][0].configure(text=money(sm["collected"] - h["expenses"]))
        self.k["profit"][1].configure(text=f"exp {money(h['expenses'])}")
        self.k["due"][0].configure(text=money(sm["total_due"]))
        self.k["due"][1].configure(text=f"{sm['due_clients']} clients")
        self.k["tickets"][0].configure(text=str(h["op"]))
        self.k["tickets"][1].configure(text=f"{h['ip']} in progress")
        inc = len(h["down"]) + len(h["outages"])
        self.k["incidents"][0].configure(text=str(inc), fg=RED if inc else GREEN)
        self.k["incidents"][1].configure(text="all clear" if not inc else "needs attention")
        self._draw_ring()
        self._draw_bars()
        self._update_detail()
        self._fill_feed()
        self._draw_zones()
        self._draw_trend()
        self._fill_advisor(h)
        self._ticker_update(h)
        self._sound_check(h)
        self.stamp.configure(text=f"refreshed {time.strftime('%H:%M:%S')}  •  data every 4 s, routers every {app.settings.get('sync_minutes', 5)} min")

    # ---- drawing ---------------------------------------------------------------------------------------------------------
    def _draw_ring(self):
        cv, sc = self.ring, self.health["score"]
        cv.delete("all")
        cx, cy, r = 135, 120, 92
        col = score_color(sc)
        cv.create_oval(cx - r, cy - r, cx + r, cy + r, outline=blend(TEXT, CARD, 0.12), width=16)
        cv.create_arc(cx - r, cy - r, cx + r, cy + r, start=90, extent=-3.6 * sc, style="arc", outline=col, width=16)
        cv.create_text(cx, cy - 6, text=f"{sc:.0f}", fill=TEXT, font=(FONT, 52, "bold"))
        cv.create_text(cx, cy + 46, text=f"HEALTH • {grade(sc)}", fill=col, font=(FONT, 11, "bold"))
        cv.create_text(cx, 236, text=f"{len(self.health['routers'])} devices • {self.health['t']['total']} clients", fill=MUTED, font=(FONT, 8))

    def _draw_bars(self):
        cv = self.bars
        cv.delete("all")
        for i, (name, v, _w) in enumerate(self.health["comps"]):
            y = 12 + i * 27
            c = score_color(v)
            cv.create_text(8, y, text=name, fill=MUTED, font=(FONT, 8), anchor="w")
            cv.create_text(262, y, text=f"{v:.0f}", fill=c, font=(FONT, 8, "bold"), anchor="e")
            cv.create_rectangle(8, y + 8, 262, y + 12, fill=blend(TEXT, CARD, 0.1), outline="")
            cv.create_rectangle(8, y + 8, 8 + 254 * max(min(v, 100), 1) / 100, y + 12, fill=c, outline="")

    def _animate(self):
        if not self._alive():
            return
        self.sweep = (self.sweep + 3.2) % 360
        self._clock()
        self._draw_radar()
        self._ticker_x -= 1.6
        bbox = self.ticker.bbox(self.tk_text)
        width = (bbox[2] - bbox[0]) if bbox else 0
        if self._ticker_x < -width:
            self._ticker_x = self.ticker.winfo_width()
        self.ticker.coords(self.tk_text, self._ticker_x + 60, 13)
        self.ticker.tag_raise("live")
        self._jobs.append(self.after(70, self._animate))

    def _draw_radar(self):
        cv = self.radar
        w, h = max(cv.winfo_width(), 300), max(cv.winfo_height(), 300)
        cx, cy, R = w / 2, h / 2, min(w, h) / 2 - 14
        cv.delete("all")
        grid = blend(CYAN, BG, 0.28)
        for f in (0.25, 0.5, 0.75, 1.0):
            cv.create_oval(cx - R * f, cy - R * f, cx + R * f, cy + R * f, outline=grid)
        cv.create_line(cx - R, cy, cx + R, cy, fill=grid)
        cv.create_line(cx, cy - R, cx, cy + R, fill=grid)
        for a in range(0, 360, 10):
            r1 = R - (8 if a % 30 == 0 else 4)
            x1, y1 = cx + R * math.cos(math.radians(a)), cy - R * math.sin(math.radians(a))
            x2, y2 = cx + r1 * math.cos(math.radians(a)), cy - r1 * math.sin(math.radians(a))
            cv.create_line(x1, y1, x2, y2, fill=grid)
        worst_down = bool(self.health.get("down") or self.health.get("outages"))
        sweep_col = RED if worst_down else GREEN
        for i in range(16):                                   # fading sweep wedge
            cv.create_arc(cx - R, cy - R, cx + R, cy + R, start=self.sweep - (i + 1) * 2.6, extent=2.6, style="pieslice",
                          fill=blend(sweep_col, BG, 0.5 * (1 - i / 16)), outline="")
        ex, ey = cx + R * math.cos(math.radians(self.sweep)), cy - R * math.sin(math.radians(self.sweep))
        cv.create_line(cx, cy, ex, ey, fill=sweep_col, width=2)
        cv.create_oval(cx - 4, cy - 4, cx + 4, cy + 4, fill=sweep_col, outline="")
        self.blips = []
        n = len(self.health.get("routers", []))
        for i, r in enumerate(self.health.get("routers", [])):
            hsh = zlib.crc32(r["name"].encode())
            ang = math.radians((hsh % 3600) / 10 if n > 2 else 40 + i * 140)
            rad = R * (0.30 + 0.58 * (((hsh >> 12) % 100) / 100))
            x, y = cx + rad * math.cos(ang), cy - rad * math.sin(ang)
            col = {"ok": GREEN, "warn": ORANGE, "down": RED}.get(r["level"], DIM)
            pulse = 4 + (3 * abs(math.sin(time.time() * 4)) if r["level"] == "down" else 0)
            cv.create_oval(x - pulse - 6, y - pulse - 6, x + pulse + 6, y + pulse + 6, outline=blend(col, BG, 0.35))
            cv.create_oval(x - pulse, y - pulse, x + pulse, y + pulse, fill=col, outline="white" if r["name"] == self.sel_router else "")
            cv.create_text(x + 12, y - 8, text=r["name"], fill=TEXT, font=(FONT, 9), anchor="w")
            self.blips.append((x, y, r["name"]))
        cv.create_text(cx, h - 4, text=f"{n} routers tracked", fill=MUTED, font=(FONT, 8), anchor="s")

    def _radar_click(self, e):
        best = min(self.blips, key=lambda b: (b[0] - e.x) ** 2 + (b[1] - e.y) ** 2, default=None)
        self.sel_router = best[2] if best and (best[0] - e.x) ** 2 + (best[1] - e.y) ** 2 < 24 ** 2 else None
        self._update_detail()

    def _update_detail(self):
        r = next((x for x in self.health.get("routers", []) if x["name"] == self.sel_router), None)
        if not r:
            self.detail.configure(text="click a blip for router details", fg=DIM)
            return
        age = f"{int(time.time() - r['ts'])}s ago" if r["ts"] else "never"
        txt = (f"{r['name']} • {r['proto']} • {r['state'].upper()} • users {r['users']} • CPU {r['cpu']}% • RAM {r['mem']:.0f}% • "
               f"uptime {r['uptime'] or '—'} • synced {age}")
        self.detail.configure(text=txt, fg={"ok": GREEN, "warn": ORANGE, "down": RED}.get(r["level"], MUTED))

    # ---- bottom panels --------------------------------------------------------------------------------------------------
    def _fill_feed(self):
        db, app = self.app.db, self.app
        today = time.strftime("%Y-%m-%d")
        rows = [(f"{today} {t}", lvl, msg) for t, lvl, msg in list(app.alerts.items)[:15]]
        for r in db.q("SELECT ts, action, detail FROM audit WHERE action IN ('outage','outage-restored','auto-enable','auto-suspend','auto-reminder',"
                      "'packages-imported','handover','charge','payment') ORDER BY id DESC LIMIT 15"):
            lvl = "critical" if r["action"] == "outage" else ("ok" if r["action"] in ("outage-restored", "auto-enable", "payment") else "info")
            rows.append((r["ts"], lvl, f"{r['action']}: {r['detail']}"))
        rows.sort(key=lambda x: x[0], reverse=True)
        w = self.feed
        w.configure(state="normal")
        w.delete("1.0", "end")
        if not rows:
            w.insert("end", "No incidents — all quiet.", "ok")
        for ts, lvl, msg in rows[:14]:
            w.insert("end", f"{ts[11:16]}  {msg[:110]}\n", lvl)
        w.configure(state="disabled")

    def _draw_zones(self):
        cv = self.zone
        cv.delete("all")
        w = max(cv.winfo_width(), 200)
        rows = self.app.db.q("SELECT CASE WHEN zone='' THEN '(no zone)' ELSE zone END AS z, COUNT(*) AS n, SUM(online) AS o FROM clients "
                             "WHERE status='active' GROUP BY 1 HAVING n>0")
        if not rows:
            cv.create_text(w // 2, 60, text="no clients yet", fill=MUTED, font=(FONT, 9))
            return
        rows = sorted(rows, key=lambda r: ((r["o"] or 0) / r["n"], -r["n"]))[:6]
        for i, r in enumerate(rows):
            pct = (r["o"] or 0) * 100 / r["n"]
            y = 8 + i * 20
            col = RED if pct < 40 else (ORANGE if pct < 70 else GREEN)
            cv.create_text(4, y + 6, text=r["z"][:14], fill=TEXT, font=(FONT, 8), anchor="w")
            cv.create_rectangle(84, y + 2, w - 96, y + 10, fill=blend(TEXT, CARD, 0.1), outline="")
            cv.create_rectangle(84, y + 2, 84 + (w - 180) * pct / 100, y + 10, fill=col, outline="")
            cv.create_text(w - 4, y + 6, text=f"{pct:.0f}%  {r['o'] or 0}/{r['n']}", fill=col, font=(FONT, 8, "bold"), anchor="e")

    def _draw_trend(self):
        cv = self.trend
        cv.delete("all")
        w, h = max(cv.winfo_width(), 200), max(cv.winfo_height(), 100)
        tr = self.app.db.online_trend(24)
        if len(tr) < 2:
            cv.create_text(w // 2, h // 2, text="collecting data (needs a few syncs)", fill=MUTED, font=(FONT, 9))
            return
        vals = [r["online"] for r in tr]
        lo, hi = min(vals), max(vals)
        span = (hi - lo) or 1
        pts = [(8 + (w - 16) * i / (len(vals) - 1), h - 22 - (h - 44) * (v - lo) / span) for i, v in enumerate(vals)]
        cv.create_polygon([8, h - 22] + [c for p in pts for c in p] + [w - 8, h - 22], fill=blend(CYAN, CARD, 0.2), outline="")
        cv.create_line([c for p in pts for c in p], fill=CYAN, width=2)
        cv.create_text(8, 8, text=f"now {vals[-1]:.0f}", fill=CYAN, font=(FONT, 9, "bold"), anchor="w")
        cv.create_text(w - 8, 8, text=f"peak {hi:.0f} • low {lo:.0f}", fill=MUTED, font=(FONT, 8), anchor="e")
        cv.create_text(8, h - 8, text=tr[0]["h"][5:], fill=DIM, font=(FONT, 7), anchor="w")
        cv.create_text(w - 8, h - 8, text="now", fill=DIM, font=(FONT, 7), anchor="e")

    def _fill_advisor(self, h):
        self._slow = (self._slow + 1) % 4                      # insights are heavier → every 4th refresh (≈16 s)
        if self._slow and getattr(self, "_adv_cache", None):
            items = self._adv_cache
        else:
            items = self._adv_cache = self.app.db.insights(int(self.app.settings.get("due_day", 10) or 10))[:7]
        w = self.adv
        w.configure(state="normal")
        w.delete("1.0", "end")
        icon = {"info": "ℹ ", "warn": "⚠ ", "bad": "● ", "ok": "✔ "}
        for lvl, text in items:
            w.insert("end", icon.get(lvl, "") + text[:170] + "\n", lvl)
        w.configure(state="disabled")

    def _ticker_update(self, h):
        t = h["t"]
        parts = [f"{t['online']} online of {t['active']} active", f"health {h['score']:.0f} ({grade(h['score'])})", f"due {money(h['sm']['total_due'])}"]
        for r in h["down"]:
            parts.append(f"⚠ {r['name']} DOWN")
        for rt, zone in h["outages"]:
            parts.append(f"⚠ possible outage {rt}/{zone}")
        parts += [txt for lvl, txt in (getattr(self, "_adv_cache", None) or [])[:3]]
        self.ticker.itemconfigure(self.tk_text, text="   ●   ".join(parts))

    def _clock(self):
        now = time.localtime()
        self.clock.configure(text=time.strftime("%H:%M:%S", now))
        self.date.configure(text=time.strftime("%A, %d %B %Y", now))

    def _sound_check(self, h):
        crit = len(h["down"]) + len(h["outages"])
        if crit > self._last_crit and self.sound.get():
            try:
                self.app.bell()
                self.after(350, self.app.bell)
            except Exception:
                pass
        self._last_crit = crit


PAGE_KINDS.update({"noc": NocCenterPage})
