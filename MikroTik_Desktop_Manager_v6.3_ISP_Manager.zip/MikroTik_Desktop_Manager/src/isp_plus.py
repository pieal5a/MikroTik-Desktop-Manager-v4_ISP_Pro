"""v6 additions
  • Bandwidth Usage      – per-client download / upload (daily totals from the PPPoE interface counters) + live top users
  • Analytics & Aging    – collection efficiency, ARPU, new / lost clients, aging buckets, zone / package mix
  • Cash Book            – collections per collector & method, cash hand-over (who still owes the office how much)
  • Inventory            – ONU / router / cable stock, assigned to clients
  • Router & Data Audit  – router-vs-database mismatches and data-quality checks, with one-click fixes
  • Client Extras dialog – ONU MAC, OLT port, map location, own due-day / grace days / exempt, installation & one-time charges
"""
import html
import threading
import time
import tkinter as tk
from concurrent.futures import ThreadPoolExecutor
from tkinter import ttk, messagebox, filedialog

import db as dbm
import db_plus as dbp
from core import *
from core import PAGE_KINDS
from isp_clients import combo, month_choices, mkey, PayDialog, ClientDialog
from isp_common import *
from isp_extra import kpi_row
from transport import NotSupported
from ui_kit import GButton, Panel, fmt_rate


def gb(n):
    """bytes -> '12.34 GB' style (decimal units, same as fmt_bytes)."""
    return fmt_bytes(n)


class ClientPick(tk.Frame):
    """Type 2+ characters of PPPoE ID / name / phone → drop-down of matches. `.cid` holds the chosen client id."""

    def __init__(self, parent, app, cid=None, width=40, bg=BG):
        super().__init__(parent, bg=bg)
        self.app, self.cid, self.found = app, cid, {}
        self.cb = combo(self, [], width, state="normal")
        self.cb.pack(side="left")
        self.cb.bind("<KeyRelease>", self._find)
        self.cb.bind("<<ComboboxSelected>>", self._pick)
        c = app.db.client(cid) if cid else None
        if c:
            self.cb.set(f"{c['pppoe_id']} — {c['name']}")

    def _find(self, _e=None):
        q = self.cb.get().strip()
        if len(q) < 2:
            return
        self.found = {f"{c['pppoe_id']} — {c['name']}": c["id"] for c in self.app.db.clients(q)[:25]}
        self.cb["values"] = list(self.found)
        if not q:
            self.cid = None

    def _pick(self, _e=None):
        self.cid = self.found.get(self.cb.get(), self.cid)

    def get(self):
        if not self.cb.get().strip():
            return None
        return self.cid


def bar_chart(cv, series, colors=(CYAN, ORANGE), unit=gb, title=""):
    """Stacked daily bars on a Canvas. series = [(label, v1, v2), ...]"""
    cv.delete("all")
    w, h = max(cv.winfo_width(), 300), max(cv.winfo_height(), 90)
    if not series:
        cv.create_text(w // 2, h // 2, text="no data yet — usage is recorded on every router sync", fill=MUTED, font=(FONT, 9))
        return
    peak = max((a + b) for _l, a, b in series) or 1
    n, pad, bot = len(series), 6, 16
    bw = max((w - 2 * pad) / n, 3)
    for i, (lab, a, b) in enumerate(series):
        x0, x1 = pad + i * bw + 1, pad + (i + 1) * bw - 1
        ha, hb = (h - bot - 14) * a / peak, (h - bot - 14) * b / peak
        y = h - bot
        cv.create_rectangle(x0, y - ha, x1, y, fill=colors[0], outline="")
        cv.create_rectangle(x0, y - ha - hb, x1, y - ha, fill=colors[1], outline="")
        if n <= 16 or i % 3 == 0:
            cv.create_text((x0 + x1) / 2, h - 7, text=lab[-2:], fill=DIM, font=(FONT, 7))
    cv.create_text(pad + 2, 8, text=f"peak {unit(peak)}  {title}", fill=MUTED, font=(FONT, 8), anchor="w")


# ======================================================================================================
# Bandwidth usage
# ======================================================================================================
class UsageDialog(tk.Toplevel):
    def __init__(self, app, cid):
        super().__init__(app)
        c = app.db.client(cid)
        self.title(f"Usage — {c['pppoe_id']}")
        self.configure(bg=BG)
        self.transient(app)
        ser = app.db.usage_series(cid, 31)
        tk.Label(self, text=f"{c['pppoe_id']}  •  {c['name']}  •  last {len(ser)} day(s)", bg=BG, fg=CYAN,
                 font=(FONT, 11, "bold")).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(self, text="■ download (to client)   ■ upload (from client)", bg=BG, fg=MUTED, font=(FONT, 8)).pack(anchor="w", padx=14)
        cv = tk.Canvas(self, width=640, height=170, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        cv.pack(padx=14, pady=6)
        self.after(80, lambda: bar_chart(cv, [(r["day"], r["tx"], r["rx"]) for r in ser]))
        w, tree = scrolled_tree(self, [("d", "DAY", 100), ("dl", "DOWNLOAD", 110, "e"), ("ul", "UPLOAD", 110, "e"), ("t", "TOTAL", 110, "e")], height=8)
        w.pack(fill="both", expand=True, padx=14, pady=(0, 12))
        for r in reversed(ser):
            tree.insert("", "end", values=(r["day"], gb(r["tx"]), gb(r["rx"]), gb(r["tx"] + r["rx"])))
        tot_dl, tot_ul = sum(r["tx"] for r in ser), sum(r["rx"] for r in ser)
        tk.Label(self, text=f"Total: ↓ {gb(tot_dl)}   ↑ {gb(tot_ul)}", bg=BG, fg=GREEN, font=(FONT, 10, "bold")).pack(pady=(0, 10))


class UsagePage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Bandwidth Usage", "per-client download / upload • live top users")
        self.cards = {}
        kpi_row(self, (("dl", "Download this month", CYAN), ("ul", "Upload this month", ORANGE), ("users", "Users with traffic", GREEN),
                       ("top", "Heaviest user", PURPLE)), self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        self.month, self.router, self.sort = tk.StringVar(value=month_choices()[2]), tk.StringVar(value="All routers"), tk.StringVar(value="Month usage")
        self.q = tk.StringVar()
        self.q.trace_add("write", lambda *_: self.refresh())
        tk.Label(f, text="Month", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        mc = combo(f, month_choices(), 18, var=self.month)
        mc.pack(side="left", padx=6)
        mc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self.rc = combo(f, [], 14, var=self.router)
        self.rc.pack(side="left", padx=4)
        self.rc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        sc = combo(f, ["Month usage", "Live speed"], 11, var=self.sort)
        sc.pack(side="left", padx=4)
        sc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        e = app.entry(f, 20)
        e.configure(textvariable=self.q)
        e.pack(side="left", padx=8, ipady=3)
        for text, fn, col, w in (("⚡ Live sample (8 s)", self.live, "green", 160), ("⬇ Export CSV", self.export, "blue", 120)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(6, 0))
        self.info = tk.Label(f, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.info.pack(side="left", padx=10)
        self.chart = tk.Canvas(self, height=110, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        self.chart.pack(fill="x", pady=(0, 6))
        cols = [("c", "PPPOE ID", 120), ("n", "CLIENT", 160), ("r", "ROUTER", 110), ("k", "PACKAGE", 90), ("dl", "DOWNLOAD", 95, "e"),
                ("ul", "UPLOAD", 95, "e"), ("t", "TOTAL", 95, "e"), ("td", "TODAY", 95, "e"), ("ld", "LIVE ↓", 90, "e"), ("lu", "LIVE ↑", 90, "e"),
                ("o", "ONLINE", 70)]
        wrap, self.tree = scrolled_tree(self, cols)
        wrap.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", self._open)
        self.rows, self.sample = [], {}
        tk.Label(self, text="Download = traffic sent to the client. Usage is counted from the PPPoE interface byte counters on every sync "
                            "(default 5 min); live columns show the last sync average, or the 8-second sample when you press ⚡.",
                 bg=BG, fg=DIM, font=(FONT, 8), justify="left").pack(anchor="w", pady=(4, 0))

    def on_show(self):
        self.rc["values"] = ["All routers"] + [p["name"] for p in self.app.profiles]
        self.refresh()

    def on_sync(self):
        if self.winfo_ismapped():
            self.refresh()

    def _live_for(self, router, user):
        if (router, user) in self.sample:
            return self.sample[(router, user)]
        live = self.app.sync.live.get(router, {}).get("rates", {})
        return live.get(user)

    def refresh(self):
        db, m = self.app.db, mkey(self.month.get())
        r = "" if self.router.get() in ("", "All routers") else self.router.get()
        rows = db.usage_month(m, r, self.q.get().strip())
        today = {x["id"]: x for x in db.usage_today(r)}
        for x in rows:
            x["today"] = (today.get(x["id"]) or {}).get("rx", 0) + (today.get(x["id"]) or {}).get("tx", 0)
            lv = self._live_for(x["router"], x["pppoe_id"]) or (0, 0)
            x["up_bps"], x["down_bps"] = lv
        if self.sort.get() == "Live speed":
            rows.sort(key=lambda x: -(x["up_bps"] + x["down_bps"]))
        self.rows = rows
        self.tree.delete(*self.tree.get_children())
        for i, x in enumerate(rows[:3000]):
            self.tree.insert("", "end", iid=str(x["id"]), tags=("odd",) if i % 2 else (), values=(
                x["pppoe_id"], x["name"], x["router"], x["package"], gb(x["tx"]), gb(x["rx"]), gb(x["tx"] + x["rx"]),
                gb(x["today"]) if x["today"] else "", fmt_rate(x["down_bps"]) if x["down_bps"] else "",
                fmt_rate(x["up_bps"]) if x["up_bps"] else "", "● online" if x["online"] else ""))
        self.cards["dl"].configure(text=gb(sum(x["tx"] for x in rows)))
        self.cards["ul"].configure(text=gb(sum(x["rx"] for x in rows)))
        self.cards["users"].configure(text=str(len(rows)))
        self.cards["top"].configure(text=(f"{rows[0]['pppoe_id']}" if rows else "—"))
        tot = db.usage_totals_by_day(m)
        self.after(50, lambda: bar_chart(self.chart, [(d["day"], d["tx"], d["rx"]) for d in tot], title="  ■ download  ■ upload, per day"))

    def _open(self, _e=None):
        sel = self.tree.selection()
        if sel:
            UsageDialog(self.app, int(sel[0]))

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"usage_{mkey(self.month.get())}.csv", parent=self.app)
        if f:
            rows = [dict(x, download=x["tx"], upload=x["rx"]) for x in self.rows]
            self.app.db.export_csv(f, rows, ["pppoe_id", "name", "router", "package", "download", "upload", "today"])

    # ---- 8-second live sample on one or all routers --------------------------------------------------------------
    def live(self):
        sel = self.router.get()
        profs = [p for p in self.app.profiles if sel in ("", "All routers") or p["name"] == sel]
        profs = [p for p in profs if p.get("proto") != "snmp" or p.get("snmp_community", "public")]
        if not profs:
            messagebox.showinfo("Live sample", "No router selected / available.", parent=self.app)
            return
        jobs = []
        for p in profs:
            pw = self.app.get_router_password(p)
            if pw is None:
                return
            jobs.append((p, pw))
        self.info.configure(text="sampling … 8 s", fg=ORANGE)

        def one(job):
            p, pw = job
            try:
                return p["name"], self.app.sync.live_sample(p, pw, 8), None
            except Exception as e:
                return p["name"], {}, str(e) or e.__class__.__name__

        def work():
            with ThreadPoolExecutor(max_workers=min(len(jobs), 6)) as ex:
                return list(ex.map(one, jobs))

        def done(res):
            self.sample = {}
            errs = []
            for name, rates, err in res:
                if err:
                    errs.append(f"{name}: {err}")
                for u, v in rates.items():
                    self.sample[(name, u)] = v
            self.sort.set("Live speed")
            self.info.configure(text=f"live sample: {len(self.sample)} users" + (f" • {len(errs)} router error(s)" if errs else ""),
                                fg=RED if errs else GREEN)
            # users with live traffic but no stored month usage yet must still be listed → refresh shows stored rows; add live-only rows
            self.refresh()
            if errs:
                messagebox.showwarning("Live sample", "\n".join(errs[:8]), parent=self.app)
        self.app.run_async(work, done, lambda e: self.info.configure(text=str(e), fg=RED))


# ======================================================================================================
# Analytics & aging
# ======================================================================================================
class AnalyticsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Analytics & Aging", "collection efficiency • ARPU • churn • who owes since when")
        self.cards = {}
        kpi_row(self, (("active", "Active clients", BLUE), ("new", "New this month", GREEN), ("lost", "Deactivated this month", RED),
                       ("eff", "Collection efficiency", CYAN), ("arpu", "ARPU ৳ / client", PURPLE), ("cpc", "Expense ৳ / client", ORANGE)),
                self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        tk.Label(f, text="Month", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.month = tk.StringVar(value=month_choices()[2])
        mc = combo(f, month_choices(), 18, var=self.month)
        mc.pack(side="left", padx=6)
        mc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        for text, fn, col, w in (("💰 Receive payment", self.pay, "green", 150), ("🖨 Print report", self.report, "blue", 130),
                                 ("⬇ Export overdue CSV", self.export, "cyan", 160)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(8, 0))
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        tk.Label(left, text="Overdue clients — oldest first (double-click = receive payment)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.tree = scrolled_tree(left, [("c", "PPPOE ID", 110), ("n", "CLIENT", 150), ("p", "PHONE", 105), ("r", "ROUTER", 95),
                                           ("m", "MONTHS", 60, "e"), ("o", "OLDEST", 80), ("t", "OWES ৳", 85, "e"), ("s", "STATUS", 75)])
        w.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda _e: self.pay())
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="y")
        tk.Label(right, text="Aging of dues", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w2, self.ag = scrolled_tree(right, [("b", "AGE", 110), ("c", "CLIENTS", 60, "e"), ("a", "AMOUNT ৳", 90, "e")], height=4)
        w2.pack(fill="x")
        tk.Label(right, text="Dues by zone", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w", pady=(10, 0))
        w3, self.zn = scrolled_tree(right, [("z", "ZONE", 110), ("c", "CLIENTS", 60, "e"), ("a", "DUE ৳", 90, "e")], height=5)
        w3.pack(fill="x")
        tk.Label(right, text="12-month trend", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w", pady=(10, 0))
        w4, self.tr = scrolled_tree(right, [("m", "MONTH", 70), ("e", "BILLED", 70, "e"), ("c", "COLLECTED", 80, "e"), ("n", "NEW", 40, "e")], height=8)
        w4.pack(fill="x")
        self.det = []

    def on_show(self):
        self.refresh()

    def on_sync(self):
        pass

    def refresh(self):
        db, m = self.app.db, mkey(self.month.get())
        a = db.analytics(m)
        self.cards["active"].configure(text=str(a["active"]))
        self.cards["new"].configure(text=str(a["new"]))
        self.cards["lost"].configure(text=str(a["lost"]))
        self.cards["eff"].configure(text=f"{a['efficiency']:.0f}%")
        self.cards["arpu"].configure(text=money(a["arpu"]))
        self.cards["cpc"].configure(text=money(a["cost_per_client"]))
        buckets, det = db.aging(m)
        self.det = det
        self.ag.delete(*self.ag.get_children())
        for b in buckets:
            self.ag.insert("", "end", tags=("bad",) if b["bucket"].startswith("3+") and b["amount"] else (), values=(b["bucket"], b["clients"], money(b["amount"])))
        self.zn.delete(*self.zn.get_children())
        for z in db.top_zones_due(m):
            self.zn.insert("", "end", values=(z["zone"], z["clients"], money(z["due"])))
        self.tr.delete(*self.tr.get_children())
        for s in reversed(db.monthly_series(12, m)):
            self.tr.insert("", "end", values=(s["month"], money(s["expected"]), money(s["collected"]), s["new"]))
        self.tree.delete(*self.tree.get_children())
        for i, x in enumerate(det[:2000]):
            tag = "bad" if x["age"] >= 3 else ("due" if x["age"] >= 1 else "")
            self.tree.insert("", "end", iid=str(x["id"]), tags=(tag,) if tag else (), values=(
                x["pppoe_id"], x["name"], x["phone1"], x["router"], x["months"], x["oldest"], money(x["total"]), STATUS_LABEL.get(x["status"], x["status"])))

    def pay(self):
        sel = self.tree.selection()
        if sel:
            PayDialog(self.app, int(sel[0]), self.refresh, mkey(self.month.get()))

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"overdue_{mkey(self.month.get())}.csv", parent=self.app)
        if f:
            self.app.db.export_csv(f, self.det, ["pppoe_id", "name", "phone1", "router", "months", "oldest", "total", "status"])

    def report(self):
        db, m, e = self.app.db, mkey(self.month.get()), html.escape
        a = db.analytics(m)
        buckets, det = db.aging(m)
        ag = "".join(f"<tr><td>{e(b['bucket'])}</td><td class='r'>{b['clients']}</td><td class='r'>{money(b['amount'])}</td></tr>" for b in buckets)
        rows = "".join(f"<tr><td>{e(x['pppoe_id'])}</td><td>{e(x['name'])}</td><td>{e(x['phone1'])}</td><td class='r'>{x['months']}</td>"
                       f"<td>{x['oldest']}</td><td class='r'>{money(x['total'])}</td></tr>" for x in det[:400])
        s = self.app.settings
        show_html(
            "<!doctype html><meta charset='utf-8'><title>Analytics</title><style>body{font-family:Segoe UI,Arial;margin:24px}"
            "table{border-collapse:collapse;width:100%;margin-bottom:18px}td,th{border:1px solid #ccc;padding:5px 8px;font-size:13px}"
            "th{background:#1d4ed8;color:#fff}td.r{text-align:right}h1{color:#1d4ed8;margin:0}</style>"
            f"<h1>{e(s.get('company', BRAND['company']))}</h1><h2>Business analytics — {dbm.month_label(m)}</h2>"
            f"<table><tr><th>Active clients</th><th>New</th><th>Deactivated</th><th>Collection efficiency</th><th>ARPU ৳</th><th>Billed ৳</th>"
            f"<th>Collected ৳</th><th>Expenses ৳</th></tr><tr><td class='r'>{a['active']}</td><td class='r'>{a['new']}</td><td class='r'>{a['lost']}</td>"
            f"<td class='r'>{a['efficiency']:.0f}%</td><td class='r'>{money(a['arpu'])}</td><td class='r'>{money(a['expected'])}</td>"
            f"<td class='r'>{money(a['collected'])}</td><td class='r'>{money(a['expenses'])}</td></tr></table>"
            f"<h3>Aging of dues</h3><table><tr><th>Age</th><th>Clients</th><th>Amount ৳</th></tr>{ag}</table>"
            f"<h3>Overdue clients (oldest first)</h3><table><tr><th>PPPoE ID</th><th>Name</th><th>Phone</th><th>Months</th><th>Oldest</th><th>Owes ৳</th></tr>{rows}</table>",
            "analytics")


# ======================================================================================================
# Cash book & collectors
# ======================================================================================================
class HandoverDialog(tk.Toplevel):
    def __init__(self, app, on_ok, collector="", amount=0):
        super().__init__(app)
        self.app, self.on_ok = app, on_ok
        self.title("Cash hand-over")
        self.configure(bg=BG)
        self.transient(app)
        self.e = {}
        for r, (lab, key) in enumerate((("Date (YYYY-MM-DD)", "day"), ("Collector", "collector"), ("Amount ৳ handed to the office", "amount"), ("Note", "note"))):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=6)
            if key == "collector":
                wd = combo(self, app.db.collector_names(), 24, state="normal")
                wd.set(collector)
            else:
                wd = app.entry(self, 26)
                wd.insert(0, {"day": time.strftime("%Y-%m-%d"), "amount": f"{amount:g}" if amount else ""}.get(key, ""))
            wd.grid(row=r, column=1, sticky="w", padx=14)
            self.e[key] = wd
        app.button(self, "Save hand-over", self.ok, True).grid(row=4, column=0, columnspan=2, sticky="ew", padx=14, pady=14)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def ok(self):
        d = {k: w.get().strip() for k, w in self.e.items()}
        try:
            time.strptime(d["day"], "%Y-%m-%d")
            amt = float(d["amount"])
            assert amt > 0 and d["collector"]
        except Exception:
            messagebox.showerror("Hand-over", "Enter a valid date, collector name and amount.", parent=self)
            return
        self.app.db.add_handover(d["day"], d["collector"], amt, d["note"])
        self.on_ok()
        self.destroy()


class CashbookPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Cash Book & Collectors", "daily collection • per collector • cash hand-over")
        self.cards = {}
        kpi_row(self, (("total", "Collected in range ৳", GREEN), ("cash", "of which Cash ৳", CYAN), ("digital", "bKash / Nagad / Bank … ৳", PURPLE),
                       ("pending", "Cash not yet handed over ৳", ORANGE)), self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        today = time.strftime("%Y-%m-%d")
        self.d1, self.d2 = tk.StringVar(value=today), tk.StringVar(value=today)
        self.op = tk.StringVar(value=app.settings.get("operator", ""))
        for lab, var, w in (("From", self.d1, 11), ("To", self.d2, 11)):
            tk.Label(f, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(0, 3))
            e = app.entry(f, w)
            e.configure(textvariable=var)
            e.pack(side="left", padx=(0, 8), ipady=3)
            e.bind("<Return>", lambda _e: self.refresh())
        for text, fn, col, w in (("↻ Refresh", self.refresh, "blue", 100), ("📅 Today", self.today, "cyan", 90), ("📅 This month", self.month, "cyan", 120),
                                 ("＋ Cash hand-over", self.handover, "green", 150), ("🖨 Print cash report", self.report, "purple", 160)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(0, 6))
        g = tk.Frame(self, bg=BG)
        g.pack(fill="x", pady=(0, 6))
        tk.Label(g, text="I am collecting as (shown as “received by” on every payment I take on this PC):", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        oe = app.entry(g, 22)
        oe.configure(textvariable=self.op)
        oe.pack(side="left", padx=8, ipady=3)
        oe.bind("<FocusOut>", lambda _e: self.save_op())
        oe.bind("<Return>", lambda _e: self.save_op())
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        tk.Label(left, text="Payments in range", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.tree = scrolled_tree(left, [("t", "TIME", 130), ("c", "PPPOE ID", 105), ("n", "CLIENT", 140), ("m", "MONTH", 65), ("a", "৳", 75, "e"),
                                           ("me", "METHOD", 70), ("b", "RECEIVED BY", 110), ("x", "TRX", 100)])
        w.pack(fill="both", expand=True)
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="y")
        tk.Label(right, text="By collector & method", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w2, self.cb = scrolled_tree(right, [("c", "COLLECTOR", 100), ("m", "METHOD", 65), ("n", "#", 35, "e"), ("t", "TOTAL ৳", 80, "e")], height=7)
        w2.pack(fill="x")
        tk.Label(right, text="Cash balance (all time)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w", pady=(10, 0))
        w3, self.bal = scrolled_tree(right, [("c", "COLLECTOR", 90), ("a", "CASH", 70, "e"), ("h", "HANDED", 70, "e"), ("p", "PENDING", 70, "e")], height=5)
        w3.pack(fill="x")
        self.bal.bind("<Double-1>", self._bal_handover)
        hb = tk.Frame(right, bg=BG)
        hb.pack(fill="x", pady=(10, 0))
        tk.Label(hb, text="Hand-overs (this month)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(side="left")
        GButton(hb, "− Delete", self.del_handover, "red", 80, 24, bg=BG).pack(side="right")
        w4, self.ho = scrolled_tree(right, [("d", "DATE", 80), ("c", "COLLECTOR", 85), ("a", "৳", 70, "e"), ("n", "NOTE", 80)], height=6)
        w4.pack(fill="x")
        self.rows = []

    def save_op(self):
        self.app.settings["operator"] = self.op.get().strip()
        self.app.apply_settings()

    def on_show(self):
        self.refresh()

    def today(self):
        self.d1.set(time.strftime("%Y-%m-%d"))
        self.d2.set(time.strftime("%Y-%m-%d"))
        self.refresh()

    def month(self):
        self.d1.set(time.strftime("%Y-%m-01"))
        self.d2.set(time.strftime("%Y-%m-%d"))
        self.refresh()

    def refresh(self):
        db = self.app.db
        a, b = self.d1.get().strip(), self.d2.get().strip()
        try:
            time.strptime(a, "%Y-%m-%d")
            time.strptime(b, "%Y-%m-%d")
        except ValueError:
            messagebox.showerror("Date", "Use YYYY-MM-DD.", parent=self.app)
            return
        self.rows = db.q("SELECT p.*, c.pppoe_id, c.name FROM payments p LEFT JOIN clients c ON c.id=p.client_id "
                         "WHERE substr(p.paid_at,1,10) BETWEEN ? AND ? ORDER BY p.id DESC LIMIT 5000", (a, b))
        self.tree.delete(*self.tree.get_children())
        for i, p in enumerate(self.rows):
            self.tree.insert("", "end", tags=("odd",) if i % 2 else (), values=(p["paid_at"], p["pppoe_id"], p["name"], p["month"], money(p["amount"]),
                                                                              p["method"], p["received_by"], p["trx"]))
        cb = db.cashbook(a, b)
        self.cb.delete(*self.cb.get_children())
        for r in cb:
            self.cb.insert("", "end", values=(r["collector"], r["method"], r["n"], money(r["total"])))
        tot = sum(r["total"] for r in cb)
        cash = sum(r["total"] for r in cb if r["method"] == "Cash")
        bal = db.cash_balance()
        self.bal.delete(*self.bal.get_children())
        for r in bal:
            self.bal.insert("", "end", tags=("due",) if r["pending"] > 0.5 else ("ok",), values=(r["collector"], money(r["collected"]), money(r["handed"]), money(r["pending"])))
        self.cards["total"].configure(text=money(tot))
        self.cards["cash"].configure(text=money(cash))
        self.cards["digital"].configure(text=money(tot - cash))
        self.cards["pending"].configure(text=money(sum(max(r["pending"], 0) for r in bal)))
        self.hrows = db.handovers(dbm.month_now())
        self.ho.delete(*self.ho.get_children())
        for h in self.hrows:
            self.ho.insert("", "end", iid=f"h{h['id']}", values=(h["day"], h["collector"], money(h["amount"]), h["note"]))

    def _bal_handover(self, _e=None):
        sel = self.bal.selection()
        if sel:
            v = self.bal.item(sel[0], "values")
            try:
                pend = float(str(v[3]).replace(",", ""))
            except ValueError:
                pend = 0
            HandoverDialog(self.app, self.refresh, v[0], max(pend, 0))

    def handover(self):
        HandoverDialog(self.app, self.refresh, self.op.get().strip())

    def del_handover(self):
        sel = self.ho.selection()
        if sel and messagebox.askyesno("Delete", "Delete this hand-over entry?", parent=self.app):
            self.app.db.delete_handover(int(sel[0][1:]))
            self.refresh()

    def report(self):
        db, e = self.app.db, html.escape
        a, b = self.d1.get().strip(), self.d2.get().strip()
        cb = db.cashbook(a, b)
        grp = "".join(f"<tr><td>{e(r['collector'])}</td><td>{e(r['method'])}</td><td class='r'>{r['n']}</td><td class='r'>{money(r['total'])}</td></tr>" for r in cb)
        rows = "".join(f"<tr><td>{e(p['paid_at'])}</td><td>{e(p['pppoe_id'])}</td><td>{e(p['name'])}</td><td>{p['month']}</td><td>{e(p['method'])}</td>"
                       f"<td>{e(p['received_by'])}</td><td class='r'>{money(p['amount'])}</td></tr>" for p in reversed(self.rows))
        bal = "".join(f"<tr><td>{e(r['collector'])}</td><td class='r'>{money(r['collected'])}</td><td class='r'>{money(r['handed'])}</td>"
                      f"<td class='r'><b>{money(r['pending'])}</b></td></tr>" for r in db.cash_balance())
        s = self.app.settings
        show_html(
            "<!doctype html><meta charset='utf-8'><title>Cash report</title><style>body{font-family:Segoe UI,Arial;margin:24px}"
            "table{border-collapse:collapse;width:100%;margin-bottom:18px}td,th{border:1px solid #ccc;padding:5px 8px;font-size:13px}"
            "th{background:#1d4ed8;color:#fff}td.r{text-align:right}h1{color:#1d4ed8;margin:0}</style>"
            f"<h1>{e(s.get('company', BRAND['company']))}</h1><h2>Cash report {e(a)} → {e(b)}</h2>"
            f"<h3>By collector</h3><table><tr><th>Collector</th><th>Method</th><th>#</th><th>৳</th></tr>{grp}</table>"
            f"<h3>Cash balance (all time)</h3><table><tr><th>Collector</th><th>Cash collected</th><th>Handed over</th><th>Pending</th></tr>{bal}</table>"
            f"<h3>All payments</h3><table><tr><th>Time</th><th>ID</th><th>Client</th><th>Month</th><th>Method</th><th>By</th><th>৳</th></tr>{rows}</table>"
            "<p>Collector signature: ____________________ &nbsp;&nbsp; Received by office: ____________________</p>", "cash_report")


# ======================================================================================================
# Inventory
# ======================================================================================================
class InventoryDialog(tk.Toplevel):
    def __init__(self, app, iid=None, on_ok=None):
        super().__init__(app)
        self.app, self.iid, self.on_ok = app, iid, on_ok
        self.d = next((r for r in app.db.inventory() if r["id"] == iid), {}) if iid else {}
        self.title("Edit equipment" if iid else "Add equipment")
        self.configure(bg=BG)
        self.transient(app)
        self.w = {}
        fields = (("Item name *", "item", 30), ("Type", "kind", 22), ("Model", "model", 26), ("Serial / MAC", "serial", 26), ("Quantity", "qty", 8),
                  ("Status", "status", 14), ("Unit cost ৳", "cost", 12), ("Note", "note", 34))
        for r, (lab, key, wd) in enumerate(fields):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=5)
            if key == "kind":
                w = combo(self, dbp.INV_KINDS, wd, state="normal")
            elif key == "status":
                w = combo(self, dbp.INV_STATUS, wd)
            else:
                w = app.entry(self, wd)
            default = {"kind": dbp.INV_KINDS[0], "status": "In stock", "qty": 1}.get(key, "")
            v = self.d.get(key, default)
            w.set(v) if isinstance(w, ttk.Combobox) else w.insert(0, str(v if v is not None else ""))
            w.grid(row=r, column=1, sticky="w", padx=14)
            self.w[key] = w
        r = len(fields)
        tk.Label(self, text="Assigned to client", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", padx=14, pady=5)
        self.cp = ClientPick(self, app, self.d.get("client_id"), 36)
        self.cp.grid(row=r, column=1, sticky="w", padx=14)
        app.button(self, "Save", self.ok, True).grid(row=r + 1, column=0, columnspan=2, sticky="ew", padx=14, pady=14)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def ok(self):
        d = {k: w.get().strip() for k, w in self.w.items()}
        if not d["item"]:
            messagebox.showerror("Equipment", "Item name is required.", parent=self)
            return
        try:
            d["qty"], d["cost"] = int(float(d["qty"] or 1)), float(d["cost"] or 0)
        except ValueError:
            messagebox.showerror("Equipment", "Quantity / cost must be numbers.", parent=self)
            return
        d["client_id"] = self.cp.get()
        if d["client_id"] and d["status"] == "In stock":
            d["status"] = "Assigned"
        d["id"] = self.iid
        self.app.db.save_inventory(d)
        if self.on_ok:
            self.on_ok()
        self.destroy()


class InventoryPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Inventory", "ONU • routers • cables • stock & assigned to clients")
        self.cards = {}
        kpi_row(self, (("items", "Item lines", BLUE), ("stock", "In stock (qty)", GREEN), ("assigned", "Assigned (qty)", CYAN),
                       ("faulty", "Faulty (qty)", RED), ("value", "Stock value ৳", PURPLE)), self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        self.status, self.q = tk.StringVar(value="All status"), tk.StringVar()
        self.q.trace_add("write", lambda *_: self.refresh())
        sc = combo(f, ["All status"] + dbp.INV_STATUS, 12, var=self.status)
        sc.pack(side="left", padx=(0, 6))
        sc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        e = app.entry(f, 24)
        e.configure(textvariable=self.q)
        e.pack(side="left", padx=(0, 8), ipady=3)
        for text, fn, col, w in (("＋ Add", self.add, "purple", 90), ("✎ Edit", self.edit, "blue", 90), ("− Delete", self.delete, "red", 90),
                                 ("⬇ Export CSV", self.export, "cyan", 120)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(0, 6))
        cols = [("i", "ITEM", 160), ("k", "TYPE", 120), ("m", "MODEL", 120), ("s", "SERIAL / MAC", 140), ("q", "QTY", 45, "e"), ("st", "STATUS", 80),
                ("c", "CLIENT", 180), ("v", "UNIT ৳", 70, "e"), ("n", "NOTE", 200)]
        w, self.tree = scrolled_tree(self, cols)
        w.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda _e: self.edit())
        self.rows = []

    def on_show(self):
        self.refresh()

    def refresh(self):
        st = "" if self.status.get() == "All status" else self.status.get()
        self.rows = rows = self.app.db.inventory(st, self.q.get().strip())
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(rows):
            tag = "bad" if r["status"] == "Faulty" else ("ok" if r["status"] == "In stock" else "")
            cl = f"{r['pppoe_id']} — {r['client_name']}" if r.get("pppoe_id") else ""
            self.tree.insert("", "end", iid=str(r["id"]), tags=(tag,) if tag else (), values=(
                r["item"], r["kind"], r["model"], r["serial"], r["qty"], r["status"], cl, money(r["cost"]), r["note"]))
        allr = self.app.db.inventory()
        qty = lambda s: sum(r["qty"] for r in allr if r["status"] == s)
        self.cards["items"].configure(text=str(len(allr)))
        self.cards["stock"].configure(text=str(qty("In stock")))
        self.cards["assigned"].configure(text=str(qty("Assigned")))
        self.cards["faulty"].configure(text=str(qty("Faulty")))
        self.cards["value"].configure(text=money(sum(r["cost"] * r["qty"] for r in allr if r["status"] == "In stock")))

    def add(self):
        InventoryDialog(self.app, None, self.refresh)

    def edit(self):
        sel = self.tree.selection()
        if sel:
            InventoryDialog(self.app, int(sel[0]), self.refresh)

    def delete(self):
        sel = self.tree.selection()
        if sel and messagebox.askyesno("Delete", f"Delete {len(sel)} item line(s)?", parent=self.app):
            for i in sel:
                self.app.db.delete_inventory(int(i))
            self.refresh()

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="inventory.csv", parent=self.app)
        if f:
            self.app.db.export_csv(f, self.rows, ["item", "kind", "model", "serial", "qty", "status", "pppoe_id", "client_name", "cost", "note"])


# ======================================================================================================
# Router & data audit
# ======================================================================================================
class AuditPage(Page):
    FIX_HINT = {
        "Not on router (create with Push)": "⬆ Push to router creates the PPPoE secret",
        "Package ≠ router PPP profile": "⬆ Push to router sets the profile from the package",
        "Overdue but still active": "⏸ Suspend on router",
        "Suspended but fully paid": "▶ Enable on router",
    }

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Router & Data Audit", "router ↔ database mismatches • missing data • duplicates")
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        self.check = tk.StringVar()
        self.cc = combo(f, [], 44, var=self.check)
        self.cc.pack(side="left", padx=(0, 8))
        self.cc.bind("<<ComboboxSelected>>", lambda _e: self.show())
        for text, fn, col, w in (("↻ Run audit", self.run, "blue", 110), ("⬆ Push to router", self.push, "purple", 140),
                                 ("⏸ Suspend", lambda: self.state(False), "orange", 100), ("▶ Enable", lambda: self.state(True), "cyan", 100),
                                 ("✎ Open client", self.open_client, "green", 120), ("⬇ Export CSV", self.export, "blue", 110)):
            GButton(f, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(0, 6))
        self.hint = tk.Label(self, text="", bg=BG, fg=MUTED, font=(FONT, 9), anchor="w")
        self.hint.pack(fill="x")
        wrap, self.tree = scrolled_tree(self, [("c", "PPPOE ID", 130), ("n", "CLIENT", 170), ("r", "ROUTER", 120), ("d", "FINDING", 520)])
        wrap.pack(fill="both", expand=True)
        self.tree.configure(selectmode="extended")
        self.tree.bind("<Double-1>", lambda _e: self.open_client())
        self.res = {}

    def on_show(self):
        self.run()

    def on_sync(self):
        pass

    def run(self):
        self.res = self.app.db.audit_checks(int(self.app.settings.get("due_day", 10) or 10))
        keep = self.check.get()
        names = [f"{k}  ({len(v)})" for k, v in self.res.items()]
        self.cc["values"] = names
        pick = next((n for n in names if n.startswith(keep.rsplit("  (", 1)[0])), None) if keep else None
        if pick is None:
            pick = next((n for n in names if not n.endswith("(0)")), names[0])
        self.check.set(pick)
        self.show()

    def _key(self):
        return self.check.get().rsplit("  (", 1)[0]

    def show(self):
        rows = self.res.get(self._key(), [])
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(rows):
            self.tree.insert("", "end", iid=str(r["id"]), tags=("odd",) if i % 2 else (), values=(r["pppoe_id"], r["name"], r["router"], r["detail"]))
        fix = self.FIX_HINT.get(self._key(), "no automatic fix — open the client and correct the data")
        self.hint.configure(text=f"{len(rows)} finding(s) • suggested fix: {fix}", fg=GREEN if not rows else ORANGE)

    def _ids(self):
        ids = [int(i) for i in self.tree.selection()] or [int(i) for i in self.tree.get_children()]
        return ids

    def push(self):
        ids = self._ids()
        if ids and messagebox.askyesno("Push to router", f"Create / update {len(ids)} PPPoE secret(s) on their routers?", parent=self.app):
            self.app.push_clients(ids)
            self.after(2500, self.run)

    def state(self, enable):
        ids = [int(i) for i in self.tree.selection()]
        if not ids:
            messagebox.showinfo("Select", "Select one or more rows first.", parent=self.app)
            return
        db = self.app.db

        def done(ok):
            for i in ok:
                db.set_status(i, "active" if enable else "suspended")
            self.run()

        def op(link, c):
            link.secret_enable(c["pppoe_id"], enable)
            if not enable:
                link.kick(c["pppoe_id"])
        self.app.router_op(ids, op, "Enable" if enable else "Suspend", done=done, skip_not_on_router=True)

    def open_client(self):
        sel = self.tree.selection()
        if sel:
            ClientDialog(self.app, int(sel[0]), self.run)

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="audit.csv", parent=self.app)
        if f:
            rows = self.res.get(self._key(), [])
            self.app.db.export_csv(f, rows, ["pppoe_id", "name", "router", "detail"])


# ======================================================================================================
# Client extras dialog (ONU, map, due-day, grace, exempt, installation / one-time charges, usage)
# ======================================================================================================
class ClientExtrasDialog(tk.Toplevel):
    def __init__(self, app, cid, on_done=None):
        super().__init__(app)
        self.app, self.cid, self.on_done = app, cid, on_done
        c = app.db.client(cid)
        self.title(f"Client extras — {c['pppoe_id']}")
        self.configure(bg=BG)
        self.transient(app)
        m = app.db.meta(cid)
        tk.Label(self, text=f"{c['pppoe_id']}  •  {c['name']}  •  {c['phone1']}", bg=BG, fg=CYAN, font=(FONT, 11, "bold")).grid(
            row=0, column=0, columnspan=4, sticky="w", padx=14, pady=(12, 4))
        self.w = {}
        fields = (("ONU / ONT MAC or serial", "onu_mac", 26), ("OLT / PON port or switch port", "olt_port", 26), ("Connection type", "conn_type", 26),
                  ("Referred by", "referrer", 26), ("Latitude", "lat", 14), ("Longitude", "lng", 14),
                  ("Own due day of month (0 = default)", "due_day", 8), ("Extra grace days before auto-suspend", "grace_days", 8),
                  ("Installation fee ৳ (record)", "install_fee", 10), ("Note", "note", 40))
        for i, (lab, key, wd) in enumerate(fields):
            r, col = 1 + i // 2, (i % 2) * 2
            if key == "note":
                r, col = 1 + len(fields) // 2, 0
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=col, sticky="w", padx=(14, 6), pady=4)
            w = combo(self, dbp.CONN_TYPES, wd) if key == "conn_type" else app.entry(self, wd)
            v = m.get(key, "")
            w.set(v) if isinstance(w, ttk.Combobox) else w.insert(0, str(v if v is not None else ""))
            w.grid(row=r, column=col + 1, sticky="w", padx=(0, 10))
            self.w[key] = w
        row = 2 + len(fields) // 2
        self.exempt = tk.BooleanVar(value=bool(m.get("exempt")))
        tk.Checkbutton(self, text="Never auto-suspend this client (VIP / free / agreed delay)", variable=self.exempt, bg=BG, fg=TEXT,
                       selectcolor=PANEL2, activebackground=BG, activeforeground=CYAN).grid(row=row, column=0, columnspan=4, sticky="w", padx=14, pady=4)
        bar = tk.Frame(self, bg=BG)
        bar.grid(row=row + 1, column=0, columnspan=4, sticky="w", padx=14, pady=4)
        for text, fn, color, w in (("💾 Save extras", self.save, "purple", 130), ("🗺 Open map", self.map, "cyan", 110), ("📈 Usage", self.usage, "green", 90)):
            GButton(bar, text, fn, color, w, 30, bg=BG).pack(side="left", padx=(0, 6))
        tk.Label(self, text="One-time charges (added to that month's bill)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).grid(
            row=row + 2, column=0, columnspan=4, sticky="w", padx=14, pady=(10, 2))
        ch = tk.Frame(self, bg=BG)
        ch.grid(row=row + 3, column=0, columnspan=4, sticky="w", padx=14)
        self.cm = tk.StringVar(value=month_choices()[2])
        combo(ch, month_choices(), 16, var=self.cm).pack(side="left", padx=(0, 6))
        self.ct = combo(ch, ["Installation fee", "ONU / router sale", "Reconnection fee", "Relocation fee", "Cable / material", "Penalty", "Other"], 18, state="normal")
        self.ct.set("Installation fee")
        self.ct.pack(side="left", padx=(0, 6))
        self.ca = app.entry(ch, 10)
        self.ca.pack(side="left", padx=(0, 6), ipady=3)
        GButton(ch, "＋ Add charge", self.add_charge, "orange", 120, 28, bg=BG).pack(side="left", padx=(0, 6))
        GButton(ch, "− Remove", self.del_charge, "red", 90, 28, bg=BG).pack(side="left")
        wrap, self.tree = scrolled_tree(self, [("m", "MONTH", 80), ("t", "CHARGE", 200), ("a", "৳", 80, "e"), ("d", "ADDED", 130)], height=5)
        wrap.grid(row=row + 4, column=0, columnspan=4, sticky="ew", padx=14, pady=(4, 12))
        self.load_charges()
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def load_charges(self):
        self.tree.delete(*self.tree.get_children())
        for ch in self.app.db.charges(self.cid):
            self.tree.insert("", "end", iid=str(ch["id"]), values=(ch["month"], ch["title"], money(ch["amount"]), ch["created"]))

    def _data(self):
        d = {k: w.get().strip() for k, w in self.w.items()}
        d["exempt"] = 1 if self.exempt.get() else 0
        return d

    def save(self):
        try:
            self.app.db.save_meta(self.cid, self._data())
        except ValueError:
            messagebox.showerror("Extras", "Due day, grace days and fee must be numbers.", parent=self)
            return
        if self.on_done:
            self.on_done()
        messagebox.showinfo("Saved", "Client extras saved.", parent=self)

    def map(self):
        import webbrowser
        d = self._data()
        if d["lat"] and d["lng"]:
            webbrowser.open(f"https://www.google.com/maps?q={d['lat']},{d['lng']}")
        else:
            c = self.app.db.client(self.cid)
            import urllib.parse
            webbrowser.open("https://www.google.com/maps/search/" + urllib.parse.quote(c["address"] or c["name"] or c["pppoe_id"]))

    def usage(self):
        UsageDialog(self.app, self.cid)

    def add_charge(self):
        try:
            amt = float(self.ca.get())
            assert amt > 0
        except Exception:
            messagebox.showerror("Charge", "Enter a valid amount.", parent=self)
            return
        self.app.db.add_charge(self.cid, mkey(self.cm.get()), self.ct.get().strip() or "Charge", amt)
        self.ca.delete(0, "end")
        self.load_charges()
        if self.on_done:
            self.on_done()

    def del_charge(self):
        sel = self.tree.selection()
        if sel and messagebox.askyesno("Remove", "Remove this charge from the bill?", parent=self):
            self.app.db.delete_charge(int(sel[0]))
            self.load_charges()
            if self.on_done:
                self.on_done()


# ======================================================================================================
# Network totals & smart insights (auto-synced from every router / device)
# ======================================================================================================
class TotalsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Network Totals & Insights", "everything auto-synced from all routers & devices")
        self.cards = {}
        kpi_row(self, (("total", "Total clients", BLUE), ("online", "Online now", GREEN), ("offline", "Offline (active)", ORANGE),
                       ("susp", "Suspended", RED), ("mrr", "Monthly revenue ৳", PURPLE), ("due", "Total due ৳", ORANGE), ("rt", "Routers up / total", CYAN)),
                self.cards)
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        GButton(f, "⇅ Sync all devices now", self.sync_all, "green", 190, 30, bg=BG).pack(side="left")
        self.info = tk.Label(f, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.info.pack(side="left", padx=12)
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="both", expand=True, padx=(0, 8))
        tk.Label(left, text="Per router / device (auto-updated every sync)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        w, self.tree = scrolled_tree(left, [("r", "ROUTER", 130), ("p", "PROTO", 60), ("s", "STATE", 80), ("t", "SECRETS", 65, "e"), ("c", "CLIENTS", 65, "e"),
                                           ("o", "ONLINE", 65, "e"), ("su", "SUSP.", 55, "e"), ("m", "REVENUE ৳", 85, "e"), ("cpu", "CPU", 45, "e"),
                                           ("ut", "UPTIME", 90), ("sy", "LAST SYNC", 75)], height=8)
        w.pack(fill="x")
        tk.Label(left, text="Users online — last 24 h (hourly average, all routers)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w", pady=(10, 2))
        self.chart = tk.Canvas(left, height=130, bg=CARD, highlightthickness=1, highlightbackground=BORDER)
        self.chart.pack(fill="x")
        right = tk.Frame(body, bg=BG)
        right.pack(side="left", fill="both", expand=True)
        tk.Label(right, text="Smart insights", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w")
        self.ins = tk.Text(right, bg=CARD, fg=TEXT, relief="flat", wrap="word", font=(FONT, 10), highlightthickness=1, highlightbackground=BORDER, padx=10, pady=8)
        self.ins.pack(fill="both", expand=True)
        for tag, col in (("info", CYAN), ("warn", ORANGE), ("bad", RED), ("ok", GREEN)):
            self.ins.tag_configure(tag, foreground=col, spacing3=6)

    def on_show(self):
        self.refresh()

    def on_sync(self):
        if self.winfo_ismapped():
            self.refresh()

    def sync_all(self):
        n = self.app.sync.sync_all()
        self.info.configure(text=f"{n} device(s) syncing …", fg=ORANGE)

    def refresh(self):
        app, db = self.app, self.app.db
        t = db.totals()
        st = app.sync.status
        up = sum(1 for p in app.profiles if st.get(p["name"], {}).get("state") == "ok")
        self.cards["total"].configure(text=str(t["total"]))
        self.cards["online"].configure(text=str(t["online"]))
        self.cards["offline"].configure(text=str(max(t["active"] - t["online"], 0)))
        self.cards["susp"].configure(text=str(t["suspended"]))
        self.cards["mrr"].configure(text=money(t["mrr"]))
        self.cards["due"].configure(text=money(db.summary(dbm.month_now())["total_due"]))
        self.cards["rt"].configure(text=f"{up} / {len(app.profiles)}")
        pc = db.per_router_counts()
        self.tree.delete(*self.tree.get_children())
        for p in app.profiles:
            s, c = st.get(p["name"], {}), pc.get(p["name"], {})
            state = s.get("state", "—")
            self.tree.insert("", "end", tags=("ok",) if state == "ok" else (("bad",) if state in ("error", "no-password") else ()), values=(
                p["name"], p.get("proto", "api").upper(), state, s.get("ppp_total", ""), c.get("clients", 0), c.get("online", 0) or 0,
                c.get("suspended", 0) or 0, money(c.get("mrr", 0)), s.get("cpu", ""), s.get("uptime", ""),
                time.strftime("%H:%M:%S", time.localtime(s["ts"])) if s.get("ts") else ""))
        tr = db.online_trend(24)
        self.after(50, lambda: bar_chart(self.chart, [(r["h"], r["online"], 0) for r in tr], unit=lambda v: f"{v:.0f} users"))
        self.ins.configure(state="normal")
        self.ins.delete("1.0", "end")
        icon = {"info": "ℹ ", "warn": "⚠ ", "bad": "🔴 ", "ok": "✔ "}
        for lvl, text in db.insights(int(app.settings.get("due_day", 10) or 10)):
            self.ins.insert("end", icon.get(lvl, "") + text + "\n", lvl)
        self.ins.configure(state="disabled")
        self.info.configure(text=f"updated {time.strftime('%H:%M:%S')}", fg=MUTED)


PAGE_KINDS.update({"totals": TotalsPage, "usage": UsagePage, "analytics": AnalyticsPage, "cashbook": CashbookPage, "inventory": InventoryPage, "audit": AuditPage})
