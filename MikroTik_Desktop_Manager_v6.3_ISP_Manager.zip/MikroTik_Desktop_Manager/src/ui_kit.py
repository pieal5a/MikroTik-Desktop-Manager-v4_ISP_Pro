"""RouterPilot-style graphical widgets drawn on tk.Canvas (standard library only)."""
import math
import tkinter as tk
from collections import deque

FONT = "Segoe UI"
MONO = "Consolas"

# ---- palette (dark navy + neon accents, as in the RouterPilot reference) ------------------
BG, SIDEBAR, TOPBAR = "#060d1b", "#081226", "#08142a"
CARD, CARD2, BORDER = "#0c1a33", "#102345", "#1b3358"
TEXT, MUTED, DIM = "#eaf3ff", "#8aa3c4", "#5a7396"
BLUE, CYAN, GREEN, ORANGE = "#2f8cff", "#22d3ee", "#22e08a", "#ff9f1c"
RED, PURPLE, PINK, YELLOW = "#ff4d6d", "#a855f7", "#ec4899", "#ffd166"

# card gradients: (left/top colour, right/bottom colour)
GRAD = {
    "blue": ("#0b3d91", "#1e7bff"), "green": ("#04613f", "#14c97a"),
    "orange": ("#8a4a00", "#f59e0b"), "red": ("#7a0f2a", "#ff3d5e"),
    "purple": ("#3b1a8f", "#8b5cf6"), "cyan": ("#075985", "#06b6d4"),
}


def lerp(c1, c2, t):
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def rrect(c, x1, y1, x2, y2, r=14, **kw):
    pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2, x2 - r, y2,
           x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(pts, smooth=True, **kw)


def gradient(c, x1, y1, x2, y2, c1, c2, steps=24, horizontal=True, tags=()):
    for i in range(steps):
        col = lerp(c1, c2, i / max(steps - 1, 1))
        if horizontal:
            a, b = x1 + (x2 - x1) * i / steps, x1 + (x2 - x1) * (i + 1) / steps + 1
            c.create_rectangle(a, y1, b, y2, fill=col, outline=col, tags=tags)
        else:
            a, b = y1 + (y2 - y1) * i / steps, y1 + (y2 - y1) * (i + 1) / steps + 1
            c.create_rectangle(x1, a, x2, b, fill=col, outline=col, tags=tags)


def fmt_rate(bps):
    n = float(bps or 0)
    for unit in ("bps", "Kbps", "Mbps", "Gbps"):
        if n < 1000:
            return f"{n:.2f} {unit}" if unit in ("Mbps", "Gbps") else f"{n:.0f} {unit}"
        n /= 1000
    return f"{n:.2f} Tbps"


def short_rate(bps):
    for unit, d in (("G", 1e9), ("M", 1e6), ("K", 1e3)):
        if bps >= d:
            v = bps / d
            return (f"{v:.0f}" if v >= 100 else f"{v:.1f}").rstrip("0").rstrip(".") + unit
    return f"{bps:.0f}"


def spark_points(values, x1, y1, x2, y2, lo=None, hi=None):
    if len(values) < 2:
        return []
    lo = min(values) if lo is None else lo
    hi = max(values) if hi is None else hi
    span = (hi - lo) or 1
    pts = []
    for i, v in enumerate(values):
        pts += [x1 + (x2 - x1) * i / (len(values) - 1), y2 - (y2 - y1) * (v - lo) / span]
    return pts


# ---------------------------------------------------------------------------------------
class Panel(tk.Canvas):
    """Rounded dark card with an optional title; children are placed in `.body` frame."""

    def __init__(self, parent, title="", icon="", accent=CYAN, link=None, **kw):
        super().__init__(parent, bg=BG, highlightthickness=0, **kw)
        self.title, self.icon, self.accent, self.link = title, icon, accent, link
        self.body = tk.Frame(self, bg=CARD)
        self._win = self.create_window(12, 40 if title else 12, window=self.body, anchor="nw")
        self.bind("<Configure>", self._draw)

    def _draw(self, _e=None):
        w, h = self.winfo_width(), self.winfo_height()
        if w < 40 or h < 40:
            return
        self.delete("bg")
        rrect(self, 1, 1, w - 2, h - 2, 16, fill=CARD, outline=BORDER, tags="bg")
        if self.title:
            self.create_text(16, 20, text=self.icon, fill=self.accent, anchor="w", font=(FONT, 13, "bold"), tags="bg")
            self.create_text(40 if self.icon else 16, 20, text=self.title, fill=TEXT, anchor="w",
                             font=(FONT, 11, "bold"), tags="bg")
            if self.link:
                t = self.create_text(w - 16, 20, text=self.link[0], fill=BLUE, anchor="e", font=(FONT, 9, "bold"),
                                     tags="bg")
                self.tag_bind(t, "<Button-1>", lambda _e: self.link[1]())
        top = 40 if self.title else 12
        self.itemconfigure(self._win, width=max(w - 24, 10), height=max(h - top - 12, 10))
        self.tag_lower("bg")


class StatCard(tk.Canvas):
    """Gradient KPI card with label, big value, delta and a live sparkline."""

    def __init__(self, parent, label, color="blue", glyph="◼", **kw):
        super().__init__(parent, bg=BG, highlightthickness=0, height=104, **kw)
        self.label, self.color, self.glyph = label, color, glyph
        self.value, self.delta, self.series = "—", "", deque(maxlen=40)
        self.bind("<Configure>", lambda _e: self.draw())

    def set(self, value, delta="", sample=None):
        self.value, self.delta = str(value), delta
        if sample is not None:
            self.series.append(float(sample))
        self.draw()

    def draw(self):
        c, w, h = self, self.winfo_width(), self.winfo_height()
        if w < 60:
            return
        c.delete("all")
        c1, c2 = GRAD[self.color]
        gradient(c, 2, 2, w - 2, h - 2, c1, c2, steps=28)
        c.create_rectangle(1, 1, w - 1, h - 1, outline=lerp(c2, "#ffffff", .25), width=1)
        c.create_text(16, 20, text=self.label, anchor="w", fill="#dbeafe", font=(FONT, 10))
        c.create_text(16, 52, text=self.value, anchor="w", fill="white", font=(FONT, 24 if len(self.value) <= 6 else 20, "bold"))
        if self.delta:
            c.create_text(16, 86, text=self.delta, anchor="w", fill="#eafff4", font=(FONT, 9, "bold"))
        # glyph badge
        c.create_oval(w - 54, 10, w - 14, 50, fill=lerp(c2, "#ffffff", .22), outline="")
        c.create_text(w - 34, 30, text=self.glyph, fill="white", font=(FONT, 15, "bold"))
        # sparkline
        vals = list(self.series)
        if len(vals) > 2 and max(vals) > min(vals):
            x1, x2, y1, y2 = w * .55, w - 14, 62, h - 12
            pts = spark_points(vals, x1, y1, x2, y2)
            c.create_polygon(pts + [x2, y2, x1, y2], fill=lerp(c2, "#ffffff", .18), outline="", stipple="gray50")
            c.create_line(*pts, fill="white", width=2, smooth=True)


class Gauge(tk.Canvas):
    """Ring gauge with a centred label (CPU / Memory / Disk / Uptime)."""

    def __init__(self, parent, name, color, size=92, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, width=size, height=size + 22, **kw)
        self.name, self.color, self.size = name, color, size
        self.pct, self.text = 0, "—"
        self.draw()

    def set(self, pct, text=None):
        self.pct = max(0, min(100, float(pct or 0)))
        self.text = text if text is not None else f"{self.pct:.0f}%"
        self.draw()

    def draw(self):
        c, s = self, self.size
        c.delete("all")
        c.create_oval(8, 8, s - 8, s - 8, outline="#16294a", width=8)
        if self.pct > 0:
            col = self.color if self.pct < 85 else RED
            c.create_arc(8, 8, s - 8, s - 8, start=90, extent=-3.6 * self.pct, style="arc", outline=col, width=8)
        c.create_text(s / 2, s / 2, text=self.text, fill=TEXT, font=(FONT, 11 if len(self.text) < 6 else 9, "bold"),
                      justify="center")
        c.create_text(s / 2, s + 10, text=self.name, fill=MUTED, font=(FONT, 9))


class Donut(tk.Canvas):
    """Donut chart with centre text; slices = [(value, colour), ...]."""

    def __init__(self, parent, size=110, thick=16, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, width=size, height=size, **kw)
        self.size, self.thick, self.slices, self.center = size, thick, [], ("", "")
        self.draw()

    def set(self, slices, big="", small=""):
        self.slices, self.center = slices, (big, small)
        self.draw()

    def draw(self):
        c, s, t = self, self.size, self.thick
        c.delete("all")
        pad = t / 2 + 3
        total = sum(v for v, _ in self.slices) or 0
        if not total:
            c.create_oval(pad, pad, s - pad, s - pad, outline="#16294a", width=t)
        else:
            start = 90.0
            for v, col in self.slices:
                if v <= 0:
                    continue
                ext = -360.0 * v / total
                c.create_arc(pad, pad, s - pad, s - pad, start=start, extent=ext - (0.0 if len(self.slices) == 1 else 1.5),
                             style="arc", outline=col, width=t)
                start += ext
        big = self.center[0]
        c.create_text(s / 2, s / 2 - 7, text=big, fill=TEXT, font=(FONT, 14 if len(big) <= 4 else 11 if len(big) <= 6 else 9 if len(big) <= 9 else 8, "bold"))
        c.create_text(s / 2, s / 2 + 11, text=self.center[1], fill=MUTED, font=(FONT, 8))


class LineChart(tk.Canvas):
    """Two-series area chart (download blue / upload green) with grid and time axis."""

    def __init__(self, parent, n=60, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, **kw)
        self.n = n
        self.a, self.b = deque(maxlen=n), deque(maxlen=n)
        self.ca, self.cb = BLUE, GREEN
        self.stamps = deque(maxlen=n)
        self.bind("<Configure>", lambda _e: self.draw())

    def push(self, a, b, stamp=""):
        self.a.append(float(a or 0))
        self.b.append(float(b or 0))
        self.stamps.append(stamp)
        self.draw()

    def clear(self):
        self.a.clear(); self.b.clear(); self.stamps.clear()
        self.draw()

    def set(self, a, b, stamps, ca=None, cb=None):
        """Plot full series (lists); x axis is stretched over the given length."""
        self.a, self.b, self.stamps = list(a), list(b), list(stamps)
        self.n = max(len(self.a), 2)
        if ca:
            self.ca, self.cb = ca, cb or self.cb
        self.draw()

    def draw(self):
        c, w, h = self, self.winfo_width(), self.winfo_height()
        if w < 160 or h < 80:
            return
        c.delete("all")
        L, R, T, B = 74, 26, 8, 24
        peak = max(max(self.a, default=0), max(self.b, default=0), 1000.0) * 1.15
        for i in range(5):
            y = B_y = h - B - (h - B - T) * i / 4
            c.create_line(L, y, w - R, y, fill="#14284a")
            c.create_text(L - 6, y, text=short_rate(peak * i / 4), fill=DIM, anchor="e", font=(FONT, 8))
        for series, col in ((self.a, self.ca), (self.b, self.cb)):
            vals = list(series)
            if len(vals) < 2:
                continue
            x_of = lambda i: L + (w - L - R) * (self.n - len(vals) + i) / (self.n - 1)
            pts = []
            for i, v in enumerate(vals):
                pts += [x_of(i), h - B - (h - B - T) * v / peak]
            c.create_polygon(pts + [x_of(len(vals) - 1), h - B, x_of(0), h - B], fill=lerp(col, CARD, .72),
                             outline="", stipple="gray50")
            c.create_line(*pts, fill=col, width=2, smooth=True)
        st = list(self.stamps)
        if st:
            for k in range(0, 5):
                idx = int((len(st) - 1) * k / 4)
                x = L + (w - L - R) * (self.n - len(st) + idx) / (self.n - 1)
                c.create_text(x, h - 10, text=st[idx], fill=DIM, font=(FONT, 8), anchor="e" if k == 4 else "center")


class BarList(tk.Canvas):
    """Top-N list with progress bars: rows = [(label, fraction 0-1, right_text, colour)]."""

    def __init__(self, parent, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, **kw)
        self.rows = []
        self.bind("<Configure>", lambda _e: self.draw())

    def set(self, rows):
        self.rows = rows
        self.draw()

    @staticmethod
    def _s(bps):
        for unit, d in (("G", 1e9), ("M", 1e6), ("K", 1e3)):
            if bps >= d:
                v = bps / d
                return (f"{v:.0f}" if v >= 100 else f"{v:.1f}").rstrip("0").rstrip(".") + unit
        return f"{bps:.0f}"

    def draw(self):
        c, w = self, self.winfo_width()
        c.delete("all")
        if w < 120:
            return
        for i, (label, frac, right, col) in enumerate(self.rows):
            y = 12 + i * 24
            c.create_text(0, y, text=label[:11], anchor="w", fill=TEXT, font=(FONT, 8))
            x1, x2 = 72, w - 78
            c.create_rectangle(x1, y - 3, x2, y + 3, fill="#14284a", outline="")
            c.create_rectangle(x1, y - 3, x1 + max((x2 - x1) * frac, 2), y + 3, fill=col, outline="")
            c.create_text(w, y, text=right, anchor="e", fill=MUTED, font=(FONT, 8))


class Topology(tk.Canvas):
    """Mini network map: nodes = {id: (label, rel_x, rel_y, colour, glyph)}, links = [(a, b, colour)]."""

    def __init__(self, parent, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, **kw)
        self.nodes, self.links, self.on_click = {}, [], None
        self.bind("<Configure>", lambda _e: self.draw())
        self.bind("<Button-1>", self._click)
        self.hits = []

    def set(self, nodes, links):
        self.nodes, self.links = nodes, links
        self.draw()

    def _click(self, e):
        for nid, x, y in self.hits:
            if abs(e.x - x) < 22 and abs(e.y - y) < 18 and self.on_click:
                self.on_click(nid)
                return

    def draw(self):
        c, w, h = self, self.winfo_width(), self.winfo_height()
        if w < 120 or h < 80:
            return
        c.delete("all")
        pos = {k: (v[1] * w, v[2] * h) for k, v in self.nodes.items()}
        for a, b, col in self.links:
            if a in pos and b in pos:
                (x1, y1), (x2, y2) = pos[a], pos[b]
                c.create_line(x1, y1, x1, (y1 + y2) / 2, x2, (y1 + y2) / 2, x2, y2, fill=col, width=2)
        self.hits = []
        for k, (label, rx, ry, col, glyph) in self.nodes.items():
            x, y = pos[k]
            rrect(c, x - 15, y - 12, x + 15, y + 12, 7, fill=col, outline=lerp(col, "#ffffff", .35))
            c.create_text(x, y, text=glyph, fill="white", font=(FONT, 12, "bold"))
            c.create_text(x, y + 20, text=label, fill=TEXT, font=(FONT, 8))
            self.hits.append((k, x, y))


class Badge(tk.Label):
    COLORS = {"online": ("#064e3b", GREEN), "warning": ("#78350f", ORANGE), "offline": ("#7f1d1d", RED),
              "established": ("#064e3b", GREEN), "idle": ("#1e3a8a", BLUE)}

    def __init__(self, parent, status, **kw):
        bg, fg = self.COLORS.get(status, ("#1e293b", MUTED))
        super().__init__(parent, text=status, bg=bg, fg=fg, font=(FONT, 8, "bold"), padx=8, pady=1, **kw)


class GButton(tk.Canvas):
    """Gradient pill button."""

    def __init__(self, parent, text, command, color="blue", width=110, height=32, bg=CARD):
        super().__init__(parent, bg=bg, highlightthickness=0, width=width, height=height, cursor="hand2")
        self.text, self.command, self.color, self.w, self.h = text, command, color, width, height
        self.draw(False)
        self.bind("<Enter>", lambda _e: self.draw(True))
        self.bind("<Leave>", lambda _e: self.draw(False))
        self.bind("<Button-1>", lambda _e: self.command())

    def draw(self, hot):
        self.delete("all")
        c1, c2 = GRAD[self.color]
        gradient(self, 0, 0, self.w, self.h, lerp(c1, "#ffffff", .15 if hot else 0), lerp(c2, "#ffffff", .15 if hot else 0), 18)
        self.create_text(self.w / 2, self.h / 2, text=self.text, fill="white", font=(FONT, 9, "bold"))


class ToolTile(tk.Canvas):
    """Quick-tool tile with coloured glyph."""

    def __init__(self, parent, text, glyph, color, command, active=False, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, height=54, cursor="hand2", **kw)
        self.text, self.glyph, self.color, self.command, self.active = text, glyph, color, command, active
        self.hot = False
        self.bind("<Configure>", lambda _e: self.draw())
        self.bind("<Enter>", lambda _e: self._h(True))
        self.bind("<Leave>", lambda _e: self._h(False))
        self.bind("<Button-1>", lambda _e: self.command())

    def _h(self, v):
        self.hot = v
        self.draw()

    def draw(self):
        w, h = self.winfo_width(), self.winfo_height()
        if w < 30:
            return
        self.delete("all")
        if self.active:
            gradient(self, 0, 0, w, h, "#1d4ed8", "#38bdf8", 20)
        else:
            rrect(self, 1, 1, w - 1, h - 1, 10, fill=CARD2 if not self.hot else "#16315f", outline=BORDER)
        self.create_text(w / 2, 18, text=self.glyph, fill="white" if self.active else self.color, font=(FONT, 14, "bold"))
        self.create_text(w / 2, 40, text=self.text, fill=TEXT, font=(FONT, 7))
