"""Notifications & automation (v5): Telegram bot, HTTP SMS gateway, bulk due reminders (SMS / WhatsApp), daily summary,
router-down alerts, payment SMS and automatic daily database backup.  Everything uses only the standard library."""
import threading
import time
import tkinter as tk
import urllib.parse
import urllib.request
import webbrowser
from tkinter import ttk, messagebox

import db as dbm
from core import *
from core import PAGE_KINDS
from isp_common import *
from ui_kit import GButton, Panel


def norm_phone(phone, local=False):
    """01XXXXXXXXX -> 8801XXXXXXXXX (or the 11-digit local form when local=True)."""
    p = "".join(ch for ch in (phone or "") if ch.isdigit())
    if p.startswith("8801") and len(p) == 13:
        p = p[2:]
    elif p.startswith("1") and len(p) == 10:
        p = "0" + p
    if local:
        return p
    return "88" + p if p.startswith("01") and len(p) == 11 else p


def _http(url, data=None, timeout=15):
    req = urllib.request.Request(url, data=data, headers={"User-Agent": "MikroTikDesktopManager/5"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read(400).decode("utf-8", "replace")


class Notifier:
    """Owned by the App (app.notifier). All network calls run on worker threads and never raise into the UI."""

    def __init__(self, app):
        self.app = app
        self.lock = threading.Lock()

    # ---- configuration ----------------------------------------------------------------------------------------
    def cfg(self, key, default=""):
        return self.app.settings.get(key, default)

    def telegram_ready(self):
        return bool(self.cfg("tg_token") and self.cfg("tg_chat"))

    def sms_ready(self):
        return bool(self.cfg("sms_url"))

    # ---- senders (blocking; call from worker threads) ----------------------------------------------------------
    def telegram(self, text):
        if not self.telegram_ready():
            return False, "Telegram bot token / chat id not set"
        url = f"https://api.telegram.org/bot{self.cfg('tg_token').strip()}/sendMessage"
        body = urllib.parse.urlencode({"chat_id": self.cfg("tg_chat").strip(), "text": text}).encode()
        try:
            code, resp = _http(url, body)
            return code == 200, resp[:120]
        except Exception as e:
            return False, str(e)

    def sms(self, phone, text, log=True):
        if not self.sms_ready():
            return False, "SMS gateway URL not set (Automation & Alerts)"
        num = norm_phone(phone)
        if len(num) < 10:
            return False, "bad phone number"
        enc = urllib.parse.quote
        url = (self.cfg("sms_url").replace("{phone}", enc(num)).replace("{phone_local}", enc(norm_phone(phone, True)))
               .replace("{text}", enc(text)))
        try:
            if self.cfg("sms_method", "GET") == "POST":
                base, _, qs = url.partition("?")
                code, resp = _http(base, qs.encode() if qs else b"")
            else:
                code, resp = _http(url)
            ok, msg = 200 <= code < 300, f"HTTP {code} {resp[:80]}".strip()
        except Exception as e:
            ok, msg = False, str(e)
        if log:
            try:
                self.app.db.log_msg(num, "sms", text, "ok" if ok else msg)
            except Exception:
                pass
        return ok, msg

    # ---- fire-and-forget helpers -------------------------------------------------------------------------------
    def notify(self, text):
        """Telegram message to the owner (only if configured)."""
        if self.telegram_ready():
            threading.Thread(target=self.telegram, args=(text,), daemon=True).start()

    def router_event(self, name, ok, msg=""):
        if self.cfg("notify_router", True):
            self.notify(f"{'✅' if ok else '🔴'} {name}: {'back online' if ok else 'unreachable'}" + (f"\n{msg}" if msg and not ok else ""))

    def payment_sms(self, cid, amount, month):
        if not self.cfg("sms_on_payment", False) or not self.sms_ready():
            return
        c = self.app.db.client(cid)
        if not c or not c["phone1"]:
            return
        left = sum(d["due"] for d in self.app.db.due_months(cid))
        text = (f"{c['name'] or c['pppoe_id']}, আপনার {money(amount)} টাকা পেমেন্ট ({dbm.month_label(month)}) গ্রহণ করা হয়েছে। "
                f"বকেয়া: {money(left)} টাকা। ধন্যবাদ — {self.cfg('company', BRAND['company'])}")
        threading.Thread(target=self.sms, args=(c["phone1"], text), daemon=True).start()

    # ---- daily jobs (called from the sync loop every cycle; cheap when nothing is due) ------------------------------
    def tick(self):
        app, today = self.app, time.strftime("%Y-%m-%d")
        try:
            if app.settings.get("auto_backup", True) and app.settings.get("last_backup") != today:
                made = app.db.auto_backup(int(app.settings.get("backup_keep", 14) or 14))
                app.settings["last_backup"] = today
                if made:
                    app.db.log("auto-backup", str(made))
                app.post(app.apply_settings)
            if app.settings.get("last_purge") != today:
                app.db.purge_usage()
                app.settings["last_purge"] = today
                app.post(app.apply_settings)
            self.auto_reminders(today)
            hour = int(app.settings.get("daily_hour", 21) or 21)
            if (app.settings.get("notify_daily", False) and self.telegram_ready() and app.settings.get("last_daily") != today
                    and time.localtime().tm_hour >= hour):
                app.settings["last_daily"] = today
                app.post(app.apply_settings)
                self.telegram(self.daily_text())
        except Exception:
            import traceback
            traceback.print_exc()

    def auto_reminders(self, today):
        """Automatic due-reminder SMS on the chosen days of the month (Automation page), once per day, after 10:00."""
        app = self.app
        if not app.settings.get("auto_remind", False) or not self.sms_ready() or app.settings.get("last_remind") == today:
            return
        days = {int(x) for x in str(app.settings.get("remind_days", "")).replace(" ", "").split(",") if x.isdigit()}
        lt = time.localtime()
        if lt.tm_mday not in days or lt.tm_hour < 10:
            return
        app.settings["last_remind"] = today
        app.post(app.apply_settings)
        month = dbm.month_now()
        rows = [c for c in app.db.clients("", "", "", "due", month) if c["total_due"] > 0 and c["status"] != "disabled" and c["phone1"]]

        def work():
            sent = 0
            for c in rows:
                ok, _m = self.sms(c["phone1"], reminder_text(c, c["total_due"], dbm.month_label(month), app.settings))
                sent += 1 if ok else 0
                time.sleep(0.4)
            app.db.log("auto-reminder", f"{sent}/{len(rows)} SMS sent")
            self.notify(f"✉ Auto due reminders: {sent}/{len(rows)} SMS sent")
        threading.Thread(target=work, daemon=True).start()

    def daily_text(self):
        db, m, today = self.app.db, dbm.month_now(), time.strftime("%Y-%m-%d")
        s, pr = db.summary(m), db.profit(m)
        day = db.one("SELECT COALESCE(SUM(amount),0) AS s, COUNT(*) AS n FROM payments WHERE substr(paid_at,1,10)=?", (today,))
        o, p = db.ticket_counts()
        bad = [n for n, st in self.app.sync.status.items() if st.get("state") == "error"]
        return (f"📊 {self.cfg('company', BRAND['company'])} — {today}\n"
                f"আজকের কালেকশন: ৳{money(day['s'])} ({day['n']} payment)\n"
                f"এই মাসে কালেকশন: ৳{money(pr['collected'])}  |  খরচ: ৳{money(pr['expenses'])}  |  নিট: ৳{money(pr['net'])}\n"
                f"মোট বকেয়া: ৳{money(s['total_due'])} ({s['due_clients']} জন)\n"
                f"ক্লায়েন্ট: {s['total']} (অনলাইন {s['online'] or 0}, সাসপেন্ড {s['suspended'] or 0})\n"
                f"খোলা টিকেট: {o + p}" + (f"\n⚠ রাউটার সমস্যা: {', '.join(bad)}" if bad else ""))


# ======================================================================================================
class BulkReminderDialog(tk.Toplevel):
    """Pick the overdue clients → send the reminder by SMS gateway (all at once) or WhatsApp (one click each)."""

    def __init__(self, app, month=None, router=""):
        super().__init__(app)
        self.app, self.month, self.router = app, month or dbm.month_now(), router
        self.title("Bulk due reminder")
        self.configure(bg=BG)
        self.geometry("980x600")
        self.transient(app)
        self.rows, self.wa_queue = [], []
        tk.Label(self, text=f"Due reminder — up to {dbm.month_label(self.month)}", bg=BG, fg=CYAN, font=(FONT, 12, "bold")).pack(
            anchor="w", padx=14, pady=(12, 2))
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", padx=14, pady=4)
        tk.Label(f, text="Minimum due ৳", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.min_due = app.entry(f, 8)
        self.min_due.insert(0, "1")
        self.min_due.pack(side="left", padx=6)
        self.only_phone = tk.BooleanVar(value=True)
        tk.Checkbutton(f, text="only clients with a phone number", variable=self.only_phone, command=self.load, bg=BG, fg=TEXT,
                       selectcolor=PANEL2, activebackground=BG, activeforeground=CYAN).pack(side="left", padx=10)
        app.button(f, "Reload", self.load).pack(side="left")
        self.info = tk.Label(f, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.info.pack(side="right")
        cols = [("c", "PPPOE ID", 120), ("n", "CLIENT", 170), ("p", "PHONE", 110), ("r", "ROUTER", 110), ("m", "DUE MONTHS", 70, "e"),
                ("d", "DUE ৳", 85, "e"), ("s", "RESULT", 220)]
        wrap, self.tree = scrolled_tree(self, cols)
        wrap.pack(fill="both", expand=True, padx=14, pady=6)
        self.tree.configure(selectmode="extended")
        tk.Label(self, text="Message preview (template is edited in ISP Settings & Data)", bg=BG, fg=MUTED, font=(FONT, 9)).pack(
            anchor="w", padx=14)
        self.prev = tk.Label(self, text="", bg=CARD, fg=TEXT, justify="left", anchor="w", wraplength=930, font=(FONT, 9), padx=8, pady=6)
        self.prev.pack(fill="x", padx=14, pady=(2, 6))
        b = tk.Frame(self, bg=BG)
        b.pack(fill="x", padx=14, pady=(0, 12))
        GButton(b, "Select all", lambda: self.tree.selection_set(self.tree.get_children()), "blue", 100, 30, bg=BG).pack(side="left", padx=(0, 6))
        GButton(b, "✉ Send SMS (selected)", self.send_sms, "green", 190, 30, bg=BG).pack(side="left", padx=6)
        GButton(b, "📱 WhatsApp — next client", self.next_wa, "cyan", 200, 30, bg=BG).pack(side="left", padx=6)
        GButton(b, "✈ Telegram me this list", self.to_telegram, "purple", 190, 30, bg=BG).pack(side="left", padx=6)
        self.tree.bind("<<TreeviewSelect>>", lambda _e: self._preview())
        self.load()

    def load(self):
        try:
            lo = float(self.min_due.get() or 0)
        except ValueError:
            lo = 0
        db = self.app.db
        rows = db.clients("", self.router, "", "due", self.month)
        self.rows = [c for c in rows if c["total_due"] >= max(lo, 0.01) and c["status"] != "disabled"
                     and (c["phone1"] or not self.only_phone.get())]
        self.tree.delete(*self.tree.get_children())
        for i, c in enumerate(self.rows):
            self.tree.insert("", "end", iid=str(c["id"]), tags=("odd",) if i % 2 else (), values=(
                c["pppoe_id"], c["name"], c["phone1"], c["router"], len(db.due_months(c["id"], self.month)), money(c["total_due"]), ""))
        self.info.configure(text=f"{len(self.rows)} clients • total ৳{money(sum(c['total_due'] for c in self.rows))}")
        self.tree.selection_set(self.tree.get_children())
        self._preview()

    def _msg(self, c):
        return reminder_text(c, c["total_due"], dbm.month_label(self.month), self.app.settings)

    def _preview(self):
        sel = self.tree.selection()
        c = next((r for r in self.rows if str(r["id"]) == (sel[0] if sel else "")), self.rows[0] if self.rows else None)
        self.prev.configure(text=self._msg(c) if c else "—")

    def _selected(self):
        ids = {int(i) for i in self.tree.selection()}
        return [c for c in self.rows if c["id"] in ids]

    def send_sms(self):
        n = self.app.notifier
        if not n.sms_ready():
            messagebox.showinfo("SMS", "Set the SMS gateway URL first (Automation & Alerts page).", parent=self)
            return
        sel = self._selected()
        if not sel or not messagebox.askyesno("Send SMS", f"Send {len(sel)} SMS now?", parent=self):
            return

        def work():
            for c in sel:
                ok, msg = n.sms(c["phone1"], self._msg(c))
                self.app.post(lambda c=c, ok=ok, msg=msg: self._mark(c["id"], ("✔ sent" if ok else "✖ " + msg)))
                time.sleep(0.4)
            self.app.db.log("bulk-sms", f"{len(sel)} reminders for {self.month}")
        threading.Thread(target=work, daemon=True).start()

    def _mark(self, cid, text):
        if self.winfo_exists() and self.tree.exists(str(cid)):
            v = list(self.tree.item(str(cid), "values"))
            v[-1] = text
            self.tree.item(str(cid), values=v)

    def next_wa(self):
        if not self.wa_queue:
            self.wa_queue = [c for c in self._selected() if c["phone1"]]
        if not self.wa_queue:
            messagebox.showinfo("WhatsApp", "No (more) selected clients with a phone number.", parent=self)
            return
        c = self.wa_queue.pop(0)
        webbrowser.open(wa_link(c["phone1"], self._msg(c)))
        self._mark(c["id"], "WhatsApp opened")
        self.info.configure(text=f"{len(self.wa_queue)} left in WhatsApp queue")

    def to_telegram(self):
        sel = self._selected()
        lines = [f"{c['pppoe_id']} {c['name']} {c['phone1']} — ৳{money(c['total_due'])}" for c in sel[:60]]
        ok, msg = self.app.notifier.telegram(f"📋 বকেয়া তালিকা ({dbm.month_label(self.month)})\n" + "\n".join(lines))
        messagebox.showinfo("Telegram", "Sent." if ok else msg, parent=self)


# ======================================================================================================
class AutomationPage(Page):
    """Telegram / SMS gateway / daily summary / backup settings and a message log."""
    FIELDS = (("tg_token", "Telegram bot token", ""), ("tg_chat", "Telegram chat id", ""),
              ("sms_url", "SMS gateway URL", ""), ("daily_hour", "Daily summary after hour (0-23)", "21"),
              ("backup_keep", "Keep this many daily backups", "14"),
              ("remind_days", "Auto due-reminder SMS on days of month (e.g. 11,20,25)", "11,20"))
    FLAGS = (("notify_router", "Telegram: router DOWN / back-online alerts", True),
             ("notify_daily", "Telegram: daily collection summary", False),
             ("sms_on_payment", "SMS the client when a payment is received", False),
             ("auto_backup", "Automatic daily database backup (backups/ folder)", True),
             ("auto_remind", "Automatically SMS due reminders on the days above (needs SMS gateway)", False),
             ("auto_enable", "Auto re-enable suspended clients on the router once their due is cleared", False),
             ("auto_packages", "Auto-import router PPP profiles as packages & fill missing client bills", True),
             ("notify_outage", "Alert when a zone / router suddenly goes mass-offline (area outage)", True))

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Automation & Alerts", "telegram • sms gateway • daily summary • auto backup")
        self.vars, self.flags = {}, {}
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x")
        p = Panel(top, "Notifications", "✈", CYAN, height=580, width=760)
        p.pack(side="left", fill="y", padx=(0, 10))
        b = p.body
        for r, (k, label, d) in enumerate(self.FIELDS):
            tk.Label(b, text=label, bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 10))
            e = app.entry(b, 58 if k in ("tg_token", "sms_url") else 20)
            e.insert(0, str(app.settings.get(k, d)))
            e.grid(row=r, column=1, sticky="w")
            e.bind("<FocusOut>", lambda _e: self.save())
            self.vars[k] = e
        self.method = tk.StringVar(value=app.settings.get("sms_method", "GET"))
        mrow = len(self.FIELDS)
        tk.Label(b, text="SMS request method", bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=mrow, column=0, sticky="w", pady=4)
        mc = ttk.Combobox(b, values=["GET", "POST"], width=8, state="readonly", textvariable=self.method)
        mc.grid(row=mrow, column=1, sticky="w")
        mc.bind("<<ComboboxSelected>>", lambda _e: self.save())
        for r, (k, t, d) in enumerate(self.FLAGS, mrow + 1):
            v = tk.BooleanVar(value=app.settings.get(k, d))
            self.flags[k] = v
            tk.Checkbutton(b, text=t, variable=v, command=self.save, bg=CARD, fg=TEXT, selectcolor=CARD2, activebackground=CARD,
                           activeforeground=CYAN).grid(row=r, column=0, columnspan=2, sticky="w", pady=1)
        tk.Label(b, text="SMS URL placeholders:  {phone} (8801…)  {phone_local} (01…)  {text}\n"
                         "e.g.  https://your-gateway/api?api_key=KEY&senderid=ID&number={phone}&message={text}",
                 bg=CARD, fg=DIM, font=(FONT, 8), justify="left").grid(row=mrow + len(self.FLAGS) + 1, column=0, columnspan=2, sticky="w", pady=(8, 0))
        bar = tk.Frame(b, bg=CARD)
        bar.grid(row=mrow + len(self.FLAGS) + 2, column=0, columnspan=2, sticky="w", pady=(10, 0))
        for text, fn, col, w in (("✈ Test Telegram", self.test_tg, "cyan", 150), ("✉ Test SMS", self.test_sms, "green", 130),
                                 ("📊 Send summary now", self.send_summary, "purple", 170), ("💾 Backup now", self.backup_now, "blue", 140)):
            GButton(bar, text, fn, col, w, 30, bg=CARD).pack(side="left", padx=(0, 6))
        side = Panel(top, "Bulk reminders", "✉", ORANGE, height=580)
        side.pack(side="left", fill="both", expand=True)
        tk.Label(side.body, text="Send the due reminder to every client who owes money — by SMS gateway,\n"
                                 "by WhatsApp (one click per client) or as a Telegram list for yourself.",
                 bg=CARD, fg=MUTED, font=(FONT, 9), justify="left").pack(anchor="w", pady=(0, 8))
        GButton(side.body, "✉ Open bulk reminder", lambda: BulkReminderDialog(app), "orange", 200, 32, bg=CARD).pack(anchor="w")
        tk.Label(self, text="Message log (latest 300)", bg=BG, fg=CYAN, font=(FONT, 10, "bold")).pack(anchor="w", pady=(10, 2))
        w, self.tree = scrolled_tree(self, [("t", "TIME", 140), ("p", "PHONE", 120), ("c", "CHANNEL", 70), ("r", "RESULT", 220),
                                           ("x", "MESSAGE", 600)])
        w.pack(fill="both", expand=True)

    def on_show(self):
        self.tree.delete(*self.tree.get_children())
        for r in self.app.db.msg_log():
            self.tree.insert("", "end", tags=("ok",) if r["result"] == "ok" else ("bad",),
                             values=(r["ts"], r["phone"], r["channel"], r["result"], r["text"]))

    def save(self):
        s = self.app.settings
        for k, e in self.vars.items():
            v = e.get().strip()
            s[k] = int(v) if k in ("daily_hour", "backup_keep") and v.isdigit() else v
        for k, v in self.flags.items():
            s[k] = bool(v.get())
        s["sms_method"] = self.method.get()
        self.app.apply_settings()

    def _bg(self, fn, title):
        self.save()
        self.app.run_async(fn, lambda res: messagebox.showinfo(title, "OK ✔" if res[0] else f"Failed: {res[1]}", parent=self.app),
                           lambda e: messagebox.showerror(title, str(e), parent=self.app))

    def test_tg(self):
        self._bg(lambda: self.app.notifier.telegram("✅ MikroTik Desktop Manager — test message"), "Telegram")

    def test_sms(self):
        from tkinter import simpledialog
        ph = simpledialog.askstring("Test SMS", "Phone number (01XXXXXXXXX):", parent=self.app)
        if ph:
            self._bg(lambda: self.app.notifier.sms(ph, "Test SMS from MikroTik Desktop Manager"), "SMS")

    def send_summary(self):
        self._bg(lambda: self.app.notifier.telegram(self.app.notifier.daily_text()), "Telegram")

    def backup_now(self):
        made = self.app.db.auto_backup(int(self.app.settings.get("backup_keep", 14) or 14))
        messagebox.showinfo("Backup", f"Saved: {made}" if made else "Today's backup already exists in the backups/ folder.", parent=self.app)


PAGE_KINDS.update({"automation": AutomationPage})
