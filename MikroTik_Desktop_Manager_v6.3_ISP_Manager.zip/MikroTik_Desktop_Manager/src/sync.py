"""Multi-router sync engine: every device (API / API-SSL / SSH / Telnet / SNMP) is polled in the background, its
PPP secrets / active sessions are merged into the client database, health numbers are kept for the Router Sync page,
and (optionally) overdue clients are suspended on the router."""
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import secret
from db import month_now
from transport import open_link, snmp_extras, NotSupported
import snmp as snmplib


class SyncManager:
    def __init__(self, app):
        self.app = app
        self.status = {}                       # profile name -> dict
        self.busy = set()
        self.pool = ThreadPoolExecutor(max_workers=6)
        self.stop_evt = threading.Event()
        self.last_round = 0
        self.live = {}                         # router -> dict(ts, rates={pppoe: (up_bps, down_bps)})  (average since last sync)
        self.outages = {}                      # (router, zone) -> online count before the drop
        self._prev = {}                        # router -> (timestamp, {pppoe: (rx, tx)})

    # -- scheduling ---------------------------------------------------------------------------------------
    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        time.sleep(4)
        while not self.stop_evt.is_set():
            mins = max(float(self.app.settings.get("sync_minutes", 5)), 0.5)
            if self.app.settings.get("auto_sync", True) and self.app.auto:
                self.sync_all(auto=True)
                self._monthly_bills()
            self.app.notifier.tick()
            self.stop_evt.wait(mins * 60)

    def _monthly_bills(self):
        if self.app.settings.get("auto_bills", True):
            try:
                if self.app.db.generate_bills(month_now()):
                    self.app.post(self.app.on_sync)
            except Exception:
                pass

    def stop(self):
        self.stop_evt.set()

    def sync_all(self, auto=False):
        n = 0
        for p in list(self.app.profiles):
            if auto and not p.get("auto_sync", True):
                continue
            if self.sync(p, auto=auto):
                n += 1
        return n

    def sync(self, p, password=None, import_new=True, auto=False):
        """Queue a sync. `password` overrides the saved one. Returns False if skipped."""
        name = p["name"]
        if name in self.busy:
            return False
        pw = password
        if pw is None and p.get("proto") != "snmp":
            if p.get("save_pw") or p.get("pw") is not None:
                pw = secret.unprotect(p.get("pw", ""))
            else:
                self.status[name] = dict(state="no-password", ts=time.time(), msg="No saved password — edit the device and tick “Save password”.", proto=p.get("proto", "api"))
                self.app.post(self.app.on_sync)
                return False
        self.busy.add(name)
        self.status.setdefault(name, {})["state"] = "syncing"
        self.app.post(self.app.on_sync)
        self.pool.submit(self._run, dict(p), pw, import_new, auto)
        return True

    # -- worker ---------------------------------------------------------------------------------------------
    def _run(self, p, pw, import_new, auto):
        name, app, db = p["name"], self.app, self.app.db
        prev = self.status.get(name, {}).get("state")
        link = None
        try:
            link = open_link(p, pw or "", verify_tls=bool(app.settings.get("verify_tls", False)))
            snap = link.snapshot()
            try:
                secrets = link.secrets()
            except NotSupported:
                secrets = None
            extras = {}
            try:
                extras = snmp_extras(p)
            except Exception as e:
                extras = dict(snmp_ok=False, snmp_err=str(e))
            active = {a["name"]: a for a in snap.get("ppp_active", []) if a.get("name")}
            zones_before = db.online_by_zone(name)
            stat = db.apply_router_state(name, secrets, active, import_new=import_new and secrets is not None)
            try:
                self._smart(p, link, snap, secrets, active, stat, zones_before)
            except Exception:
                pass                                      # smart extras must never break a sync
            try:
                self._usage(name, link, snap, extras)
            except Exception:
                pass                                      # usage tracking must never break a sync
            suspended = self._enforce(link, p, secrets) if secrets is not None and app.settings.get("auto_suspend") else 0
            reenabled = self._reenable(link, p) if secrets is not None and app.settings.get("auto_enable") else 0
            snap.update(extras)
            snap.update(state="ok", ts=time.time(), proto=p.get("proto", "api"), stat=stat, msg=self._msg(stat, suspended, secrets, reenabled),
                        auto_suspended=suspended, ppp_active_n=len(active))
            snap.pop("ifaces_raw", None)
            self.status[name] = snap
            if prev == "error":
                app.post(lambda: app.alerts.add("info", f"sync-ok:{name}", f"{name}: back online", 60))
                app.notifier.router_event(name, True)
            db.log("sync", f"{name} [{p.get('proto', 'api')}] new={stat['new']} online={stat['online']}")
        except Exception as e:
            self.status[name] = dict(state="error", ts=time.time(), msg=str(e) or e.__class__.__name__, proto=p.get("proto", "api"))
            if prev != "error":
                app.post(lambda e=e: app.alerts.add("critical", f"sync-err:{name}", f"{name}: sync failed — {e}", 600))
                app.notifier.router_event(name, False, str(e))
        finally:
            if link:
                try:
                    link.close()
                except Exception:
                    pass
            self.busy.discard(name)
            app.post(app.on_sync)

    @staticmethod
    def _msg(stat, suspended, secrets, reenabled=0):
        if secrets is None:
            return f"online users {stat['online']} (SNMP: health & traffic only)"
        s = f"new {stat['new']} • changed {stat['updated']} • missing {stat['missing']} • online {stat['online']}"
        s += f" • auto-suspended {suspended}" if suspended else ""
        return s + (f" • auto-enabled {reenabled}" if reenabled else "")

    # -- smart auto-sync extras (v6.1) ----------------------------------------------------------------------------
    def _smart(self, p, link, snap, secrets, active, stat, zones_before):
        app, db, name = self.app, self.app.db, p["name"]
        if secrets is not None and app.settings.get("auto_packages", True):
            try:
                db.sync_profiles(link.profiles())
            except Exception:
                pass                                      # NotSupported / old firmware: keep going with the other smart steps
            db.fill_missing_bills()
            if stat.get("new") and app.settings.get("auto_bills", True):
                db.generate_bills(month_now())            # newly imported clients are billed straight away
        disabled = sum(1 for s in (secrets or []) if s.get("disabled") == "true")
        db.add_router_stat(name, snap.get("ppp_total", len(secrets or [])), len(active), disabled, snap.get("cpu", 0), snap.get("mem_pct", 0))
        if app.settings.get("notify_outage", True):
            after = db.online_by_zone(name)
            for zone, (n, before) in zones_before.items():
                now_o = after.get(zone, (0, 0))[1]
                key = (name, zone)
                if n >= 5 and before >= 5 and now_o <= before * 0.4 and key not in self.outages:
                    self.outages[key] = before
                    msg = f"Possible outage — {name} / {zone}: online {before} → {now_o} within one sync (fibre cut / power / OLT?)"
                    db.log("outage", msg)
                    app.post(lambda m=msg, k=key: app.alerts.add("critical", f"outage:{k}", m, 900))
                    app.notifier.notify("⚠ " + msg)
                elif key in self.outages and now_o >= self.outages[key] * 0.8:
                    msg = f"Restored — {name} / {zone}: {now_o} online again"
                    del self.outages[key]
                    db.log("outage-restored", msg)
                    app.notifier.notify("✅ " + msg)

    # -- per-client bandwidth usage (v6) -------------------------------------------------------------------------
    def _usage(self, router, link, snap, extras):
        """Turn the PPPoE interface byte counters into per-day totals and a live average rate per user."""
        try:
            counters = link.ppp_counters()
        except NotSupported:
            src = snap.get("ppp_active") if link.kind == "snmp" else extras.get("snmp_pppoe")
            counters = {a["name"]: (int(a.get("rxb") or 0), int(a.get("txb") or 0)) for a in (src or []) if a.get("name")}
        self.record_counters(router, counters)

    def record_counters(self, router, counters):
        ts = time.time()
        prev = self._prev.get(router)
        self._prev[router] = (ts, counters)
        if not prev:
            return                                        # first sample after start: nothing to subtract from
        pts, pc = prev
        dt = max(ts - pts, 1.0)
        ids = {r["pppoe_id"]: r["id"] for r in self.app.db.q("SELECT id, pppoe_id FROM clients WHERE router=?", (router,))}
        day, rows, rates = time.strftime("%Y-%m-%d"), [], {}
        for user, (rx, tx) in counters.items():
            cid = ids.get(user)
            if cid is None:
                continue
            if user in pc:
                prx, ptx = pc[user]
                drx, dtx = (rx - prx if rx >= prx else rx), (tx - ptx if tx >= ptx else tx)   # counter reset = new session
            else:
                drx, dtx = rx, tx                         # session started since the last poll: counters began at zero
            if drx or dtx:
                rows.append((cid, day, drx, dtx))
            rates[user] = (drx * 8 / dt, dtx * 8 / dt)
        self.app.db.add_usage_many(rows)
        self.live[router] = dict(ts=ts, rates=rates)

    def live_sample(self, p, password, seconds=8):
        """Blocking (call from a worker thread): read the counters twice `seconds` apart → instantaneous {user: (up_bps, down_bps)}."""
        link = open_link(p, password, verify_tls=bool(self.app.settings.get("verify_tls", False)))
        try:
            a = link.ppp_counters(fresh=True)
            time.sleep(max(float(seconds), 2.0))
            b = link.ppp_counters(fresh=True)
        finally:
            link.close()
        t = max(float(seconds), 2.0)
        return {u: (max(rx - a.get(u, (rx, tx))[0], 0) * 8 / t, max(tx - a.get(u, (rx, tx))[1], 0) * 8 / t) for u, (rx, tx) in b.items()}

    # -- auto re-enable paid clients (v6) -----------------------------------------------------------------------------
    def _reenable(self, link, p):
        rows = self.app.db.q(
            "SELECT c.id, c.pppoe_id FROM clients c WHERE c.router=? AND c.status='suspended' AND c.on_router=1 AND NOT EXISTS("
            "SELECT 1 FROM bills b WHERE b.client_id=c.id AND b.amount-b.discount-b.paid>0 AND b.month<=?)", (p["name"], month_now()))
        n = 0
        for c in rows:
            try:
                link.secret_enable(c["pppoe_id"], True)
                self.app.db.set_status(c["id"], "active")
                self.app.db.log("auto-enable", f"{c['pppoe_id']} on {p['name']}")
                n += 1
            except Exception:
                continue
        return n

    # -- auto suspend overdue ---------------------------------------------------------------------------------
    def overdue_ids(self, router):
        due_day, today = int(self.app.settings.get("due_day", 10)), time.localtime()
        cur = month_now()
        rows = self.app.db.q(
            "SELECT c.id, c.pppoe_id FROM clients c LEFT JOIN client_meta m ON m.client_id=c.id "
            "WHERE c.router=? AND c.status='active' AND c.on_router=1 AND COALESCE(m.exempt,0)=0 AND EXISTS("
            "SELECT 1 FROM bills b WHERE b.client_id=c.id AND b.amount-b.discount-b.paid>0 AND (b.month<? OR (b.month=? AND ?>"
            "(CASE WHEN COALESCE(m.due_day,0)>0 THEN m.due_day ELSE ? END)+COALESCE(m.grace_days,0))))",
            (router, cur, cur, today.tm_mday, due_day))
        return rows

    def _enforce(self, link, p, secrets):
        n = 0
        for c in self.overdue_ids(p["name"]):
            try:
                link.secret_enable(c["pppoe_id"], False)
                link.kick(c["pppoe_id"])
                self.app.db.set_status(c["id"], "suspended")
                self.app.db.log("auto-suspend", f"{c['pppoe_id']} on {p['name']}")
                n += 1
            except Exception:
                continue
        return n

    # -- one-off router operations (used by the Clients page) -----------------------------------------------------
    def with_link(self, p, password, fn):
        pw = password if password is not None else secret.unprotect(p.get("pw", ""))
        link = open_link(p, pw, verify_tls=bool(self.app.settings.get("verify_tls", False)))
        try:
            return fn(link)
        finally:
            link.close()
