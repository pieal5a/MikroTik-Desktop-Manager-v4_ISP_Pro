"""App PIN lock (v6): PIN at start-up, manual lock (Ctrl+L) and idle auto-lock.  The PIN is stored as a salted PBKDF2 hash
in settings.json — it protects the screen, it does not encrypt the database."""
import hashlib
import hmac
import os
import time
import tkinter as tk
from tkinter import messagebox

from core import *
from core import PAGE_KINDS
from ui_kit import GButton, Panel


def _hash(pin, salt):
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt), 120_000).hex()


def has_pin(app):
    return bool(app.settings.get("pin_hash"))


def set_pin(app, pin):
    if not pin:
        app.settings.pop("pin_hash", None)
        app.settings.pop("pin_salt", None)
    else:
        salt = os.urandom(16).hex()
        app.settings["pin_salt"], app.settings["pin_hash"] = salt, _hash(pin, salt)
    app.apply_settings()


def check_pin(app, pin):
    return hmac.compare_digest(_hash(pin, app.settings.get("pin_salt", "00")), app.settings.get("pin_hash", ""))


def lock(app):
    """Hide the app and ask for the PIN. Closing the prompt quits the program."""
    if not has_pin(app) or getattr(app, "_locked", False):
        return
    app._locked = True
    app.withdraw()
    win = tk.Toplevel()
    win.title("Locked")
    win.configure(bg=BG)
    win.resizable(False, False)
    tk.Label(win, text="🔒  MikroTik Desktop Manager", bg=BG, fg=TEXT, font=(FONT, 14, "bold")).pack(padx=40, pady=(26, 4))
    tk.Label(win, text="Enter PIN to continue", bg=BG, fg=MUTED, font=(FONT, 10)).pack()
    e = tk.Entry(win, show="•", width=14, justify="center", font=(FONT, 16), bg=PANEL2, fg=TEXT, insertbackground=CYAN, relief="flat")
    e.pack(pady=14, ipady=4)
    msg = tk.Label(win, text="", bg=BG, fg=RED, font=(FONT, 9))
    msg.pack()
    tries = {"n": 0}

    def go(_e=None):
        if check_pin(app, e.get()):
            app._locked = False
            win.destroy()
            app.deiconify()
            touch(app)
            return
        tries["n"] += 1
        e.delete(0, "end")
        msg.configure(text=f"Wrong PIN ({tries['n']})")
        if tries["n"] >= 5:                      # slow down guessing
            e.configure(state="disabled")
            win.after(15000, lambda: (e.configure(state="normal"), e.focus_set()) if win.winfo_exists() else None)
            msg.configure(text="Too many attempts — wait 15 s")
            tries["n"] = 0

    def quit_app():
        win.destroy()
        app.on_close()
    e.bind("<Return>", go)
    tk.Button(win, text="Unlock", command=go, bg=BLUE, fg="white", relief="flat", padx=16, pady=5, cursor="hand2").pack(pady=(4, 24))
    win.protocol("WM_DELETE_WINDOW", quit_app)
    win.update_idletasks()
    win.geometry(f"+{win.winfo_screenwidth() // 2 - 160}+{win.winfo_screenheight() // 2 - 150}")
    win.lift()
    win.attributes("-topmost", True)
    e.focus_force()


def touch(app, _e=None):
    app._last_active = time.time()


def install(app):
    app._locked, app._last_active = False, time.time()
    app.bind_all("<Any-KeyPress>", lambda e: touch(app), add="+")
    app.bind_all("<Any-Button>", lambda e: touch(app), add="+")
    app.bind_all("<Motion>", lambda e: touch(app), add="+")
    app.bind("<Control-l>", lambda _e: lock(app))

    def idle():
        try:
            mins = float(app.settings.get("lock_minutes", 0) or 0)
            if mins > 0 and has_pin(app) and not app._locked and time.time() - app._last_active > mins * 60:
                lock(app)
        finally:
            app.after(15000, idle)
    app.after(15000, idle)
    if has_pin(app):
        app.after(50, lambda: lock(app))


class SecurityPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Security & PIN", "screen lock • idle auto-lock")
        p = Panel(self, "App lock", "🔒", CYAN, height=330, width=640)
        p.pack(anchor="w")
        b = p.body
        self.status = tk.Label(b, text="", bg=CARD, fg=GREEN, font=(FONT, 10, "bold"))
        self.status.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 8))
        self.e = {}
        for r, (lab, key) in enumerate((("Current PIN (if set)", "old"), ("New PIN (4+ digits; empty = remove)", "new"), ("Repeat new PIN", "rep")), 1):
            tk.Label(b, text=lab, bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 10))
            en = app.entry(b, 18, show="•")
            en.grid(row=r, column=1, sticky="w")
            self.e[key] = en
        tk.Label(b, text="Auto-lock after minutes idle (0 = off)", bg=CARD, fg=MUTED, font=(FONT, 9)).grid(row=4, column=0, sticky="w", pady=4)
        self.idle = app.entry(b, 8)
        self.idle.insert(0, str(app.settings.get("lock_minutes", 0)))
        self.idle.grid(row=4, column=1, sticky="w")
        bar = tk.Frame(b, bg=CARD)
        bar.grid(row=5, column=0, columnspan=2, sticky="w", pady=(12, 0))
        GButton(bar, "💾 Save", self.save, "purple", 100, 30, bg=CARD).pack(side="left", padx=(0, 6))
        GButton(bar, "🔒 Lock now (Ctrl+L)", lambda: lock(app), "orange", 170, 30, bg=CARD).pack(side="left")
        tk.Label(b, text="The PIN hides the program; router passwords and the database are not encrypted.\nKeep the PC and backups physically safe.",
                 bg=CARD, fg=DIM, font=(FONT, 8), justify="left").grid(row=6, column=0, columnspan=2, sticky="w", pady=(10, 0))

    def on_show(self):
        self.status.configure(text="PIN lock is ON" if has_pin(self.app) else "PIN lock is OFF", fg=GREEN if has_pin(self.app) else ORANGE)

    def save(self):
        app = self.app
        g = lambda k: self.e[k].get()
        if has_pin(app) and not check_pin(app, g("old")):
            messagebox.showerror("PIN", "Current PIN is wrong.", parent=app)
            return
        if g("new") != g("rep"):
            messagebox.showerror("PIN", "The new PIN and its repeat differ.", parent=app)
            return
        if g("new") and len(g("new")) < 4:
            messagebox.showerror("PIN", "Use at least 4 characters.", parent=app)
            return
        try:
            app.settings["lock_minutes"] = max(float(self.idle.get() or 0), 0)
        except ValueError:
            messagebox.showerror("Auto-lock", "Minutes must be a number.", parent=app)
            return
        if g("new") or has_pin(app):
            set_pin(app, g("new"))
        app.apply_settings()
        for e in self.e.values():
            e.delete(0, "end")
        self.on_show()
        messagebox.showinfo("Security", "Saved.", parent=app)


PAGE_KINDS.update({"security": SecurityPage})
