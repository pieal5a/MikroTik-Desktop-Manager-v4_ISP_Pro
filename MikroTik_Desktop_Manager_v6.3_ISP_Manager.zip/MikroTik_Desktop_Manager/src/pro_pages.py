"""RouterPilot-style pages: Dashboard, Devices, Quick Connect, Graphical Monitor, Topology, Alerts, Reports,
Settings, DNS Lookup."""
import html
import random
import socket
import threading
import time
import tkinter as tk
import webbrowser
from tkinter import ttk, messagebox, simpledialog, filedialog

import mndp
from core import *
from core import PAGE_KINDS
from services import Fleet, short_uptime, parse_uptime, PHYSICAL
from ui_kit import (Panel, StatCard, Gauge, Donut, LineChart, BarList, Topology, GButton, ToolTile, rrect, gradient,
                    lerp, fmt_rate as rate)

STATUS_COL = {"online": GREEN, "warning": ORANGE, "offline": RED}
TYPE_GLYPH = {"Router": ("⇆", BLUE), "Switch": ("⊞", GREEN), "Firewall": ("▩", ORANGE), "Access Point": ("◉", RED),
              "Server": ("▤", GREEN), "OLT": ("⌬", PURPLE)}


def entry(parent, width=20, textvariable=None, show=None):
    e = tk.Entry(parent, width=width, bg=CARD2, fg=TEXT, insertbackground=CYAN, relief="flat", highlightthickness=1,
                 highlightbackground=BORDER, highlightcolor=CYAN, font=(FONT, 10), textvariable=textvariable, show=show)
    return e


def label(parent, text, fg=MUTED, size=9, bold=False, bg=CARD, **kw):
    return tk.Label(parent, text=text, bg=bg, fg=fg, font=(FONT, size, "bold" if bold else "normal"), **kw)


def combo(parent, values, width=16, value=None):
    c = ttk.Combobox(parent, values=values, state="readonly", width=width)
    if value is not None:
        c.set(value)
    elif values:
        c.current(0)
    return c


# ---------------------------------------------------------------------------------------
class DeviceTable(tk.Canvas):
    """Canvas table with status pills, usage bars and row actions (connect / edit / delete)."""
    COLS = (("Device", .17), ("Type", .11), ("IP Address", .11), ("Status", .09), ("Uptime", .08), ("CPU", .10),
            ("Memory", .10), ("TX / RX", .11), ("Location", .13))
    ROW, HEAD, ACT = 32, 30, 92

    def __init__(self, parent, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, **kw)
        self.rows, self.sel, self.off = [], None, 0
        self.on_open = self.on_edit = self.on_delete = self.on_select = None
        self.bind("<Configure>", lambda _e: self.draw())
        self.bind("<Button-1>", self._click)
        self.bind("<Double-1>", self._dbl)
        self.bind("<Enter>", lambda _e: self.bind_all("<MouseWheel>", self._wheel))
        self.bind("<Leave>", lambda _e: self.unbind_all("<MouseWheel>"))
        self.bind("<Button-4>", lambda _e: self._scroll(-1))
        self.bind("<Button-5>", lambda _e: self._scroll(1))

    def set_rows(self, rows):
        self.rows = rows
        self.draw()

    def _wheel(self, e):
        self._scroll(-1 if e.delta > 0 else 1)

    def _scroll(self, d):
        vis = max((self.winfo_height() - self.HEAD) // self.ROW, 1)
        self.off = max(0, min(self.off + d, max(len(self.rows) - vis, 0)))
        self.draw()

    def _row_at(self, y):
        i = (y - self.HEAD) // self.ROW + self.off
        return i if 0 <= i < len(self.rows) and y >= self.HEAD else None

    def _click(self, e):
        i = self._row_at(e.y)
        if i is None:
            return
        self.sel = i
        w = self.winfo_width()
        if e.x > w - self.ACT:
            part = (e.x - (w - self.ACT)) // (self.ACT // 3)
            fn = (self.on_open, self.on_edit, self.on_delete)[min(int(part), 2)]
            if fn:
                fn(self.rows[i])
        if self.on_select:
            self.on_select(self.rows[i])
        self.draw()

    def _dbl(self, e):
        i = self._row_at(e.y)
        if i is not None and e.x <= self.winfo_width() - self.ACT and self.on_open:
            self.on_open(self.rows[i])

    def draw(self):
        c, w, h = self, self.winfo_width(), self.winfo_height()
        if w < 300:
            return
        c.delete("all")
        tw = w - self.ACT - 10
        xs, x = [], 10
        for name, frac in self.COLS:
            xs.append(x)
            c.create_text(x + 4, self.HEAD / 2, text=name, anchor="w", fill=MUTED, font=(FONT, 9, "bold"))
            x += tw * frac
        c.create_text(w - 8, self.HEAD / 2, text="Actions", anchor="e", fill=MUTED, font=(FONT, 9, "bold"))
        c.create_line(0, self.HEAD - 1, w, self.HEAD - 1, fill=BORDER)
        vis = (h - self.HEAD) // self.ROW + 1
        for k, r in enumerate(self.rows[self.off:self.off + vis]):
            i = k + self.off
            y = self.HEAD + k * self.ROW
            mid = y + self.ROW / 2
            if i == self.sel:
                c.create_rectangle(0, y, w, y + self.ROW, fill="#12305c", outline="")
            elif k % 2:
                c.create_rectangle(0, y, w, y + self.ROW, fill="#0a1830", outline="")
            g, gc = TYPE_GLYPH.get(r["type"], ("▣", BLUE))
            rrect(c, xs[0] + 2, mid - 11, xs[0] + 24, mid + 11, 6, fill=gc, outline="")
            c.create_text(xs[0] + 13, mid, text=g, fill="white", font=(FONT, 10, "bold"))
            c.create_text(xs[0] + 32, mid, text=r["name"][:20], anchor="w", fill=TEXT, font=(FONT, 9))
            c.create_text(xs[1] + 4, mid, text=r["type"], anchor="w", fill=MUTED, font=(FONT, 9))
            c.create_text(xs[2] + 4, mid, text=r["ip"], anchor="w", fill=CYAN, font=(FONT, 9))
            sc = STATUS_COL.get(r["status"], MUTED)
            rrect(c, xs[3] + 2, mid - 9, xs[3] + 62, mid + 9, 8, fill=lerp(sc, CARD, .75), outline=sc)
            c.create_text(xs[3] + 32, mid, text=r["status"], fill=sc, font=(FONT, 8, "bold"))
            c.create_text(xs[4] + 4, mid, text=r["uptime"], anchor="w", fill=MUTED, font=(FONT, 9))
            for idx, key in ((5, "cpu"), (6, "mem")):
                v = r.get(key)
                if v is None:
                    c.create_text(xs[idx] + 4, mid, text="—", anchor="w", fill=DIM, font=(FONT, 9))
                    continue
                col = GREEN if v < 60 else ORANGE if v < 80 else RED
                bw = tw * self.COLS[idx][1] - 52
                c.create_rectangle(xs[idx] + 4, mid - 3, xs[idx] + 4 + bw, mid + 3, fill="#14284a", outline="")
                c.create_rectangle(xs[idx] + 4, mid - 3, xs[idx] + 4 + max(bw * v / 100, 1), mid + 3, fill=col, outline="")
                c.create_text(xs[idx] + 10 + bw, mid, text=f"{v}%", anchor="w", fill=MUTED, font=(FONT, 8))
            c.create_text(xs[7] + 4, mid, text=r["txrx"], anchor="w", fill=MUTED, font=(FONT, 9))
            c.create_text(xs[8] + 4, mid, text=r["loc"], anchor="w", fill=MUTED, font=(FONT, 9))
            ax = w - self.ACT
            for j, (gl, col) in enumerate((("⏵", GREEN), ("✎", BLUE), ("✕", RED))):
                c.create_text(ax + j * (self.ACT // 3) + self.ACT // 6, mid, text=gl, fill=col, font=(FONT, 11, "bold"))
        if not self.rows:
            c.create_text(w / 2, h / 2, text="No devices yet — press  + Add Device  or  Scan Network",
                          fill=DIM, font=(FONT, 10))


# ---------------------------------------------------------------------------------------
class LogList(tk.Canvas):
    def __init__(self, parent, **kw):
        super().__init__(parent, bg=CARD, highlightthickness=0, **kw)
        self.rows = []
        self.bind("<Configure>", lambda _e: self.draw())

    def set(self, rows):
        self.rows = rows
        self.draw()

    def draw(self):
        c, w = self, self.winfo_width()
        c.delete("all")
        for i, (t, topics, msg) in enumerate(self.rows[:6]):
            y = 12 + i * 22
            col = RED if ("critical" in topics or "error" in topics) else ORANGE if "warning" in topics else GREEN
            c.create_text(2, y, text=t[-8:], anchor="w", fill=DIM, font=(FONT, 8))
            c.create_oval(56, y - 4, 64, y + 4, fill=col, outline="")
            c.create_text(72, y, text=msg[:max((w - 80) // 6, 8)], anchor="w", fill=MUTED, font=(FONT, 8))
        if not self.rows:
            c.create_text(w / 2, 40, text="No log entries", fill=DIM, font=(FONT, 9))


def topo_from(d, wide=False):
    nodes, links = {}, []
    demo = d.get("demo")
    nb = d.get("neighbors", [])[:10]
    per_row = (5 if wide else 4) if len(nb) > 4 else max(len(nb), 1)
    rows = max((len(nb) + per_row - 1) // per_row, 1)
    levels = (1 if demo else 0) + 1 + (rows if nb else 0)
    ys = [.14 + k * (.72 / max(levels - 1, 1)) for k in range(levels)] if levels > 1 else [.45]
    k0 = 0
    if demo:
        nodes["net"] = ("Internet", .5, ys[0], BLUE, "◍")
        links.append(("net", "me", BLUE))
        k0 = 1
    nodes["me"] = ((d.get("identity") or "Router")[:14], .5, ys[k0], "#ef4444", "⇆")
    for i, n in enumerate(nb):
        r, k = divmod(i, per_row)
        cnt = min(per_row, len(nb) - r * per_row)
        plat = (n.get("platform") or "").lower()
        col = "#ef4444" if "ccr" in (n.get("identity") or "").lower() else GREEN if "mikrotik" in plat else CYAN
        nodes[f"n{i}"] = ((n.get("identity") or n.get("address") or "?")[:10], (k + 1) / (cnt + 1), ys[k0 + 1 + r], col, "▤")
        links.append(("me", f"n{i}", GREEN if i % 2 == 0 else BLUE))
    return nodes, links


# ---------------------------------------------------------------------------------------
class DashboardPro(Page):
    RANGES = {"5 Minutes": 150, "15 Minutes": 450, "1 Hour": 1800}

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)
        self.visible, self.last = False, None
        # ---- KPI cards -------------------------------------------------------------
        row = tk.Frame(self, bg=BG)
        row.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        self.cards = {}
        for i, (k, lab, col, gl) in enumerate((("total", "Total Devices", "blue", "▤"), ("online", "Online", "green", "◉"),
                                                ("warn", "Warning", "orange", "⚠"), ("off", "Offline", "red", "⛓"),
                                                ("ppp", "Total Clients (PPPoE)", "purple", "☻"),
                                                ("traffic", "Total Traffic", "cyan", "⇅"))):
            row.columnconfigure(i, weight=1, uniform="k")
            cd = StatCard(row, lab, col, gl)
            cd.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 5, 0 if i == 5 else 5))
            self.cards[k] = cd
        # ---- main grid -------------------------------------------------------------
        main = tk.Frame(self, bg=BG)
        main.grid(row=1, column=0, sticky="nsew")
        main.columnconfigure(0, weight=7)
        main.columnconfigure(1, weight=3, minsize=330)
        main.rowconfigure(0, weight=1)
        left, right = tk.Frame(main, bg=BG), tk.Frame(main, bg=BG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 10))
        right.grid(row=0, column=1, sticky="nsew")
        left.columnconfigure(0, weight=1)
        left.rowconfigure(1, weight=1)
        right.columnconfigure(0, weight=1)
        right.rowconfigure(2, weight=1)
        self._traffic(left)
        self._devices(left)
        self._bottom(left)
        self._resources(right)
        self._tools(right)
        self._topology(right)

    # ---- sections --------------------------------------------------------------------
    def _traffic(self, parent):
        p = Panel(parent, "Network Traffic (Live)", "▥", BLUE, height=262)
        p.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        b = p.body
        b.columnconfigure(0, weight=1)
        ctl = tk.Frame(b, bg=CARD)
        ctl.grid(row=0, column=0, columnspan=2, sticky="e")
        self.if_combo = combo(ctl, ["All Interfaces"], 18)
        self.if_combo.pack(side="left", padx=4)
        self.range_combo = combo(ctl, list(self.RANGES), 11, "1 Hour")
        self.range_combo.pack(side="left", padx=4)
        for cb in (self.if_combo, self.range_combo):
            cb.bind("<<ComboboxSelected>>", lambda _e: self._chart())
        leg = tk.Frame(b, bg=CARD)
        leg.grid(row=0, column=0, sticky="w")
        for txt, col in (("● Download", BLUE), ("● Upload", GREEN)):
            label(leg, txt, col, 9).pack(side="left", padx=(0, 12))
        self.chart = LineChart(b, height=170)
        self.chart.grid(row=1, column=0, sticky="nsew")
        b.rowconfigure(1, weight=1)
        side = tk.Frame(b, bg=CARD)
        side.grid(row=1, column=1, sticky="ns", padx=(10, 0))
        label(side, "Current Speed", TEXT, 9, True).grid(row=0, column=0, columnspan=2, sticky="w")
        self.dl = label(side, "▼ —", BLUE, 15, True)
        self.dl.grid(row=1, column=0, columnspan=2, sticky="w")
        self.ul = label(side, "▲ —", GREEN, 15, True)
        self.ul.grid(row=2, column=0, columnspan=2, sticky="w")
        self.donut = Donut(side, 96, 13)
        self.donut.grid(row=3, column=0, pady=(4, 0))
        self.dlg = label(side, "", MUTED, 8, justify="left")
        self.dlg.grid(row=3, column=1, padx=6)

    def _devices(self, parent):
        p = Panel(parent, "", height=250)
        p.grid(row=1, column=0, sticky="nsew", pady=(0, 10))
        b = p.body
        b.columnconfigure(0, weight=1)
        b.rowconfigure(1, weight=1)
        top = tk.Frame(b, bg=CARD)
        top.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        label(top, "▤", BLUE, 13, True).pack(side="left", padx=(0, 6))
        label(top, "Device List", TEXT, 12, True).pack(side="left")
        label(top, "Overview of all registered network devices", MUTED, 9).pack(side="left", padx=10)
        GButton(top, "＋ Add Device", self.app.add_device, "purple", 112).pack(side="right")
        GButton(top, "◎ Scan Network", self.app.scan_network_dialog, "blue", 118).pack(side="right", padx=8)
        self.q = tk.StringVar()
        entry(top, 20, self.q).pack(side="right", padx=4, ipady=3)
        label(top, "Search:", MUTED, 9).pack(side="right")
        self.q.trace_add("write", lambda *_: self._devs())
        self.table = DeviceTable(b)
        self.table.grid(row=1, column=0, sticky="nsew")
        self.table.on_open = self.app.connect_row
        self.table.on_edit = lambda r: self.app.profile_dialog(True, r.get("profile"))
        self.table.on_delete = self.app.delete_row

    def _bottom(self, parent):
        row = tk.Frame(parent, bg=BG)
        row.grid(row=2, column=0, sticky="ew")
        for i in range(4):
            row.columnconfigure(i, weight=1, uniform="b")
        self.bgp_p = Panel(row, "BGP Peers", "◈", PURPLE, height=172)
        self.ppp_p = Panel(row, "PPPoE Clients", "☻", GREEN, height=172)
        self.top_p = Panel(row, "Interface Traffic (Top 5)", "▥", CYAN, height=172)
        self.log_p = Panel(row, "Recent Logs", "☰", ORANGE, height=172, link=("View All", lambda: self.app.navigate("Log")))
        for i, p in enumerate((self.bgp_p, self.ppp_p, self.top_p, self.log_p)):
            p.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 5, 0 if i == 3 else 5))
        self.bgp_d, self.bgp_t = Donut(self.bgp_p.body, 92, 13), label(self.bgp_p.body, "", MUTED, 9, justify="left")
        self.bgp_d.pack(side="right"); self.bgp_t.pack(side="left", padx=4)
        self.ppp_d, self.ppp_t = Donut(self.ppp_p.body, 92, 13), label(self.ppp_p.body, "", MUTED, 9, justify="left")
        self.ppp_d.pack(side="right"); self.ppp_t.pack(side="left", padx=4)
        self.bars = BarList(self.top_p.body)
        self.bars.pack(fill="both", expand=True)
        self.logs = LogList(self.log_p.body)
        self.logs.pack(fill="both", expand=True)

    def _resources(self, parent):
        p = Panel(parent, "System Resources", "◔", CYAN, height=190)
        p.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        self.gauges = {}
        for i, (k, name, col) in enumerate((("cpu", "CPU", CYAN), ("mem", "Memory", ORANGE), ("disk", "Disk", GREEN),
                                            ("up", "Uptime", PURPLE))):
            g = Gauge(p.body, name, col, 74)
            g.grid(row=0, column=i, padx=3)
            p.body.columnconfigure(i, weight=1)
            self.gauges[k] = g
        self.res_lbl = label(p.body, "", MUTED, 9)
        self.res_lbl.grid(row=1, column=0, columnspan=4, pady=(2, 0))

    def _tools(self, parent):
        p = Panel(parent, "Quick Tools", "⚡", BLUE, height=240)
        p.grid(row=1, column=0, sticky="ew", pady=(0, 10))
        A = self.app
        tiles = (("WinBox", "◈", CYAN, A.winbox_launcher, True), ("Terminal", "▭", TEXT, lambda: A.navigate("Terminal (API)"), False),
                 ("Torch", "≋", RED, lambda: A.navigate("Torch"), False),
                 ("BW Test", "◔", PURPLE, lambda: A.navigate("Bandwidth Test"), False),
                 ("Ping", "⌖", GREEN, lambda: A.navigate("Ping"), False),
                 ("Traceroute", "⛶", BLUE, lambda: A.navigate("Traceroute"), False),
                 ("DNS Lookup", "◍", BLUE, lambda: A.navigate("DNS Lookup"), False),
                 ("IP Scan", "⚑", GREEN, lambda: A.navigate("IP Scan"), False),
                 ("Export Cfg", "▤", BLUE, lambda: A.quick_action("export"), False),
                 ("Backup", "▣", ORANGE, lambda: A.quick_action("backup"), False),
                 ("Restore", "↺", RED, lambda: A.quick_action("restore"), False),
                 ("Reboot", "⟲", CYAN, lambda: A.quick_action("reboot"), False))
        for i, (t, g, c, fn, act) in enumerate(tiles):
            p.body.columnconfigure(i % 4, weight=1, uniform="t")
            ToolTile(p.body, t, g, c, fn, act).grid(row=i // 4, column=i % 4, padx=3, pady=3, sticky="ew")

    def _topology(self, parent):
        p = Panel(parent, "Topology Map", "⌬", RED, height=230, link=("View Full ›", lambda: self.app.navigate("Topology Map")))
        p.grid(row=2, column=0, sticky="nsew")
        self.topo = Topology(p.body)
        self.topo.pack(fill="both", expand=True)

    # ---- data ------------------------------------------------------------------------
    def on_show(self):
        self.visible = True
        self.app.telemetry.subscribe(self.on_data)
        self._tick()
        self._devs()

    def on_hide(self):
        self.visible = False
        if self.on_data in self.app.telemetry.subs:
            self.app.telemetry.subs.remove(self.on_data)

    def _tick(self):
        if not self.visible:
            return
        if not self.app.connected and self.app.settings.get("demo", True):
            d = self.app.demo.step()
            self.on_data(d)
        elif not self.app.connected:
            self._empty()
        self.after(int(self.app.telemetry.interval * 1000), self._tick)

    def _empty(self):
        for k, c in self.cards.items():
            c.set("—", "connect to a router")

    def on_fleet(self):
        if self.visible:
            self._devs()

    def _devs(self):
        q = self.q.get().strip().lower()
        rows = [r for r in self.app.fleet_rows() if not q or q in " ".join(str(v) for v in r.values()).lower()]
        self.table.set_rows(rows)

    def _series(self):
        t, sel = self.app.telemetry, self.if_combo.get()
        n = self.RANGES[self.range_combo.get()]
        if self.last and self.last.get("demo"):
            dm = self.app.demo
            if sel in ("", "All Interfaces"):
                return list(dm.rx_h)[-n:], list(dm.tx_h)[-n:], list(dm.st)[-n:]
            return list(dm.rx_h)[-n:], list(dm.tx_h)[-n:], list(dm.st)[-n:]
        if sel in ("", "All Interfaces"):
            return list(t.tot_rx)[-n:], list(t.tot_tx)[-n:], list(t.stamps)[-n:]
        h = list(t.if_hist.get(sel, []))[-n:]
        return [a for a, _ in h], [b for _, b in h], list(t.stamps)[-len(h):] if h else []

    def _chart(self):
        a, b, s = self._series()
        self.chart.set(a, b, s)

    def on_data(self, d):
        if not self.visible or (d.get("demo") and self.app.connected):
            return
        self.last = d
        demo, tot_rx, tot_tx = d.get("demo"), d.get("rx", 0), d.get("tx", 0)
        rows = self.app.fleet_rows()
        if demo:
            total, on, warn, off = 248, 235, 8, 5
        else:
            total = len(rows)
            on = sum(r["status"] == "online" for r in rows)
            warn = sum(r["status"] == "warning" for r in rows)
            off = sum(r["status"] == "offline" for r in rows)
        pct = lambda n: f"{n * 100 / total:.1f}%" if total else "—"
        wob = (lambda v: v + random.uniform(-.8, .8)) if demo else (lambda v: None)
        self.cards["total"].set(total, "▲ 12%" if demo else f"{total} saved", wob(total))
        self.cards["online"].set(on, "▼ " + pct(on) if demo else pct(on) + " up", wob(on))
        self.cards["warn"].set(warn, pct(warn), wob(warn))
        self.cards["off"].set(off, pct(off), wob(off))
        ppp = d.get("ppp_active", 0)
        self.cards["ppp"].set(f"{ppp:,}", "▲ 18%" if demo else f"of {d.get('ppp_total', 0):,}", ppp)
        self.cards["traffic"].set(rate(tot_rx + tot_tx), "▲ 12%" if demo else "live", tot_rx + tot_tx)
        # traffic
        names = ["All Interfaces"] + [i["name"] for i in d["ifaces"]]
        if list(self.if_combo["values"]) != names:
            self.if_combo["values"] = names
        sel = self.if_combo.get() or "All Interfaces"
        rx, tx = (tot_rx, tot_tx) if sel == "All Interfaces" else next(
            ((i["rx"], i["tx"]) for i in d["ifaces"] if i["name"] == sel), (0, 0))
        self.dl.configure(text="▼ " + rate(rx))
        self.ul.configure(text="▲ " + rate(tx))
        tt = (rx + tx) or 1
        self.donut.set([(rx, BLUE), (tx, GREEN)], rate(rx + tx), "Total")
        self.dlg.configure(text=f"● TX  {rate(tx)}  ({tx * 100 / tt:.0f}%)\n\n● RX  {rate(rx)}  ({rx * 100 / tt:.0f}%)")
        self._chart()
        # resources
        self.gauges["cpu"].set(d["cpu"])
        self.gauges["mem"].set(d["mem_pct"])
        self.gauges["disk"].set(d["disk_pct"])
        sec = parse_uptime(d["uptime"])
        self.gauges["up"].set(min(sec / 86400 / 30 * 100, 100), short_uptime(sec).replace(" ", "\n"))
        self.res_lbl.configure(text=f"{d.get('identity', '')} • {d.get('board', '')} • v{(d.get('version') or '').split(' ')[0]}"[:48])
        # bottom
        est, other, tot = d.get("bgp", (0, 0, 0))
        self.bgp_d.set([(est, GREEN), (other, ORANGE)], str(tot), "Peers")
        self.bgp_t.configure(text=f"Total: {tot}\n\n● Estab.  {est}\n● Other  {other}")
        pt = d.get("ppp_total", 0) or ppp
        self.ppp_d.set([(ppp, GREEN), (max(pt - ppp, 0), RED)], f"{ppp:,}", "Clients")
        self.ppp_t.configure(text=f"Total: {pt:,}\n\n● Online  {ppp:,}\n● Offline  {max(pt - ppp, 0):,}")
        top = sorted((i for i in d["ifaces"] if i["type"] in PHYSICAL + ("bridge", "vlan", "bonding")),
                     key=lambda i: i["rx"] + i["tx"], reverse=True)[:5]
        peak = max([i["rx"] + i["tx"] for i in top] + [1])
        self.bars.set([(i["name"], (i["rx"] + i["tx"]) / peak, f"{BarList._s(i['rx'])}/{BarList._s(i['tx'])}", BLUE)
                       for i in top])
        self.logs.set(d.get("logs", []))
        self.topo.set(*topo_from(d))
        self._devs()


# ---------------------------------------------------------------------------------------
class DevicesPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Devices", "saved router profiles • TCP reachability probe every 20 s")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 8))
        GButton(bar, "＋ Add Device", app.add_device, "purple", 120, bg=BG).pack(side="left")
        GButton(bar, "◎ Scan Network", app.scan_network_dialog, "blue", 130, bg=BG).pack(side="left", padx=8)
        GButton(bar, "⟳ Probe Now", app.fleet.probe_now, "cyan", 110, bg=BG).pack(side="left")
        GButton(bar, "⬇ Import JSON", self.imp, "green", 120, bg=BG).pack(side="left", padx=8)
        GButton(bar, "⬆ Export JSON", self.exp, "orange", 120, bg=BG).pack(side="left")
        p = Panel(self)
        p.pack(fill="both", expand=True)
        self.table = DeviceTable(p.body)
        self.table.pack(fill="both", expand=True)
        self.table.on_open = app.connect_row
        self.table.on_edit = lambda r: app.profile_dialog(True, r.get("profile"))
        self.table.on_delete = app.delete_row
        tk.Label(self, text="Double-click a row (or ⏵) to connect • ✎ edit • ✕ delete • passwords are never stored",
                 bg=BG, fg=MUTED, font=(FONT, 9)).pack(anchor="w", pady=(6, 0))
        self.visible = False

    def on_show(self):
        self.visible = True
        self.table.set_rows(self.app.fleet_rows(force_real=True))

    def on_hide(self):
        self.visible = False

    def on_fleet(self):
        if self.visible:
            self.table.set_rows(self.app.fleet_rows(force_real=True))

    def exp(self):
        f = filedialog.asksaveasfilename(defaultextension=".json", initialfile="routers.json", parent=self.app)
        if f:
            import json
            Path(f).write_text(json.dumps([{k: v for k, v in p.items() if k != "pw"} for p in self.app.profiles], indent=2), encoding="utf-8")

    def imp(self):
        f = filedialog.askopenfilename(filetypes=[("JSON", "*.json")], parent=self.app)
        if f:
            import json
            try:
                data = json.loads(Path(f).read_text(encoding="utf-8"))
                names = {p["name"] for p in self.app.profiles}
                for p in data:
                    if {"name", "host", "port", "username"} <= set(p) and p["name"] not in names:
                        self.app.profiles.append({k: p[k] for k in ("name", "host", "port", "username", "ssl", "location", "proto", "snmp_community", "snmp_version", "snmp_port", "auto_sync") if k in p})
                self.app.save_profiles()
                self.app.on_fleet()
            except Exception as e:
                messagebox.showerror("Import failed", str(e))


from pathlib import Path  # noqa: E402  (used above)


# ---------------------------------------------------------------------------------------
class QuickConnectPage(Page):
    """WinBox-loader style: connect by IP, discover neighbours (MNDP), pick a saved router."""

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Quick Connect", "WinBox loader — connect without creating a profile first")
        top = tk.Frame(self, bg=BG)
        top.pack(fill="x")
        p = Panel(top, "Connect To", "ϟ", ORANGE, height=335, width=430)
        p.pack(side="left", padx=(0, 10))
        p.pack_propagate(False)
        b = p.body
        self.v = {k: tk.StringVar(value=d) for k, d in (("host", ""), ("port", "8728"), ("user", "admin"), ("pw", ""))}
        for i, (lab, k, show) in enumerate((("Connect To (IP / host)", "host", None), ("API Port", "port", None),
                                            ("Login", "user", None), ("Password", "pw", "•"))):
            label(b, lab, MUTED, 9).grid(row=i, column=0, sticky="w", pady=6)
            entry(b, 26, self.v[k], show).grid(row=i, column=1, pady=6, padx=8, ipady=3)
        self.ssl, self.save = tk.BooleanVar(), tk.BooleanVar(value=True)
        for i, (t, v) in enumerate((("Use API-SSL (TLS)", self.ssl), ("Save as device (no password)", self.save))):
            tk.Checkbutton(b, text=t, variable=v, bg=CARD, fg=TEXT, selectcolor=CARD2, activebackground=CARD,
                           activeforeground=CYAN, command=self._ssl).grid(row=4 + i, column=0, columnspan=2, sticky="w")
        GButton(b, "ϟ  Connect", self.go, "blue", 190, 34).grid(row=6, column=0, columnspan=2, pady=10)
        q = Panel(top, "Neighbors (MNDP — Layer 2 discovery)", "⌬", GREEN, height=335)
        q.pack(side="left", fill="both", expand=True)
        q.pack_propagate(False)
        bar = tk.Frame(q.body, bg=CARD)
        bar.pack(fill="x")
        GButton(bar, "⟳ Discover (6 s)", self.discover, "green", 130, 28).pack(side="left")
        self.info = label(bar, "", MUTED, 9)
        self.info.pack(side="left", padx=10)
        cols = ("address", "mac", "identity", "platform", "version", "board", "interface")
        self.tree = ttk.Treeview(q.body, columns=cols, show="headings", height=6)
        for c in cols:
            self.tree.heading(c, text=c.upper())
            self.tree.column(c, width=92 if c not in ("identity", "mac") else 120)
        self.tree.pack(fill="both", expand=True, pady=(6, 0))
        self.tree.bind("<Double-1>", self.pick)
        self.tree.bind("<<TreeviewSelect>>", self.pick)
        saved = Panel(self, "Saved routers", "▤", BLUE)
        saved.pack(fill="both", expand=True, pady=(10, 0))
        self.table = DeviceTable(saved.body)
        self.table.pack(fill="both", expand=True)
        self.table.on_open = lambda r: self.fill(r["profile"]) if r.get("profile") else None
        self.table.on_edit = lambda r: app.profile_dialog(True, r.get("profile"))
        self.table.on_delete = app.delete_row

    def _ssl(self):
        if self.ssl.get() and self.v["port"].get() == "8728":
            self.v["port"].set("8729")
        elif not self.ssl.get() and self.v["port"].get() == "8729":
            self.v["port"].set("8728")

    def fill(self, p):
        self.v["host"].set(p["host"]); self.v["port"].set(str(p["port"])); self.v["user"].set(p["username"])
        self.ssl.set(p.get("ssl", False))

    def on_show(self):
        self.table.set_rows(self.app.fleet_rows(force_real=True))

    def pick(self, _e=None):
        sel = self.tree.selection()
        if sel:
            v = self.tree.item(sel[0], "values")
            if v[0]:
                self.v["host"].set(v[0])

    def discover(self):
        self.tree.delete(*self.tree.get_children())
        self.info.configure(text="Listening…", fg=YELLOW)
        cols = ("address", "mac", "identity", "platform", "version", "board", "interface")

        def done(rows):
            for r in rows:
                self.tree.insert("", "end", values=[r.get(c, "") for c in cols])
            self.info.configure(text=f"{len(rows)} device(s) found — select one to fill the address", fg=MUTED)
        self.app.run_async(lambda: mndp.scan(6), done, lambda e: self.info.configure(text=f"⚠ {e}", fg=RED))

    def go(self):
        host = self.v["host"].get().strip()
        if not host:
            messagebox.showinfo("Quick Connect", "Enter an IP address or host name.")
            return
        try:
            port = int(self.v["port"].get())
        except ValueError:
            messagebox.showerror("Quick Connect", "Invalid port.")
            return
        prof = {"name": host, "host": host, "port": port, "username": self.v["user"].get().strip() or "admin",
                "ssl": self.ssl.get()}
        if self.save.get() and not any(p["name"] == host for p in self.app.profiles):
            self.app.profiles.append(prof)
            self.app.save_profiles()
            self.app.refresh_profiles(host)
        self.app.connect_with(prof, self.v["pw"].get())


# ---------------------------------------------------------------------------------------
class MonitorPage(Page):
    """Graphical Monitor — one live chart per busiest interface (6 at a time) + total."""

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Graphical Monitor", "live RX / TX per interface — refreshed from the router every 2 s")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 8))
        tk.Label(bar, text="Window", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.win = combo(bar, ["5 Minutes", "15 Minutes", "1 Hour"], 12, "5 Minutes")
        self.win.pack(side="left", padx=8)
        self.mode = combo(bar, ["Busiest 6 interfaces", "Physical ports only"], 22)
        self.mode.pack(side="left")
        grid = tk.Frame(self, bg=BG)
        grid.pack(fill="both", expand=True)
        self.cells = []
        for i in range(7):
            grid.columnconfigure(i % 2, weight=1, uniform="m")
            grid.rowconfigure(i // 2, weight=1, uniform="r")
            p = Panel(grid, "—", "▥", BLUE)
            p.grid(row=i // 2, column=i % 2, sticky="nsew", padx=4, pady=4)
            ch = LineChart(p.body)
            ch.pack(fill="both", expand=True)
            self.cells.append((p, ch))
        self.visible = False

    def on_show(self):
        self.visible = True
        self.app.telemetry.subscribe(self.on_data)
        self._tick()

    def on_hide(self):
        self.visible = False
        if self.on_data in self.app.telemetry.subs:
            self.app.telemetry.subs.remove(self.on_data)

    def _tick(self):
        if self.visible and not self.app.connected and self.app.settings.get("demo", True):
            self.on_data(self.app.demo.step())
            self.after(2000, self._tick)

    def on_data(self, d):
        if not self.visible:
            return
        n = {"5 Minutes": 150, "15 Minutes": 450, "1 Hour": 1800}[self.win.get()]
        t = self.app.telemetry
        ifs = [i for i in d["ifaces"] if self.mode.current() == 0 or i["type"] in PHYSICAL]
        ifs = sorted(ifs, key=lambda i: i["rx"] + i["tx"], reverse=True)[:6]
        demo = d.get("demo")
        p0, c0 = self.cells[0]
        a, b, s = (list(self.app.demo.rx_h), list(self.app.demo.tx_h), list(self.app.demo.st)) if demo else \
            (list(t.tot_rx), list(t.tot_tx), list(t.stamps))
        p0.title, p0.accent = f"Total   ▼ {rate(d['rx'])}   ▲ {rate(d['tx'])}", GREEN
        p0._draw()
        c0.set(a[-n:], b[-n:], s[-n:])
        for (p, ch), i in zip(self.cells[1:], ifs + [None] * 6):
            if i is None:
                p.title = "—"
                p._draw()
                ch.set([], [], [])
                continue
            p.title = f"{i['name']}   ▼ {rate(i['rx'])}   ▲ {rate(i['tx'])}"
            p._draw()
            if demo:
                import random
                h = [(x * random.uniform(.25, .5), y * random.uniform(.25, .5)) for x, y in zip(a[-60:], b[-60:])]
            else:
                h = list(t.if_hist.get(i["name"], []))[-n:]
            ch.set([x for x, _ in h], [y for _, y in h], s[-len(h):] if h else [])


# ---------------------------------------------------------------------------------------
class TopologyPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Topology Map", "this router + Layer-2/3 neighbours (/ip/neighbor) — click a device to add it")
        p = Panel(self)
        p.pack(fill="both", expand=True)
        self.topo = Topology(p.body)
        self.topo.pack(fill="both", expand=True)
        self.topo.on_click = self.click
        self.d, self.visible = {}, False
        self.info = tk.Label(self, text="", bg=BG, fg=MUTED, font=(FONT, 9), anchor="w")
        self.info.pack(fill="x", pady=(6, 0))

    def on_show(self):
        self.visible = True
        self.app.telemetry.subscribe(self.on_data)
        if not self.app.connected and self.app.settings.get("demo", True):
            self.on_data(self.app.demo.step())

    def on_hide(self):
        self.visible = False
        if self.on_data in self.app.telemetry.subs:
            self.app.telemetry.subs.remove(self.on_data)

    def on_data(self, d):
        self.d = d
        self.topo.set(*topo_from(d, wide=True))
        self.info.configure(text=f"{len(d.get('neighbors', []))} neighbour(s) • identity: {d.get('identity', '')}"
                                 + ("   (DEMO data)" if d.get("demo") else ""))

    def click(self, nid):
        if nid.startswith("n"):
            n = self.d.get("neighbors", [])[int(nid[1:])]
            if n.get("address") and messagebox.askyesno("Add device", f"Add {n.get('identity') or n['address']} "
                                                                     f"({n['address']}) as a device?"):
                self.app.profile_dialog(False, None, prefill={"name": n.get("identity") or n["address"], "host": n["address"]})


# ---------------------------------------------------------------------------------------
class AlertsPage(Page):
    COL = {"critical": RED, "error": RED, "warning": ORANGE, "info": BLUE}

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Alerts & Notifications", "generated from live telemetry: CPU, memory, link-down, BGP, error logs")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 8))
        GButton(bar, "✓ Mark all read", app.alerts.mark_read, "green", 130, bg=BG).pack(side="left")
        GButton(bar, "✕ Clear", app.alerts.clear, "red", 90, bg=BG).pack(side="left", padx=8)
        GButton(bar, "⬆ Export CSV", self.export, "blue", 110, bg=BG).pack(side="left")
        p = Panel(self)
        p.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(p.body, columns=("t", "l", "m"), show="headings")
        for c, h, w in (("t", "TIME", 90), ("l", "LEVEL", 90), ("m", "MESSAGE", 900)):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, stretch=c == "m")
        for k, col in self.COL.items():
            self.tree.tag_configure(k, foreground=col)
        self.tree.pack(fill="both", expand=True)

    def on_show(self):
        self.app.alerts.subs.append(self.fill)
        self.fill()
        self.app.alerts.mark_read()

    def on_hide(self):
        if self.fill in self.app.alerts.subs:
            self.app.alerts.subs.remove(self.fill)

    def fill(self):
        if not self.winfo_exists():
            return
        self.tree.delete(*self.tree.get_children())
        for t, lvl, msg in self.app.alerts.items:
            self.tree.insert("", "end", values=(t, lvl.upper(), msg), tags=(lvl,))

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="alerts.csv", parent=self.app)
        if f:
            import csv
            with open(f, "w", newline="", encoding="utf-8") as fh:
                w = csv.writer(fh)
                w.writerow(["time", "level", "message"])
                w.writerows(self.app.alerts.items)


# ---------------------------------------------------------------------------------------
class ReportsPage(Page):
    SECTIONS = (
        ("System resource", "/system/resource", ""),
        ("RouterBOARD", "/system/routerboard", ""),
        ("Interfaces", "/interface", "name type mtu mac-address running disabled rx-byte tx-byte comment"),
        ("IP addresses", "/ip/address", "address network interface disabled comment"),
        ("Routes", "/ip/route", "dst-address gateway distance routing-table comment"),
        ("DHCP leases", "/ip/dhcp-server/lease", "address mac-address host-name status comment"),
        ("PPP active sessions", "/ppp/active", "name service caller-id address uptime"),
        ("Simple queues", "/queue/simple", "name target max-limit comment"),
        ("Firewall filter", "/ip/firewall/filter", "chain action protocol src-address dst-address dst-port comment"),
        ("NAT", "/ip/firewall/nat", "chain action protocol src-address dst-address dst-port to-addresses comment"),
        ("Users", "/user", "name group address last-logged-in"),
        ("IP services", "/ip/service", "name port address disabled"),
        ("Packages", "/system/package", "name version"),
    )

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Reports", "export router inventory & configuration summaries")
        p = Panel(self, "Generate report", "▤", GREEN, height=190)
        p.pack(fill="x")
        label(p.body, "Choose sections, then export a self-contained HTML report (opens in your browser) or CSV files.",
              MUTED, 9).pack(anchor="w")
        grid = tk.Frame(p.body, bg=CARD)
        grid.pack(fill="x", pady=8)
        self.vars = []
        for i, (t, _p, _c) in enumerate(self.SECTIONS):
            v = tk.BooleanVar(value=i < 8)
            self.vars.append(v)
            tk.Checkbutton(grid, text=t, variable=v, bg=CARD, fg=TEXT, selectcolor=CARD2, activebackground=CARD,
                           activeforeground=CYAN).grid(row=i // 5, column=i % 5, sticky="w", padx=8)
        row = tk.Frame(p.body, bg=CARD)
        row.pack(fill="x")
        GButton(row, "▤ HTML report", lambda: self.run("html"), "blue", 140, 32).pack(side="left")
        GButton(row, "⬇ CSV files", lambda: self.run("csv"), "green", 120, 32).pack(side="left", padx=8)
        self.msg = label(row, "", MUTED, 9)
        self.msg.pack(side="left", padx=10)
        self.out = tk.Text(self, bg=CARD, fg=TEXT, relief="flat", font=(MONO, 9), height=14)
        self.out.pack(fill="both", expand=True, pady=(10, 0))

    def run(self, kind):
        api = self.app.require()
        if not api:
            return
        chosen = [s for s, v in zip(self.SECTIONS, self.vars) if v.get()]
        if not chosen:
            return
        target = None
        if kind == "html":
            target = filedialog.asksaveasfilename(defaultextension=".html", initialfile=f"router-report-{time.strftime('%Y%m%d')}.html",
                                                  parent=self.app)
        else:
            target = filedialog.askdirectory(parent=self.app)
        if not target:
            return
        self.msg.configure(text="Collecting…", fg=YELLOW)
        clone = api.clone()

        def work():
            clone.connect()
            data = []
            try:
                for title, path, cols in chosen:
                    try:
                        rows = clone.command(path + "/print")
                    except Exception as e:
                        rows = [{"error": str(e)}]
                    data.append((title, cols.split(), rows))
            finally:
                clone.close()
            return data

        def done(data):
            ident = self.app.telemetry.d.get("identity", "router")
            if kind == "html":
                Path(target).write_text(self.build_html(ident, data), encoding="utf-8")
                webbrowser.open(Path(target).as_uri())
            else:
                import csv
                for title, cols, rows in data:
                    keys = cols or sorted({k for r in rows for k in r if not k.startswith(".")})
                    with open(Path(target) / f"{title.replace(' ', '_')}.csv", "w", newline="", encoding="utf-8") as fh:
                        w = csv.writer(fh)
                        w.writerow(keys)
                        for r in rows:
                            w.writerow([r.get(k, "") for k in keys])
            self.msg.configure(text=f"✔ {len(data)} section(s) exported", fg=GREEN)
            self.out.insert("end", f"✔ {time.strftime('%H:%M:%S')}  {kind.upper()} → {target}\n")
        self.app.run_async(work, done, lambda e: self.msg.configure(text=f"⚠ {e}", fg=RED))

    @staticmethod
    def build_html(ident, data):
        h = ["<!doctype html><meta charset='utf-8'><title>Router report</title><style>"
             "body{background:#060d1b;color:#eaf3ff;font:14px Segoe UI,Arial;margin:30px}h1{color:#22d3ee}"
             "h2{color:#2f8cff;margin-top:28px}table{border-collapse:collapse;width:100%;background:#0c1a33}"
             "th{background:#102345;color:#22d3ee;text-align:left;padding:6px 10px;font-size:12px}"
             "td{padding:5px 10px;border-top:1px solid #1b3358;font-size:12px}tr:nth-child(even) td{background:#0a1830}"
             "</style>", f"<h1>MikroTik report — {html.escape(ident)}</h1><p>Generated {time.strftime('%Y-%m-%d %H:%M:%S')}</p>"]
        for title, cols, rows in data:
            keys = cols or sorted({k for r in rows for k in r if not k.startswith(".")})
            h.append(f"<h2>{html.escape(title)} <small>({len(rows)})</small></h2><table><tr>" +
                     "".join(f"<th>{html.escape(k)}</th>" for k in keys) + "</tr>")
            for r in rows:
                h.append("<tr>" + "".join(f"<td>{html.escape(str(r.get(k, '')))}</td>" for k in keys) + "</tr>")
            h.append("</table>")
        return "".join(h)


# ---------------------------------------------------------------------------------------
class AppSettingsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Settings", "stored in %APPDATA%\\MikroTikDesktopManager\\settings.json (no passwords)")
        p = Panel(self, "Application", "⚙", BLUE, height=330)
        p.pack(fill="x")
        b = p.body
        self.vars = {}
        opts = (("demo", "Show DEMO preview data on the dashboard while disconnected", True),
                ("winbox_mode", "WinBox mode — open every menu in its own floating window", False),
                ("verify_tls", "Verify TLS certificate by default (API-SSL)", False))
        for i, (k, t, d) in enumerate(opts):
            v = tk.BooleanVar(value=app.settings.get(k, d))
            self.vars[k] = v
            tk.Checkbutton(b, text=t, variable=v, bg=CARD, fg=TEXT, selectcolor=CARD2, activebackground=CARD,
                           activeforeground=CYAN, command=self.save).grid(row=i, column=0, columnspan=3, sticky="w", pady=4)
        label(b, "Telemetry interval (seconds)", MUTED, 9).grid(row=4, column=0, sticky="w", pady=(10, 0))
        self.iv = combo(b, ["1", "2", "3", "5", "10"], 6, str(int(app.settings.get("interval", 2))))
        self.iv.grid(row=4, column=1, sticky="w", padx=8, pady=(10, 0))
        self.iv.bind("<<ComboboxSelected>>", lambda _e: self.save())
        label(b, "Alerts: CPU ≥ 85 %, memory ≥ 90 %, link down, BGP not established, error/critical log lines.",
              DIM, 9).grid(row=5, column=0, columnspan=3, sticky="w", pady=(12, 0))

    def save(self):
        for k, v in self.vars.items():
            self.app.settings[k] = v.get()
        self.app.settings["interval"] = float(self.iv.get())
        self.app.apply_settings()


# ---------------------------------------------------------------------------------------
class DnsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("DNS Lookup", "resolved from this PC • use Tools → Any Menu → /ip/dns/cache for the router's cache")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 8))
        tk.Label(bar, text="Name", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.v = tk.StringVar(value="example.com")
        e = entry(bar, 34, self.v)
        e.pack(side="left", padx=8, ipady=3)
        e.bind("<Return>", lambda _e: self.go())
        GButton(bar, "◍ Lookup", self.go, "blue", 100, 30, bg=BG).pack(side="left")
        p = Panel(self)
        p.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(p.body, columns=("family", "address"), show="headings")
        self.tree.heading("family", text="FAMILY")
        self.tree.heading("address", text="ADDRESS")
        self.tree.pack(fill="both", expand=True)

    def go(self):
        name = self.v.get().strip()
        self.tree.delete(*self.tree.get_children())

        def work():
            return sorted({(("IPv6" if a[0] == socket.AF_INET6 else "IPv4"), a[4][0]) for a in socket.getaddrinfo(name, None)})
        self.app.run_async(work, lambda rows: [self.tree.insert("", "end", values=r) for r in rows],
                           lambda e: self.tree.insert("", "end", values=("error", str(e))))


PAGE_KINDS.update({"dashboard": DashboardPro, "devices": DevicesPage, "quickconnect": QuickConnectPage,
                   "monitor": MonitorPage, "topology": TopologyPage, "alerts": AlertsPage, "reports": ReportsPage,
                   "settings_app": AppSettingsPage, "dns": DnsPage})
