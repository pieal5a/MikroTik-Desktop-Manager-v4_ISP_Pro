"""App-level ISP operations (mixed into App): router passwords, push / enable / disable / delete PPPoE secrets,
sync triggers.  All router I/O runs on worker threads; results come back through app.post()."""
import threading
import tkinter as tk
from tkinter import messagebox, simpledialog

import secret
from transport import NotSupported
from isp_common import STATUS_LABEL


class ISPMixin:
    def profile_by_name(self, name):
        return next((p for p in self.profiles if p["name"] == name), None)

    def get_router_password(self, p, ask=True):
        """Saved password if any, otherwise ask (UI thread). SNMP needs none. Returns None when cancelled."""
        if p.get("proto") == "snmp":
            return ""
        if p.get("save_pw") or p.get("pw") is not None:
            return secret.unprotect(p.get("pw", ""))
        if not ask:
            return None
        return simpledialog.askstring("Router password", f"Password for {p['username']}@{p['host']} ({p['name']}):",
                                      show="•", parent=self)

    def sync_now(self, p):
        pw = self.get_router_password(p)
        if pw is None:
            return
        self.sync.sync(p, password=pw)

    def on_sync(self):
        for pg in list(self.all_pages()):
            if hasattr(pg, "on_sync"):
                try:
                    pg.on_sync()
                except Exception:
                    import traceback
                    traceback.print_exc()

    # ---- generic per-client router operation ------------------------------------------------------------------------
    def router_op(self, ids, op, label, done=None, skip_not_on_router=False):
        db = self.db
        groups, problems = {}, []
        for cid in ids:
            c = db.client(cid)
            if not c:
                continue
            if skip_not_on_router and not c["on_router"]:
                continue
            p = self.profile_by_name(c["router"])
            if not p:
                problems.append(f"{c['pppoe_id']}: no router assigned")
            elif p.get("proto") not in ("api", "api-ssl", "ssh", "telnet"):
                problems.append(f"{c['pppoe_id']}: {p['name']} uses {p.get('proto', '').upper()} (read-only)")
            else:
                groups.setdefault(p["name"], (p, []))[1].append(c)
        passwords = {}
        for name, (p, _cl) in groups.items():
            pw = self.get_router_password(p)
            if pw is None:
                return
            passwords[name] = pw
        if not groups:
            if problems:
                messagebox.showwarning(label, "\n".join(problems[:15]), parent=self)
            if done:
                done(set())
            return

        def work():
            ok, errs = set(), list(problems)
            for name, (p, clients) in groups.items():
                try:
                    def run(link, clients=clients):
                        for c in clients:
                            try:
                                op(link, c)
                                ok.add(c["id"])
                            except Exception as e:
                                errs.append(f"{c['pppoe_id']}: {e}")
                    self.sync.with_link(p, passwords[name], run)
                except Exception as e:
                    errs.append(f"{name}: {e}")
            return ok, errs

        def finish(res):
            ok, errs = res
            if done:
                done(ok)
            db.log("router-op", f"{label}: ok={len(ok)} errors={len(errs)}")
            if errs:
                messagebox.showwarning(label, f"{len(ok)} done, {len(errs)} problem(s):\n\n" + "\n".join(errs[:15]), parent=self)
            self.on_sync()
        self.run_async(work, finish, lambda e: messagebox.showerror(label, str(e), parent=self))

    # ---- push clients (create / update PPPoE secret) ------------------------------------------------------------------
    def push_clients(self, ids, quiet=False):
        db = self.db
        existing = {}

        def op(link, c):
            names = existing.get(c["router"])
            if names is None:
                names = existing[c["router"]] = {s.get("name") for s in link.secrets()}
            pk = next((p for p in db.packages() if p["name"] == c["package"]), None)
            profile = (pk or {}).get("mt_profile") or c["package"]
            comment = c["name"] or ""
            if c["pppoe_id"] in names:
                kw = {}
                if c["pppoe_pass"]:
                    kw["password"] = c["pppoe_pass"]
                if profile:
                    kw["profile"] = profile
                if comment:
                    kw["comment"] = comment
                link.secret_set(c["pppoe_id"], **kw)
            else:
                link.secret_add(c["pppoe_id"], c["pppoe_pass"] or "123456", profile, comment)
            if c["status"] == "suspended":
                link.secret_enable(c["pppoe_id"], False)

        def done(ok):
            for i in ok:
                db.x("UPDATE clients SET on_router=1 WHERE id=?", (i,))
            if ok and not quiet:
                messagebox.showinfo("Push to router", f"{len(ok)} client(s) created / updated on the router.", parent=self)
        self.router_op(ids, op, "Push to router", done=done)

    # ---- after a payment: offer to re-enable a suspended client ----------------------------------------------------------
    def after_payment(self, cid):
        c = self.db.client(cid)
        if not c or c["status"] != "suspended":
            return
        if sum(d["due"] for d in self.db.due_months(cid)) > 0:
            return
        if not messagebox.askyesno("Re-enable client", f"{c['name'] or c['pppoe_id']} is suspended and now has no due.\n"
                                   "Enable the PPPoE account again?", parent=self):
            return

        def done(ok):
            if cid in ok or not c["on_router"]:
                self.db.set_status(cid, "active")
            self.on_sync()
        self.router_op([cid], lambda link, cl: link.secret_enable(cl["pppoe_id"], True), "Enable", done=done,
                       skip_not_on_router=True)
