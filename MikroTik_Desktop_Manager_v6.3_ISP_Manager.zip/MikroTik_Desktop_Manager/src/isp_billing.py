"""Billing & Collection page and Packages page."""
import html
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import db as dbm
from core import *
from core import PAGE_KINDS
from isp_clients import PayDialog, combo, month_choices, mkey, webbrowser_open
from isp_common import *
from ui_kit import GButton


class BillingPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Billing & Collection", "monthly bills • payments • due list • receipts")
        self.month = tk.StringVar(value=month_choices()[2])
        self.router, self.view = tk.StringVar(value="All routers"), tk.StringVar(value="All bills")
        self.q = tk.StringVar()
        self.q.trace_add("write", lambda *_: self.refresh())
        self.cards = {}
        row = tk.Frame(self, bg=BG)
        row.pack(fill="x", pady=(0, 8))
        for key, title, color in (("expected", "Expected this month (৳)", BLUE), ("paid", "Received on those bills (৳)", GREEN),
                                  ("due", "Due this month (৳)", ORANGE), ("pct", "Collection rate", CYAN),
                                  ("total_due", "Total outstanding, all months (৳)", RED), ("due_clients", "Clients owing", ORANGE)):
            c = tk.Frame(row, bg=CARD, highlightbackground=BORDER, highlightthickness=1)
            c.pack(side="left", padx=(0, 8), ipadx=10, ipady=4)
            tk.Frame(c, bg=color, height=3).pack(fill="x")
            v = tk.Label(c, text="0", bg=CARD, fg=color, font=(FONT, 15, "bold"))
            v.pack(anchor="w", padx=10)
            tk.Label(c, text=title, bg=CARD, fg=MUTED, font=(FONT, 8)).pack(anchor="w", padx=10)
            self.cards[key] = v
        f = tk.Frame(self, bg=BG)
        f.pack(fill="x", pady=(0, 6))
        tk.Label(f, text="Month", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
        mc = combo(f, month_choices(), 18, var=self.month)
        mc.pack(side="left", padx=6)
        mc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        self.rc = combo(f, [], 14, var=self.router)
        self.rc.pack(side="left", padx=4)
        self.rc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        vc = combo(f, ["All bills", "Due only", "Paid only"], 10, var=self.view)
        vc.pack(side="left", padx=4)
        vc.bind("<<ComboboxSelected>>", lambda _e: self.refresh())
        e = app.entry(f, 22)
        e.configure(textvariable=self.q)
        e.pack(side="left", padx=8, ipady=3)
        b = tk.Frame(self, bg=BG)
        b.pack(fill="x", pady=(0, 6))
        for text, fn, col, w in (("🧾 Generate Bills", self.generate, "purple", 130), ("💰 Receive Payment", self.pay, "green", 140),
                                 ("📱 WhatsApp Reminder", self.remind, "cyan", 150), ("🖨 Due List (print)", self.due_list, "orange", 140),
                                 ("🖨 Report", self.report, "blue", 100), ("⬇ Export CSV", self.export, "blue", 110)):
            GButton(b, text, fn, col, max(w, 26 + 7 * len(text)), 30, bg=BG).pack(side="left", padx=(0, 6))
        cols = [("c", "PPPOE ID", 120), ("n", "CLIENT", 170), ("p", "PHONE", 110), ("r", "ROUTER", 110), ("k", "PACKAGE", 90),
                ("a", "BILL", 75, "e"), ("d", "DISCOUNT", 75, "e"), ("pd", "PAID", 75, "e"), ("du", "DUE", 75, "e"), ("s", "STATE", 80)]
        wrap, self.tree = scrolled_tree(self, cols)
        wrap.pack(fill="both", expand=True)
        self.tree.configure(selectmode="extended")
        self.tree.bind("<Double-1>", lambda _e: self.pay())
        low = tk.Frame(self, bg=BG)
        low.pack(fill="x", pady=(8, 0))
        self.sub = {}
        for key, title, cols2 in (("method", "Collected by method", [("m", "METHOD", 90), ("n", "COUNT", 55, "e"), ("t", "TOTAL", 90, "e")]),
                                  ("day", "Daily collection", [("m", "DAY", 90), ("n", "COUNT", 55, "e"), ("t", "TOTAL", 90, "e")]),
                                  ("router", "By router", [("m", "ROUTER", 110), ("n", "CLIENTS", 60, "e"), ("e", "EXPECTED", 80, "e"),
                                                           ("t", "PAID", 80, "e")])):
            box = tk.Frame(low, bg=BG)
            box.pack(side="left", fill="both", expand=True, padx=(0, 8))
            tk.Label(box, text=title, bg=BG, fg=CYAN, font=(FONT, 9, "bold")).pack(anchor="w")
            w, t = scrolled_tree(box, cols2, height=5)
            w.pack(fill="both", expand=True)
            self.sub[key] = t

    def on_show(self):
        self.refresh()

    def on_sync(self):
        if self.winfo_ismapped():
            self.refresh()

    def refresh(self):
        db = self.app.db
        m = mkey(self.month.get())
        names = [p["name"] for p in self.app.profiles]
        self.rc["values"] = ["All routers"] + names
        if self.router.get() not in names:
            self.router.set("All routers")
        rows = db.month_bills(m, self.q.get().strip(), "" if self.router.get().startswith("All") else self.router.get())
        v = self.view.get()
        if v == "Due only":
            rows = [r for r in rows if r["due"] > 0]
        elif v == "Paid only":
            rows = [r for r in rows if r["due"] <= 0]
        self.rows = rows
        self.tree.delete(*self.tree.get_children())
        for i, r in enumerate(rows):
            state = "Paid" if r["due"] <= 0 else ("Partial" if r["paid"] > 0 else "Unpaid")
            tag = ["odd"] if i % 2 else []
            tag.append("ok" if state == "Paid" else "due" if state == "Partial" else "bad")
            self.tree.insert("", "end", iid=str(r["client_id"]), tags=tag, values=(
                r["pppoe_id"], r["name"], r["phone1"], r["router"], r["package"], money(r["amount"]), money(r["discount"]),
                money(r["paid"]), money(r["due"]), state))
        s = db.summary(m)
        for k, lab in self.cards.items():
            lab.configure(text=(f"{(s['paid'] * 100 / s['expected']):.0f}%" if s["expected"] else "—") if k == "pct" else money(s.get(k) or 0))
        for key, data in (("method", db.by_method(m)), ("day", db.by_day(m)), ("router", db.by_router(m))):
            t = self.sub[key]
            t.delete(*t.get_children())
            for r in data:
                vals = {"method": (r.get("method"), r.get("n"), money(r.get("total"))),
                        "day": (r.get("day"), r.get("n"), money(r.get("total"))),
                        "router": (r.get("router") or "—", r.get("clients"), money(r.get("expected")), money(r.get("paid")))}[key]
                t.insert("", "end", values=vals)

    def generate(self):
        m = mkey(self.month.get())
        n = self.app.db.generate_bills(m)
        messagebox.showinfo("Bills", f"{n} new bill(s) created for {dbm.month_label(m)}.\n"
                            "(Only active / suspended clients with a bill amount > 0 who joined by that month.)", parent=self.app)
        self.refresh()

    def _sel(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Select", "Select a bill row first.", parent=self.app)
        return [int(i) for i in sel]

    def pay(self):
        ids = self._sel()
        if ids:
            PayDialog(self.app, ids[0], self.refresh, mkey(self.month.get()))

    def remind(self):
        ids = self._sel()
        if not ids:
            return
        m = mkey(self.month.get())
        c = self.app.db.client(ids[0])
        due = sum(d["due"] for d in self.app.db.due_months(c["id"], m))
        if due <= 0 or not c["phone1"]:
            messagebox.showinfo("Reminder", "No due amount or no phone number for this client.", parent=self.app)
            return
        webbrowser_open(wa_link(c["phone1"], reminder_text(c, due, dbm.month_label(m), self.app.settings)))

    def _report_head(self, title):
        s = self.app.settings
        return (f"<!doctype html><meta charset='utf-8'><title>{html.escape(title)}</title><style>body{{font-family:Segoe UI,Arial;margin:24px}}"
                "table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:5px 8px;font-size:13px}th{background:#1d4ed8;color:#fff}"
                "td.r{text-align:right}h1{color:#1d4ed8;margin:0}</style>"
                f"<h1>{html.escape(s.get('company', BRAND['company']))}</h1><div>{html.escape(s.get('site', BRAND['site']))}</div>"
                f"<h2>{html.escape(title)}</h2>")

    def due_list(self):
        m = mkey(self.month.get())
        rows = self.app.db.clients("", self.router.get() if not self.router.get().startswith("All") else "", "", "due", m)
        e = html.escape
        body = "".join(
            f"<tr><td>{i}</td><td>{e(c['pppoe_id'])}</td><td>{e(c['name'])}</td><td>{e(c['phone1'])}</td><td>{e(c['address'])}</td>"
            f"<td>{e(c['router'])}</td><td>{', '.join(d['month'] for d in self.app.db.due_months(c['id'], m))}</td>"
            f"<td class='r'>{money(c['total_due'])}</td></tr>" for i, c in enumerate(rows, 1))
        total = sum(c["total_due"] for c in rows)
        show_html(self._report_head(f"Due list up to {dbm.month_label(m)}") +
                  "<table><tr><th>#</th><th>PPPoE</th><th>Name</th><th>Phone</th><th>Address</th><th>Router</th><th>Due months</th>"
                  f"<th>Due ৳</th></tr>{body}<tr><td colspan=7><b>Total ({len(rows)} clients)</b></td><td class='r'><b>{money(total)}</b></td></tr></table>",
                  "due_list")

    def report(self):
        m = mkey(self.month.get())
        db, e = self.app.db, html.escape
        s = db.summary(m)
        pay = "".join(f"<tr><td>{e(p['paid_at'])}</td><td>{e(p['pppoe_id'] or '')}</td><td>{e(p['name'] or '')}</td><td>{p['month']}</td>"
                      f"<td>{e(p['method'])}</td><td class='r'>{money(p['amount'])}</td></tr>" for p in db.payments(month=None)
                      if p["paid_at"][:7] == m)
        show_html(self._report_head(f"Collection report — {dbm.month_label(m)}") +
                  f"<p>Expected <b>{money(s['expected'])}</b> • Collected <b>{money(s['collected'])}</b> • Due this month <b>{money(s['due'])}</b> "
                  f"• Total outstanding <b>{money(s['total_due'])}</b></p><table><tr><th>Date</th><th>PPPoE</th><th>Client</th><th>For month</th>"
                  f"<th>Method</th><th>Amount</th></tr>{pay}</table>", "collection")

    def export(self):
        f = filedialog.asksaveasfilename(defaultextension=".csv", initialfile=f"bills_{mkey(self.month.get())}.csv", parent=self.app)
        if f:
            self.app.db.export_csv(f, self.rows, ["month", "pppoe_id", "name", "phone1", "router", "package", "amount", "discount", "paid", "due"])


# ======================================================================================================
class PackageDialog(tk.Toplevel):
    def __init__(self, app, pkg, on_ok):
        super().__init__(app)
        self.title("Package")
        self.configure(bg=BG)
        self.transient(app)
        self.pkg, self.on_ok = dict(pkg or {}), on_ok
        self.e = {}
        for i, (lab, k) in enumerate((("Package name *", "name"), ("Speed (e.g. 10 Mbps)", "speed"), ("Monthly price (৳)", "price"),
                                      ("MikroTik PPP profile", "mt_profile"), ("Note", "note"))):
            tk.Label(self, text=lab, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=i, column=0, sticky="w", padx=14, pady=7)
            w = app.entry(self, 28)
            w.insert(0, str(self.pkg.get(k, "") or ""))
            w.grid(row=i, column=1, padx=14)
            self.e[k] = w
        app.button(self, "Save", self.ok, True).grid(row=6, column=0, columnspan=2, sticky="ew", padx=14, pady=14)
        self.after(60, lambda: self.grab_set() if self.winfo_exists() else None)

    def ok(self):
        d = {k: w.get().strip() for k, w in self.e.items()}
        if not d["name"]:
            return
        try:
            d["price"] = float(d["price"] or 0)
        except ValueError:
            messagebox.showerror("Price", "Price must be a number.", parent=self)
            return
        d["id"] = self.pkg.get("id")
        self.on_ok(d)
        self.destroy()


class PackagesPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Packages", "internet plans • price • MikroTik PPP profile")
        b = tk.Frame(self, bg=BG)
        b.pack(fill="x", pady=(0, 8))
        for text, fn, col, w in (("＋ Add Package", self.add, "purple", 120), ("✎ Edit", self.edit, "blue", 90),
                                 ("− Delete", self.delete, "red", 90), ("⬇ Import router profiles", self.imp, "cyan", 170),
                                 ("↻ Apply price to clients", self.apply, "orange", 170)):
            GButton(b, text, fn, col, w, 30, bg=BG).pack(side="left", padx=(0, 6))
        wrap, self.tree = scrolled_tree(self, [("n", "PACKAGE", 160), ("s", "SPEED", 110), ("p", "PRICE ৳", 90, "e"), ("m", "PPP PROFILE", 150),
                                               ("c", "CLIENTS", 70, "e"), ("o", "NOTE", 300)])
        wrap.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda _e: self.edit())

    def on_show(self):
        self.refresh()

    def refresh(self):
        self.tree.delete(*self.tree.get_children())
        counts = {r["package"]: r["n"] for r in self.app.db.q("SELECT package, COUNT(*) n FROM clients GROUP BY package")}
        for p in self.app.db.packages():
            self.tree.insert("", "end", iid=str(p["id"]), values=(p["name"], p["speed"], money(p["price"]), p["mt_profile"],
                                                                  counts.get(p["name"], 0), p["note"]))

    def _save(self, d):
        self.app.db.save_package(d)
        self.refresh()

    def add(self):
        PackageDialog(self.app, None, self._save)

    def _cur(self):
        sel = self.tree.selection()
        return next((p for p in self.app.db.packages() if str(p["id"]) == sel[0]), None) if sel else None

    def edit(self):
        p = self._cur()
        if p:
            PackageDialog(self.app, p, self._save)

    def delete(self):
        p = self._cur()
        if p and messagebox.askyesno("Delete", f"Delete package '{p['name']}'? (clients keep their package text)", parent=self.app):
            self.app.db.delete_package(p["id"])
            self.refresh()

    def apply(self):
        p = self._cur()
        if not p:
            return
        if messagebox.askyesno("Apply price", f"Set the monthly bill of ALL clients on '{p['name']}' to {money(p['price'])} ৳?\n"
                               "(Existing generated bills keep their old amount.)", parent=self.app):
            self.app.db.x("UPDATE clients SET bill=? WHERE package=?", (p["price"], p["name"]))
            self.app.db.log("package-price", f"{p['name']} -> {p['price']:g}")

    def imp(self):
        profs = [p for p in self.app.profiles if p.get("proto", "api") in ("api", "api-ssl", "ssh", "telnet")]
        if not profs:
            messagebox.showinfo("Import", "Add an API / SSH / Telnet router first.", parent=self.app)
            return
        p = profs[0] if len(profs) == 1 else self._choose(profs)
        if not p:
            return
        pw = self.app.get_router_password(p)
        if pw is None:
            return
        self.app.run_async(lambda: self.app.sync.with_link(p, pw, lambda l: l.profiles()), self._got,
                           lambda e: messagebox.showerror("Import", str(e), parent=self.app))

    def _choose(self, profs):
        from tkinter import simpledialog
        n = simpledialog.askstring("Router", "Router name:\n" + "\n".join(p["name"] for p in profs), parent=self.app)
        return next((p for p in profs if p["name"] == n), None)

    def _got(self, rows):
        n = 0
        have = {p["name"] for p in self.app.db.packages()}
        for r in rows:
            nm = r.get("name", "")
            if nm and nm not in have and nm not in ("default", "default-encryption"):
                self.app.db.save_package(dict(name=nm, speed=r.get("rate-limit", ""), price=0, mt_profile=nm))
                n += 1
        messagebox.showinfo("Import", f"{n} profile(s) imported — now set their prices.", parent=self.app)
        self.refresh()


PAGE_KINDS.update({"billing": BillingPage, "packages": PackagesPage})
