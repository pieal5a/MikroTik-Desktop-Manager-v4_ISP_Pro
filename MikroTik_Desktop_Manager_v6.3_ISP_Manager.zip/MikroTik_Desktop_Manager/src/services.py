"""Background services: live telemetry (own API session), alert centre, fleet reachability probe, demo data."""
import math
import random
import re
import socket
import threading
import time
from collections import deque
from concurrent.futures import ThreadPoolExecutor

PHYSICAL = ("ether", "wlan", "wifi", "lte", "pppoe-out", "sfp", "sfpplus", "wg")
SKIP_TYPES = ("pppoe-in", "l2tp-in", "sstp-in", "ovpn-in", "pptp-in", "ppp-in")


def parse_uptime(s):
    """RouterOS '1w2d3h4m5s' -> seconds."""
    mult = {"w": 604800, "d": 86400, "h": 3600, "m": 60, "s": 1}
    return sum(int(n) * mult[u] for n, u in re.findall(r"(\d+)([wdhms])", s or ""))


def short_uptime(s):
    sec = parse_uptime(s) if not isinstance(s, (int, float)) else int(s)
    d, h, m = sec // 86400, sec % 86400 // 3600, sec % 3600 // 60
    return f"{d}d {h}h" if d else f"{h}h {m}m"


def _i(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------------------
class AlertCenter:
    def __init__(self):
        self.items, self.unread, self.last, self.subs = deque(maxlen=500), 0, {}, []

    def add(self, level, key, text, cooldown=300):
        now = time.time()
        if now - self.last.get(key, 0) < cooldown:
            return
        self.last[key] = now
        self.items.appendleft((time.strftime("%H:%M:%S"), level, text))
        self.unread += 1
        for fn in self.subs:
            fn()

    def mark_read(self):
        self.unread = 0
        for fn in self.subs:
            fn()

    def clear(self):
        self.items.clear()
        self.mark_read()


# ---------------------------------------------------------------------------------------
class Telemetry:
    """Polls the connected router every few seconds on a dedicated API session and publishes snapshots."""
    HIST = 1800

    def __init__(self, app):
        self.app, self.evt, self.clone, self.subs = app, threading.Event(), None, []
        self.d, self.demo = {}, None
        self.tot_rx, self.tot_tx, self.stamps = deque(maxlen=self.HIST), deque(maxlen=self.HIST), deque(maxlen=self.HIST)
        self.if_hist = {}
        self.prev, self.extra, self.last_extra = {}, {}, 0
        self.interval = 2.0

    def subscribe(self, fn):
        self.subs.append(fn)
        if self.d:
            fn(self.d)

    def reset(self):
        self.d, self.prev, self.extra, self.last_extra = {}, {}, {}, 0
        self.tot_rx.clear(); self.tot_tx.clear(); self.stamps.clear(); self.if_hist.clear()

    # -- real router ------------------------------------------------------------------
    def start(self, api):
        self.stop()
        self.reset()
        self.evt = evt = threading.Event()
        self.clone = clone = api.clone()
        threading.Thread(target=self._loop, args=(clone, evt), daemon=True).start()

    def stop(self):
        self.evt.set()
        if self.clone:
            self.clone.close()
            self.clone = None

    def _loop(self, clone, evt):
        try:
            clone.connect()
        except Exception as e:
            self.app.post(lambda e=e: self.app.alerts.add("error", "telemetry", f"Live monitor could not connect: {e}"))
            return
        while not evt.is_set():
            if not self.app.auto:
                evt.wait(1.0)
                continue
            try:
                snap = self._collect(clone)
            except Exception as e:
                if not evt.is_set():
                    self.app.post(lambda e=e: self.app.alerts.add("error", "telemetry", f"Live monitor stopped: {e}"))
                return
            self.app.post(lambda s=snap: self._publish(s, evt))
            evt.wait(self.interval)

    def _collect(self, api):
        now = time.time()
        res = (api.command("/system/resource/print") or [{}])[0]
        ifs = api.command("/interface/print", "=.proplist=name,type,running,disabled,rx-byte,tx-byte", "?dynamic=false")
        out = []
        for r in ifs:
            n = r.get("name", "")
            rx, tx = _i(r.get("rx-byte")), _i(r.get("tx-byte"))
            rrx = rtx = 0.0
            if n in self.prev:
                t0, rx0, tx0 = self.prev[n]
                dt = max(now - t0, 0.001)
                rrx, rtx = max(rx - rx0, 0) * 8 / dt, max(tx - tx0, 0) * 8 / dt
            self.prev[n] = (now, rx, tx)
            out.append(dict(name=n, type=r.get("type", ""), running=r.get("running") == "true",
                            disabled=r.get("disabled") == "true", rx=rrx, tx=rtx, rxb=rx, txb=tx))
        if now - self.last_extra > 15 or not self.extra:
            self.last_extra = now
            self.extra = self._collect_extra(api)
        d = dict(res=res, ifaces=out, ts=now, demo=False, first=not self.tot_rx and not self.d)
        d.update(self.extra)
        return d

    def _collect_extra(self, api):
        ex = {}

        def safe(path, *a):
            try:
                return api.command(path, *a)
            except Exception:
                return None
        ex["identity"] = ((safe("/system/identity/print") or [{}])[0]).get("name", "")
        ex["board"] = ((safe("/system/routerboard/print") or [{}])[0]).get("model", "")
        act = safe("/ppp/active/print", "=.proplist=name")
        sec = safe("/ppp/secret/print", "=.proplist=name")
        ex["ppp_active"] = len(act) if act is not None else 0
        ex["ppp_total"] = len(sec) if sec is not None else (len(act) if act else 0)
        bgp = safe("/routing/bgp/session/print", "=.proplist=name,established")
        if bgp is None:
            bgp = safe("/routing/bgp/peer/print", "=.proplist=name,state")
            est = sum(1 for r in bgp or [] if r.get("state") == "established")
        else:
            est = sum(1 for r in bgp if r.get("established") == "true")
        ex["bgp"] = (est, max(len(bgp or []) - est, 0), len(bgp or []))
        logs = safe("/log/print", "=.proplist=time,topics,message") or []
        ex["logs"] = [(r.get("time", ""), r.get("topics", ""), r.get("message", "")) for r in logs[-8:]][::-1]
        nb = safe("/ip/neighbor/print") or []
        ex["neighbors"] = [dict(identity=r.get("identity", ""), address=r.get("address", ""), mac=r.get("mac-address", ""),
                                platform=r.get("platform", ""), interface=r.get("interface", ""),
                                version=r.get("version", "")) for r in nb]
        return ex

    # -- publish (UI thread) ----------------------------------------------------------
    def _publish(self, snap, evt):
        if evt.is_set():
            return
        res = snap["res"]
        total, free = _i(res.get("total-memory")), _i(res.get("free-memory"))
        hdd_t, hdd_f = _i(res.get("total-hdd-space")), _i(res.get("free-hdd-space"))
        snap["cpu"] = _i(res.get("cpu-load"))
        snap["mem_pct"] = (total - free) * 100 / total if total else 0
        snap["disk_pct"] = (hdd_t - hdd_f) * 100 / hdd_t if hdd_t else 0
        snap["uptime"] = res.get("uptime", "")
        snap["version"] = res.get("version", "")
        phys = [i for i in snap["ifaces"] if i["type"] in PHYSICAL or i["type"].startswith(("ether", "sfp", "wlan"))]
        snap["rx"], snap["tx"] = sum(i["rx"] for i in phys), sum(i["tx"] for i in phys)
        first = snap.pop("first", False)
        self.d = snap
        if first:                      # first sample has no previous counters → rates would be 0
            for fn in list(self.subs):
                fn(snap)
            return
        stamp = time.strftime("%H:%M", time.localtime(snap["ts"]))
        self.tot_rx.append(snap["rx"]); self.tot_tx.append(snap["tx"]); self.stamps.append(stamp)
        for i in snap["ifaces"]:
            h = self.if_hist.setdefault(i["name"], deque(maxlen=self.HIST))
            h.append((i["rx"], i["tx"]))
        self._alerts(snap)
        for fn in list(self.subs):
            try:
                fn(snap)
            except Exception:
                import traceback
                traceback.print_exc()

    def _alerts(self, d):
        a, ident = self.app.alerts, d.get("identity") or "router"
        if d["cpu"] >= 85:
            a.add("critical", "cpu", f"{ident}: high CPU load {d['cpu']}%")
        if d["mem_pct"] >= 90:
            a.add("warning", "mem", f"{ident}: memory usage {d['mem_pct']:.0f}%")
        for i in d["ifaces"]:
            was = self.prev.get("up:" + i["name"])
            if i["type"] in PHYSICAL and not i["disabled"] and was is True and not i["running"]:
                a.add("warning", "if:" + i["name"], f"{ident}: interface {i['name']} link down", 60)
            self.prev["up:" + i["name"]] = i["running"]
        bgp = d.get("bgp", (0, 0, 0))
        if bgp[1]:
            a.add("warning", "bgp", f"{ident}: {bgp[1]} BGP peer(s) not established", 900)
        for t, topics, msg in d.get("logs", [])[:3]:
            if "critical" in topics or "error" in topics:
                a.add("error", "log:" + msg[:40], f"{ident}: [{topics}] {msg}", 600)


# ---------------------------------------------------------------------------------------
class DemoSource:
    """Random-walk sample data so the dashboard can be previewed without a router (clearly labelled DEMO)."""

    def __init__(self):
        self.t, self.rx, self.tx = 0, 1.8e9, 1.4e9
        self.rx_h, self.tx_h, self.st = deque(maxlen=120), deque(maxlen=120), deque(maxlen=120)
        for _ in range(120):
            self.step()

    def step(self):
        self.t += 1
        self.rx = min(max(self.rx + random.uniform(-2.2e8, 2.2e8) + (1.8e9 - self.rx) * .08, 6e8), 3.4e9)
        self.tx = min(max(self.tx + random.uniform(-1.8e8, 1.8e8) + (1.4e9 - self.tx) * .08, 5e8), 2.8e9)
        self.rx_h.append(self.rx); self.tx_h.append(self.tx)
        self.st.append(time.strftime("%H:%M", time.localtime(time.time() - (120 - self.t % 120) * 30)))
        names = [("ether1-WAN1", 1.0, "ether"), ("ether2-WAN2", .7, "ether"), ("sfp-sfpplus1", .55, "ether"),
                 ("bridge-LAN", .4, "bridge"), ("pppoe-out1", .35, "pppoe-out"), ("ether5-OLT", .2, "ether")]
        ifs = [dict(name=n, type=t, running=True, disabled=False, rx=self.rx * f * random.uniform(.9, 1.1) / 2,
                    tx=self.tx * f * random.uniform(.9, 1.1) / 2, rxb=0, txb=0) for n, f, t in names]
        return dict(demo=True, ts=time.time(), cpu=int(40 + 8 * math.sin(self.t / 6) + random.randint(-2, 2)),
                    mem_pct=68 + random.random() * 2, disk_pct=32, uptime="12d14h32m", version="7.15.2 (stable)",
                    identity="Router-Main", board="CCR2116-12G-4S+", ifaces=ifs, rx=self.rx, tx=self.tx,
                    ppp_active=3126 + random.randint(-4, 4), ppp_total=3542, bgp=(10, 2, 12),
                    logs=[("13:00:15", "bgp,info", "BGP peer 203.0.113.1 established"),
                          ("12:59:42", "interface,info", "Interface ether1 link up"),
                          ("12:58:33", "pppoe,info", "PPPoE client connected (user123)"),
                          ("12:57:21", "system,error,critical", "High CPU usage on Switch-02"),
                          ("12:55:10", "system,info", "Configuration backup completed")],
                    neighbors=[dict(identity="CCR1036", address="192.168.1.2", platform="MikroTik", interface="sfp1"),
                               dict(identity="CCR2116", address="192.168.1.3", platform="MikroTik", interface="sfp2"),
                               dict(identity="Switch-01", address="192.168.1.10", platform="MikroTik", interface="ether3"),
                               dict(identity="Switch-02", address="192.168.1.11", platform="MikroTik", interface="ether4"),
                               dict(identity="OLT-01", address="192.168.1.100", platform="Huawei", interface="ether5")])

    DEVICES = [("Router-Main", "Router", "192.168.1.1", "online", "12d 14h", 45, 52, "1.2G / 980M", "Network Core"),
               ("Core-CCR1036", "Router", "192.168.1.2", "online", "30d 5h", 62, 71, "850M / 420M", "Data Center A"),
               ("Core-CCR2116", "Router", "192.168.1.3", "online", "25d 10h", 38, 48, "620M / 310M", "Data Center B"),
               ("Switch-01", "Switch", "192.168.1.10", "online", "18d 2h", 22, 36, "420M / 400M", "Floor 1"),
               ("Switch-02", "Switch", "192.168.1.11", "warning", "3d 6h", 88, 92, "1.1G / 980M", "Floor 2"),
               ("Firewall-01", "Firewall", "192.168.1.254", "online", "20d 8h", 55, 62, "480M / 620M", "Security Zone"),
               ("AP-Guest", "Access Point", "192.168.2.100", "offline", "0d 0h", 0, 0, "0 / 0", "Lobby"),
               ("Server-01", "Server", "192.168.1.20", "online", "45d 12h", 32, 45, "120M / 80M", "Data Center A"),
               ("OLT-01", "OLT", "192.168.1.100", "online", "28d 14h", 42, 38, "950M / 850M", "GPON POP")]


# ---------------------------------------------------------------------------------------
class Fleet:
    """TCP reachability probe of saved router profiles (no passwords needed)."""

    def __init__(self, app):
        self.app, self.status, self.evt = app, {}, threading.Event()
        self.pool = ThreadPoolExecutor(max_workers=16)

    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def probe_now(self):
        self.pool.submit(self._round)

    def _loop(self):
        while True:
            self._round()
            time.sleep(20)

    def _round(self):
        profs = list(self.app.profiles)
        futs = {p["name"]: self.pool.submit(self._probe, p) for p in profs if p.get("proto") != "snmp"}
        res = {n: f.result() for n, f in futs.items()}
        for p in profs:                      # SNMP is UDP: reuse the result of the last sync
            if p.get("proto") == "snmp":
                ok = getattr(self.app, "sync", None) and self.app.sync.status.get(p["name"], {}).get("state") == "ok"
                res[p["name"]] = dict(state="online" if ok else "offline", ms=None)
        self.status = res
        self.app.post(self.app.on_fleet)

    @staticmethod
    def _probe(p):
        t = time.time()
        try:
            with socket.create_connection((p["host"], int(p["port"])), timeout=1.5):
                return dict(state="online", ms=int((time.time() - t) * 1000))
        except Exception:
            return dict(state="offline", ms=None)

    @staticmethod
    def sweep(cidr, ports=(8728, 8291), timeout=0.6, progress=None):
        """Find MikroTik-looking hosts in a /24-ish range by probing API (8728) / WinBox (8291) ports."""
        import ipaddress
        net = ipaddress.ip_network(cidr, strict=False)
        hosts = list(net.hosts())[:1024]
        found = []

        def one(ip):
            for port in ports:
                try:
                    with socket.create_connection((str(ip), port), timeout=timeout):
                        return dict(host=str(ip), port=8728 if port == 8291 else port, via=port)
                except Exception:
                    continue
            return None
        with ThreadPoolExecutor(max_workers=96) as ex:
            for i, r in enumerate(ex.map(one, hosts)):
                if r:
                    found.append(r)
                if progress and i % 16 == 0:
                    progress(i + 1, len(hosts))
        return found
