"""Tiny fake RouterOS API server for offline testing:  python tools/mock_router.py  (127.0.0.1:8728, admin / any password)."""
import os, socket, sys, threading, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from routeros_api import recv_sentence, send_sentence

DB = {
    "/interface": [{".id": "*1", "name": "ether1", "type": "ether", "running": "true", "disabled": "false", "rx-byte": "123456789", "tx-byte": "987654321", "mtu": "1500", "comment": "WAN"},
                   {".id": "*2", "name": "bridge1", "type": "bridge", "running": "true", "disabled": "false", "rx-byte": "5000", "tx-byte": "7000"}],
    "/ip/address": [{".id": "*1", "address": "192.168.88.1/24", "network": "192.168.88.0", "interface": "bridge1", "disabled": "false", "dynamic": "false"}],
    "/ip/firewall/filter": [{".id": "*A", "chain": "input", "action": "accept", "disabled": "false"}, {".id": "*B", "chain": "forward", "action": "drop", "disabled": "true"}],
    "/ppp/active": [{".id": f"*P{i}", "name": f"user{i}", "service": "pppoe", "address": f"10.0.0.{i}", "uptime": "1h"} for i in range(1, 38)],
    "/ppp/secret": [{".id": f"*S{i}", "name": f"user{i}", "service": "pppoe"} for i in range(1, 51)],
    "/log": [{".id": "*L1", "time": "12:01:02", "topics": "system,info", "message": "mock started"},
             {".id": "*L2", "time": "12:02:10", "topics": "interface,info", "message": "ether1 link up"},
             {".id": "*L3", "time": "12:03:44", "topics": "system,error,critical", "message": "login failure for user x"}],
    "/ip/neighbor": [{".id": "*N1", "identity": "Switch-A", "address": "192.168.88.2", "mac-address": "AA:BB:CC:00:00:01", "platform": "MikroTik", "interface": "ether2", "version": "7.15"},
                     {".id": "*N2", "identity": "CCR2004", "address": "192.168.88.3", "mac-address": "AA:BB:CC:00:00:02", "platform": "MikroTik", "interface": "ether3", "version": "7.14"}],
    "/routing/bgp/session": [{".id": "*B1", "name": "peer1", "established": "true"}, {".id": "*B2", "name": "peer2", "established": "false"}],
    "/ip/dns": [{"servers": "8.8.8.8", "allow-remote-requests": "no", "cache-size": "2048KiB"}],
}
SYS = {"/system/resource": [{"version": "7.15 (stable)", "uptime": "1d02:03:04", "cpu-load": "7", "free-memory": "200000000", "total-memory": "256000000", "total-hdd-space": "16000000", "free-hdd-space": "9000000", "architecture-name": "arm", "platform": "MikroTik", "board-name": "hAP ac2"}],
       "/system/identity": [{"name": "MockRouter"}], "/system/routerboard": [{"model": "RBD52G"}]}

def handle(c):
    try:
        while True:
            w = recv_sentence(c)
            if not w: continue
            cmd, attrs = w[0], [x for x in w[1:]]
            if cmd == "/login":
                send_sentence(c, ["!done"]); continue
            base, _, verb = cmd.rpartition("/")
            if cmd.startswith("/ping"):
                for i in range(3):
                    send_sentence(c, ["!re", f"=seq={i}", "=host=8.8.8.8", "=ttl=57", f"=time={10+i}ms", "=sent=%d" % (i+1), "=received=%d" % (i+1), "=packet-loss=0"]); time.sleep(0.1)
                send_sentence(c, ["!done"]); continue
            if cmd == "/interface/monitor-traffic":
                for i in range(50):
                    send_sentence(c, ["!re", f"=rx-bits-per-second={i*100000}", f"=tx-bits-per-second={i*50000}"]); time.sleep(0.05)
                send_sentence(c, ["!done"]); continue
            if cmd == "/system/reboot":
                send_sentence(c, ["!fatal", "session closed"]); return
            if base == "/interface":
                t = int(time.time()) % 100000
                for r in DB["/interface"]:
                    r["rx-byte"] = str(int(r["rx-byte"]) + 400000 + (t % 7) * 60000)
                    r["tx-byte"] = str(int(r["tx-byte"]) + 250000 + (t % 5) * 40000)
            rows = SYS.get(base) if base in SYS else DB.get(base)
            if verb == "print":
                if rows is None:
                    send_sentence(c, ["!trap", "=message=no such command or directory (" + base.strip("/") + ")"]); send_sentence(c, ["!done"]); continue
                for r in rows: send_sentence(c, ["!re"] + [f"={k}={v}" for k, v in r.items()])
                send_sentence(c, ["!done"])
            elif verb == "add":
                a = dict(x[1:].split("=", 1) for x in attrs if x.startswith("="))
                a[".id"] = "*N%d" % len(DB.setdefault(base, [])); a.setdefault("disabled", "false"); DB[base].append(a)
                send_sentence(c, ["!done", "=ret=" + a[".id"]])
            elif verb in ("set", "remove", "enable", "disable"):
                a = dict(x[1:].split("=", 1) for x in attrs if x.startswith("="))
                ids = a.pop(".id", a.pop("numbers", "")).split(",")
                for r in DB.get(base, []):
                    if r[".id"] in ids:
                        if verb == "set": r.update(a)
                        elif verb == "enable": r["disabled"] = "false"
                        elif verb == "disable": r["disabled"] = "true"
                if verb == "remove": DB[base] = [r for r in DB.get(base, []) if r[".id"] not in ids]
                send_sentence(c, ["!done"])
            else:
                send_sentence(c, ["!trap", "=message=bad command"]); send_sentence(c, ["!done"])
    except Exception:
        pass
    finally:
        c.close()

def serve(host="127.0.0.1", port=8728):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind((host, port)); s.listen(5)
    print(f"Mock RouterOS API on {host}:{port}")
    while True:
        c, _ = s.accept(); threading.Thread(target=handle, args=(c,), daemon=True).start()

if __name__ == "__main__":
    serve()
