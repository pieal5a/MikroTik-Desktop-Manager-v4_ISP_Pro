"""Fake Telnet (23→2323) and SNMP (161→1161) RouterOS agents for offline testing:
    python tools/mock_devices.py          # telnet 127.0.0.1:2323 (admin / any password), SNMP 127.0.0.1:1161 community 'public'
Together with tools/mock_router.py (API 8728) you can try every protocol without a real router."""
import os, re, socket, sys, threading
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import snmp as S

# ------------------------------------------------------------------ Telnet
SECRETS = [dict(name=f"user{i}", service="pppoe", password=f"pw{i}", profile="10M" if i % 2 else "20M",
                comment=f"Client {i}", disabled="true" if i == 4 else "false") for i in range(1, 7)]
ACTIVE = [dict(name=f"user{i}", address=f"10.0.0.{i}", uptime="2h3m", **{"caller-id": f"AA:00:00:00:00:0{i}"}) for i in (1, 2, 3)]


def line(r, flags="", idx=0):
    def q(v):
        return f'"{v}"' if (" " in v or v == "") else v
    return f" {idx} {flags:<2} " + " ".join(f"{k}={q(str(v))}" for k, v in r.items() if k != "disabled")


def kv(cmd):
    return {m.group(1): m.group(2).strip('"') for m in re.finditer(r'([\w-]+)=("[^"]*"|\S+)', cmd)}


def run_cmd(cmd):
    cmd = cmd.strip()
    if cmd.startswith("/system resource print"):
        return 'uptime=1d02h03m version="7.15 (stable)" cpu-load=7 free-memory=200000000 total-memory=256000000 total-hdd-space=16000000 free-hdd-space=9000000 board-name="hAP ac2"'
    if cmd.startswith("/system identity print"):
        return "name=MockTelnet"
    if cmd.startswith("/interface print"):
        return "\r\n".join([line(dict(name="ether1", type="ether", **{"rx-byte": 123456, "tx-byte": 654321}), "R", 0),
                            line(dict(name="ether2", type="ether", **{"rx-byte": 99, "tx-byte": 11}), "", 1)])
    if cmd.startswith("/ppp active print"):
        return "\r\n".join(line(a, "R", i) for i, a in enumerate(ACTIVE))
    if cmd.startswith("/ppp secret print"):
        return "\r\n".join(line(s, "X" if s["disabled"] == "true" else "", i) for i, s in enumerate(SECRETS))
    if cmd.startswith("/ppp profile print"):
        return "\r\n".join(line(dict(name=n, **{"rate-limit": r}), "", i) for i, (n, r) in enumerate((("10M", "10M/10M"), ("20M", "20M/20M"))))
    m = re.match(r"/ppp secret (add|set|remove|enable|disable) (.*)", cmd)
    if m:
        verb, rest = m.groups()
        a = kv(rest)
        target = re.search(r'\[find name=("[^"]*"|\S+?)\]', rest)
        name = (target.group(1).strip('"') if target else a.get("name"))
        cur = next((s for s in SECRETS if s["name"] == name), None)
        if verb == "add":
            SECRETS.append(dict(name=name, service="pppoe", password=a.get("password", ""), profile=a.get("profile", "default"),
                                comment=a.get("comment", ""), disabled="false"))
        elif cur is None:
            return "failure: no such item"
        elif verb == "set":
            cur.update({k: v for k, v in a.items() if k != "name"} | ({"name": a["name"]} if False else {}))
        elif verb == "remove":
            SECRETS.remove(cur)
        else:
            cur["disabled"] = "true" if verb == "disable" else "false"
        return ""
    if cmd.startswith("/ppp active remove"):
        return ""
    return "bad command name"


def telnet_client(c):
    try:
        c.sendall(bytes([255, 253, 24]) + b"MikroTik v7.15 (stable)\r\nLogin: ")
        buf = b""

        def readline():
            nonlocal buf
            while b"\n" not in buf and b"\r" not in buf:
                d = c.recv(1024)
                if not d:
                    raise EOFError
                buf += bytes(b for b in d if b < 128 and not (b == 255))
            parts = re.split(rb"\r\n|\r|\n", buf, 1)
            buf = parts[1] if len(parts) > 1 else b""
            return parts[0].decode(errors="ignore")
        user = readline()
        c.sendall(b"Password: ")
        readline()
        c.sendall(b"\r\n\r\n  MikroTik RouterOS 7.15 (c) 1999-2024       http://www.mikrotik.com/\r\n\r\n[admin@MockTelnet] > ")
        while True:
            cmd = readline()
            if cmd == "/quit":
                break
            out = run_cmd(cmd)
            c.sendall((cmd + "\r\n" + (out + "\r\n" if out else "") + "[admin@MockTelnet] > ").encode())
    except Exception:
        pass
    finally:
        c.close()


def serve_telnet(port=2323):
    s = socket.socket(); s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1); s.bind(("127.0.0.1", port)); s.listen(8)
    def loop():
        while True:
            c, _ = s.accept()
            threading.Thread(target=telnet_client, args=(c,), daemon=True).start()
    threading.Thread(target=loop, daemon=True).start()
    return s


# ------------------------------------------------------------------ SNMP
def build_mib():
    m = {S.SYS_DESCR: (S.OCT, "RouterOS hAP ac2"), S.SYS_UPTIME: (0x43, 8640000 + 360000), S.SYS_NAME: (S.OCT, "MockSNMP"),
         S.MT_TEMP: (S.INT, 420), S.MT_VOLT: (S.INT, 241), S.MT_BOARD: (S.OCT, "hAP ac2"), S.MT_FW: (S.OCT, "7.15")}
    for i, v in ((1, 12), (2, 8)):
        m[f"{S.HR_CPU}.{i}"] = (S.INT, v)
    for i, (d, sz, us) in enumerate((("main memory", 262144, 131072), ("flash disk", 16384, 4096)), 1):
        m[f"{S.HR_ST_DESCR}.{i}"] = (S.OCT, d); m[f"{S.HR_ST_UNITS}.{i}"] = (S.INT, 1024)
        m[f"{S.HR_ST_SIZE}.{i}"] = (S.INT, sz); m[f"{S.HR_ST_USED}.{i}"] = (S.INT, us)
    for i, n in enumerate(("ether1", "ether2", "<pppoe-user1>", "<pppoe-user2>"), 1):
        m[f"{S.IFX_NAME}.{i}"] = (S.OCT, n); m[f"{S.IF_OPER}.{i}"] = (S.INT, 1); m[f"{S.IF_ADMIN}.{i}"] = (S.INT, 1)
        m[f"{S.IFX_HC_IN}.{i}"] = (0x46, 1000000 * i); m[f"{S.IFX_HC_OUT}.{i}"] = (0x46, 500000 * i)
    return m


def enc(tag, v):
    if tag in (S.OCT,):
        return S._tlv(tag, v.encode())
    if tag == S.INT:
        return S._int(v)
    return S._tlv(tag, v.to_bytes(max(1, (v.bit_length() + 7) // 8), "big"))


def serve_snmp(port=1161, community="public"):
    mib = build_mib()
    keys = sorted(mib, key=S._oid_key)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); sock.bind(("127.0.0.1", port))

    def nxt(o):
        k = S._oid_key(o)
        return next((x for x in keys if S._oid_key(x) > k), None)

    def loop():
        while True:
            data, addr = sock.recvfrom(65535)
            try:
                _t, body, _ = S._read(data, 0)
                _t, ver, i = S._read(body, 0)
                _t, comm, i = S._read(body, i)
                if comm.decode() != community:
                    continue
                tag, pdu, _ = S._read(body, i)
                _t, rid, j = S._read(pdu, 0)
                _t, a, j = S._read(pdu, j)
                _t, b, j = S._read(pdu, j)
                _t, vbl, _ = S._read(pdu, j)
                oids, k = [], 0
                while k < len(vbl):
                    _t, vb, k = S._read(vbl, k)
                    _t, o, _x = S._read(vb, 0)
                    oids.append(S._dec_oid(o))
                out = []
                if tag == S.GET:
                    for o in oids:
                        out.append((o, mib.get(o)))
                elif tag == S.GETNEXT:
                    for o in oids:
                        n = nxt(o); out.append((n or o, mib.get(n) if n else None))
                else:   # GETBULK
                    reps, cur = int.from_bytes(b, "big"), oids[0]
                    for _ in range(reps):
                        n = nxt(cur)
                        if not n:
                            out.append((cur, None)); break
                        out.append((n, mib[n])); cur = n
                vbs = b"".join(S._tlv(S.SEQ, S._oid(o) + (enc(*v) if v else S._tlv(0x82, b""))) for o, v in out)
                resp = S._tlv(S.SEQ, S._int(int.from_bytes(ver, "big")) + S._tlv(S.OCT, comm) +
                              S._tlv(S.RESPONSE, S._tlv(S.INT, rid) + S._int(0) + S._int(0) + S._tlv(S.SEQ, vbs)))
                sock.sendto(resp, addr)
            except Exception as e:
                print("snmp mock error", e)
    threading.Thread(target=loop, daemon=True).start()
    return sock


if __name__ == "__main__":
    serve_telnet(); serve_snmp()
    print("Mock Telnet on 127.0.0.1:2323 (admin / any), mock SNMP on 127.0.0.1:1161 (community public). Ctrl+C to stop.")
    threading.Event().wait()
