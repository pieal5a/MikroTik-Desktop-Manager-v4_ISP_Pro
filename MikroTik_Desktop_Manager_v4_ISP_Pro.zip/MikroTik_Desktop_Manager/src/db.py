"""SQLite storage (standard library) for ISP clients, packages, bills, payments and the audit log.
Client documents (photo / NID) are copied into  <data dir>/files/<client id>/ ."""
import csv
import shutil
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS packages(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, speed TEXT DEFAULT '',
  price REAL DEFAULT 0, mt_profile TEXT DEFAULT '', note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS clients(id INTEGER PRIMARY KEY, router TEXT DEFAULT '', pppoe_id TEXT NOT NULL,
  pppoe_pass TEXT DEFAULT '', package TEXT DEFAULT '', bill REAL DEFAULT 0, name TEXT DEFAULT '',
  phone1 TEXT DEFAULT '', phone2 TEXT DEFAULT '', nid TEXT DEFAULT '', address TEXT DEFAULT '', zone TEXT DEFAULT '',
  join_date TEXT DEFAULT '', status TEXT DEFAULT 'active', note TEXT DEFAULT '',
  photo TEXT DEFAULT '', nid_front TEXT DEFAULT '', nid_back TEXT DEFAULT '', other_file TEXT DEFAULT '',
  on_router INTEGER DEFAULT 0, online INTEGER DEFAULT 0, ip TEXT DEFAULT '', uptime TEXT DEFAULT '',
  last_seen TEXT DEFAULT '', router_note TEXT DEFAULT '', created TEXT, updated TEXT,
  UNIQUE(router, pppoe_id));
CREATE TABLE IF NOT EXISTS bills(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, month TEXT NOT NULL,
  amount REAL DEFAULT 0, discount REAL DEFAULT 0, paid REAL DEFAULT 0, UNIQUE(client_id, month));
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, client_id INTEGER NOT NULL, month TEXT NOT NULL,
  amount REAL NOT NULL, method TEXT DEFAULT 'Cash', trx TEXT DEFAULT '', received_by TEXT DEFAULT '',
  paid_at TEXT, note TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts TEXT, action TEXT, detail TEXT);
CREATE INDEX IF NOT EXISTS ix_bills_month ON bills(month);
CREATE INDEX IF NOT EXISTS ix_pay_month ON payments(month);
"""
CLIENT_FIELDS = ("router", "pppoe_id", "pppoe_pass", "package", "bill", "name", "phone1", "phone2", "nid", "address",
                 "zone", "join_date", "status", "note", "photo", "nid_front", "nid_back", "other_file")
DUE_SQL = "COALESCE((SELECT SUM(MAX(b.amount-b.discount-b.paid,0)) FROM bills b WHERE b.client_id=c.id AND b.month<=?),0)"
MONTH_SQL = "(SELECT b.amount-b.discount-b.paid FROM bills b WHERE b.client_id=c.id AND b.month=?)"


def now():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def month_now():
    return time.strftime("%Y-%m")


def add_months(m, n):
    y, mo = int(m[:4]), int(m[5:7]) - 1 + n
    return f"{y + mo // 12:04d}-{mo % 12 + 1:02d}"


MONTH_NAMES = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
               "November", "December"]


def month_label(m):
    try:
        return f"{MONTH_NAMES[int(m[5:7]) - 1]} {m[:4]}"
    except Exception:
        return m


class DB:
    def __init__(self, folder):
        self.dir = Path(folder)
        self.files = self.dir / "files"
        self.files.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "isp.db"
        self.lock = threading.RLock()
        self._open()

    def _open(self):
        self.cx = sqlite3.connect(self.path, check_same_thread=False)
        self.cx.row_factory = sqlite3.Row
        self.cx.executescript(SCHEMA)
        self.cx.commit()

    def q(self, sql, args=()):
        with self.lock:
            return [dict(r) for r in self.cx.execute(sql, args).fetchall()]

    def one(self, sql, args=()):
        r = self.q(sql, args)
        return r[0] if r else None

    def x(self, sql, args=()):
        with self.lock:
            cur = self.cx.execute(sql, args)
            self.cx.commit()
            return cur.lastrowid

    # ---- audit -------------------------------------------------------------------------------------
    def log(self, action, detail=""):
        self.x("INSERT INTO audit(ts,action,detail) VALUES(?,?,?)", (now(), action, detail))

    def audit(self, limit=500):
        return self.q("SELECT * FROM audit ORDER BY id DESC LIMIT ?", (limit,))

    # ---- packages ----------------------------------------------------------------------------------
    def packages(self):
        return self.q("SELECT * FROM packages ORDER BY price, name")

    def save_package(self, d):
        vals = (d["name"], d.get("speed", ""), float(d.get("price") or 0), d.get("mt_profile", ""), d.get("note", ""))
        if d.get("id"):
            self.x("UPDATE packages SET name=?,speed=?,price=?,mt_profile=?,note=? WHERE id=?", vals + (d["id"],))
            return d["id"]
        self.x("INSERT INTO packages(name,speed,price,mt_profile,note) VALUES(?,?,?,?,?) ON CONFLICT(name) DO UPDATE "
               "SET speed=excluded.speed, mt_profile=excluded.mt_profile", vals)
        return None

    def delete_package(self, pid):
        self.x("DELETE FROM packages WHERE id=?", (pid,))

    # ---- clients -----------------------------------------------------------------------------------
    def clients(self, search="", router="", package="", status="", month=None, zone=""):
        month = month or month_now()
        sql = f"SELECT c.*, {DUE_SQL} AS total_due, {MONTH_SQL} AS month_due FROM clients c WHERE 1=1"
        args = [month, month]
        if search:
            like = f"%{search}%"
            sql += " AND (c.pppoe_id LIKE ? OR c.name LIKE ? OR c.phone1 LIKE ? OR c.phone2 LIKE ? OR c.nid LIKE ? " \
                   "OR c.address LIKE ? OR c.ip LIKE ?)"
            args += [like] * 7
        if router:
            sql += " AND c.router=?"; args.append(router)
        if package:
            sql += " AND c.package=?"; args.append(package)
        if zone:
            sql += " AND c.zone=?"; args.append(zone)
        if status in ("active", "suspended", "disabled"):
            sql += " AND c.status=?"; args.append(status)
        elif status == "online":
            sql += " AND c.online=1"
        elif status == "offline":
            sql += " AND c.online=0 AND c.status='active'"
        elif status == "due":
            sql += f" AND {DUE_SQL}>0"; args.append(month)
        elif status == "paid":
            sql += f" AND {DUE_SQL}<=0 AND c.status!='disabled'"; args.append(month)
        elif status == "not-on-router":
            sql += " AND c.on_router=0"
        sql += " ORDER BY c.router, c.pppoe_id"
        return self.q(sql, args)

    def client(self, cid):
        return self.one("SELECT * FROM clients WHERE id=?", (cid,))

    def find_client(self, router, pppoe):
        return self.one("SELECT * FROM clients WHERE router=? AND pppoe_id=?", (router, pppoe))

    def zones(self):
        return [r["zone"] for r in self.q("SELECT DISTINCT zone FROM clients WHERE zone!='' ORDER BY zone")]

    def save_client(self, d):
        d = {k: d.get(k, "") for k in CLIENT_FIELDS} | {"id": d.get("id")}
        d["bill"] = float(d["bill"] or 0)
        d["status"] = d["status"] or "active"
        ts = now()
        if d["id"]:
            sets = ",".join(f"{k}=?" for k in CLIENT_FIELDS)
            self.x(f"UPDATE clients SET {sets}, updated=? WHERE id=?", [d[k] for k in CLIENT_FIELDS] + [ts, d["id"]])
            self.log("client-edit", f"{d['pppoe_id']} ({d['router']})")
            return d["id"]
        cols = ",".join(CLIENT_FIELDS)
        cid = self.x(f"INSERT INTO clients({cols},created,updated) VALUES({','.join('?' * len(CLIENT_FIELDS))},?,?)",
                     [d[k] for k in CLIENT_FIELDS] + [ts, ts])
        self.log("client-add", f"{d['pppoe_id']} ({d['router']})")
        return cid

    def delete_client(self, cid, keep_files=False):
        c = self.client(cid)
        if not c:
            return
        for t in ("bills", "payments"):
            self.x(f"DELETE FROM {t} WHERE client_id=?", (cid,))
        self.x("DELETE FROM clients WHERE id=?", (cid,))
        if not keep_files:
            shutil.rmtree(self.files / str(cid), ignore_errors=True)
        self.log("client-delete", f"{c['pppoe_id']} ({c['router']})")

    def update_files(self, cid, files):
        for k, v in files.items():
            if k in ("photo", "nid_front", "nid_back", "other_file"):
                self.x(f"UPDATE clients SET {k}=? WHERE id=?", (v, cid))

    def set_status(self, cid, status):
        self.x("UPDATE clients SET status=?, updated=? WHERE id=?", (status, now(), cid))

    def attach(self, cid, kind, src):
        """Copy a file into the client's folder; returns the stored relative path."""
        src = Path(src)
        folder = self.files / str(cid)
        folder.mkdir(parents=True, exist_ok=True)
        for old in folder.glob(kind + ".*"):
            if old != src:
                old.unlink(missing_ok=True)
        dest = folder / f"{kind}{src.suffix.lower() or '.jpg'}"
        if src.resolve() != dest.resolve():
            shutil.copyfile(src, dest)
        return f"{cid}/{dest.name}"

    def file_path(self, rel):
        return self.files / rel if rel else None

    # ---- bills / payments ----------------------------------------------------------------------------
    def ensure_bill(self, cid, month, amount=None):
        b = self.one("SELECT * FROM bills WHERE client_id=? AND month=?", (cid, month))
        if b:
            return b
        if amount is None:
            amount = (self.client(cid) or {}).get("bill", 0)
        self.x("INSERT INTO bills(client_id,month,amount) VALUES(?,?,?)", (cid, month, amount))
        return self.one("SELECT * FROM bills WHERE client_id=? AND month=?", (cid, month))

    def generate_bills(self, month):
        """Create the month's bill for every non-disabled client who has joined by then. Returns #created."""
        n = 0
        for c in self.q("SELECT id,bill,join_date FROM clients WHERE status!='disabled' AND bill>0"):
            if (c["join_date"] or "0000-00")[:7] > month:
                continue
            if not self.one("SELECT 1 FROM bills WHERE client_id=? AND month=?", (c["id"], month)):
                self.x("INSERT INTO bills(client_id,month,amount) VALUES(?,?,?)", (c["id"], month, c["bill"]))
                n += 1
        if n:
            self.log("bills-generated", f"{month}: {n}")
        return n

    def pay(self, cid, month, amount, method="Cash", trx="", by="", note="", discount=0.0):
        amount = float(amount)
        b = self.ensure_bill(cid, month)
        if discount:
            self.x("UPDATE bills SET discount=discount+? WHERE id=?", (float(discount), b["id"]))
        self.x("UPDATE bills SET paid=paid+? WHERE id=?", (amount, b["id"]))
        pid = self.x("INSERT INTO payments(client_id,month,amount,method,trx,received_by,paid_at,note) "
                     "VALUES(?,?,?,?,?,?,?,?)", (cid, month, amount, method, trx, by, now(), note))
        c = self.client(cid) or {}
        self.log("payment", f"{c.get('pppoe_id')} {month} {amount:g} {method}")
        return pid

    def delete_payment(self, pid):
        p = self.one("SELECT * FROM payments WHERE id=?", (pid,))
        if p:
            self.x("UPDATE bills SET paid=MAX(paid-?,0) WHERE client_id=? AND month=?", (p["amount"], p["client_id"], p["month"]))
            self.x("DELETE FROM payments WHERE id=?", (pid,))
            self.log("payment-delete", f"#{pid} {p['month']} {p['amount']:g}")

    def bill_status(self, cid, month):
        b = self.one("SELECT * FROM bills WHERE client_id=? AND month=?", (cid, month))
        if not b:
            c = self.client(cid) or {}
            return dict(amount=c.get("bill", 0), discount=0, paid=0, due=c.get("bill", 0), exists=False)
        return dict(amount=b["amount"], discount=b["discount"], paid=b["paid"],
                    due=max(b["amount"] - b["discount"] - b["paid"], 0), exists=True)

    def due_months(self, cid, upto=None):
        return self.q("SELECT month, amount-discount-paid AS due FROM bills WHERE client_id=? AND month<=? "
                      "AND amount-discount-paid>0 ORDER BY month", (cid, upto or month_now()))

    def payments(self, cid=None, month=None, limit=2000):
        sql = "SELECT p.*, c.pppoe_id, c.name, c.router FROM payments p LEFT JOIN clients c ON c.id=p.client_id WHERE 1=1"
        args = []
        if cid:
            sql += " AND p.client_id=?"; args.append(cid)
        if month:
            sql += " AND p.month=?"; args.append(month)
        return self.q(sql + " ORDER BY p.id DESC LIMIT ?", args + [limit])

    def month_bills(self, month, search="", router=""):
        sql = ("SELECT b.*, c.pppoe_id, c.name, c.phone1, c.router, c.package, c.status, "
               "MAX(b.amount-b.discount-b.paid,0) AS due FROM bills b JOIN clients c ON c.id=b.client_id WHERE b.month=?")
        args = [month]
        if search:
            sql += " AND (c.pppoe_id LIKE ? OR c.name LIKE ? OR c.phone1 LIKE ?)"; args += [f"%{search}%"] * 3
        if router:
            sql += " AND c.router=?"; args.append(router)
        return self.q(sql + " ORDER BY c.router, c.pppoe_id", args)

    def summary(self, month):
        r = self.one("SELECT COALESCE(SUM(amount-discount),0) AS expected, COALESCE(SUM(paid),0) AS paid, "
                     "COALESCE(SUM(MAX(amount-discount-paid,0)),0) AS due, COUNT(*) AS bills FROM bills WHERE month=?", (month,))
        cl = self.one("SELECT COUNT(*) AS total, SUM(status='active') AS active, SUM(online=1) AS online, "
                      "SUM(status='suspended') AS suspended FROM clients")
        collected = self.one("SELECT COALESCE(SUM(amount),0) AS s FROM payments WHERE substr(paid_at,1,7)=?", (month,))["s"]
        total_due = self.one("SELECT COALESCE(SUM(MAX(amount-discount-paid,0)),0) AS s FROM bills WHERE month<=?", (month,))["s"]
        due_clients = self.one("SELECT COUNT(DISTINCT client_id) AS n FROM bills WHERE month<=? AND amount-discount-paid>0", (month,))["n"]
        return dict(r) | dict(cl) | dict(collected=collected, total_due=total_due, due_clients=due_clients)

    def by_method(self, month):
        return self.q("SELECT method, COUNT(*) AS n, SUM(amount) AS total FROM payments WHERE substr(paid_at,1,7)=? "
                      "GROUP BY method ORDER BY total DESC", (month,))

    def by_day(self, month):
        return self.q("SELECT substr(paid_at,1,10) AS day, COUNT(*) AS n, SUM(amount) AS total FROM payments "
                      "WHERE substr(paid_at,1,7)=? GROUP BY day ORDER BY day", (month,))

    def by_router(self, month):
        return self.q("SELECT c.router, COUNT(DISTINCT c.id) AS clients, COALESCE(SUM(b.amount-b.discount),0) AS expected, "
                      "COALESCE(SUM(b.paid),0) AS paid FROM clients c LEFT JOIN bills b ON b.client_id=c.id AND b.month=? "
                      "GROUP BY c.router ORDER BY c.router", (month,))

    # ---- router sync helpers -----------------------------------------------------------------------------
    def apply_router_state(self, router, secrets, active, import_new=True, mark_missing=True):
        """secrets: list of PPP secret dicts (or None when the protocol cannot read them).
        active: {pppoe_name: {address, uptime}}. Returns dict(new=, updated=, missing=, online=)."""
        stat = dict(new=0, updated=0, missing=0, online=0)
        ts = now()
        with self.lock:
            if secrets is not None:
                seen = set()
                for s in secrets:
                    name = s.get("name", "")
                    if not name or s.get("service") not in (None, "", "any", "pppoe"):
                        continue
                    seen.add(name)
                    cur = self.find_client(router, name)
                    st = "suspended" if s.get("disabled") == "true" else "active"
                    if cur:
                        self.x("UPDATE clients SET on_router=1, router_note=?, updated=updated WHERE id=?",
                               (s.get("comment", ""), cur["id"]))
                        # router is the source of truth for password / package only when still empty locally
                        if not cur["pppoe_pass"] and s.get("password"):
                            self.x("UPDATE clients SET pppoe_pass=? WHERE id=?", (s["password"], cur["id"]))
                        if not cur["package"] and s.get("profile"):
                            self.x("UPDATE clients SET package=? WHERE id=?", (s["profile"], cur["id"]))
                        if cur["status"] != "disabled" and cur["status"] != st:
                            self.x("UPDATE clients SET status=? WHERE id=?", (st, cur["id"]))
                            stat["updated"] += 1
                    elif import_new:
                        pk = self.one("SELECT price FROM packages WHERE name=? OR mt_profile=?", (s.get("profile", ""), s.get("profile", "")))
                        self.x("INSERT INTO clients(router,pppoe_id,pppoe_pass,package,bill,name,status,on_router,router_note,"
                               "join_date,created,updated) VALUES(?,?,?,?,?,?,?,1,?,?,?,?)",
                               (router, name, s.get("password", ""), s.get("profile", ""), (pk or {}).get("price", 0),
                                s.get("comment", ""), st, s.get("comment", ""), ts[:10], ts, ts))
                        stat["new"] += 1
                if mark_missing:
                    for c in self.q("SELECT id,pppoe_id FROM clients WHERE router=? AND on_router=1", (router,)):
                        if c["pppoe_id"] not in seen:
                            self.x("UPDATE clients SET on_router=0 WHERE id=?", (c["id"],))
                            stat["missing"] += 1
            self.x("UPDATE clients SET online=0, ip='', uptime='' WHERE router=?", (router,))
            for name, info in active.items():
                self.x("UPDATE clients SET online=1, ip=?, uptime=?, last_seen=? WHERE router=? AND pppoe_id=?",
                       (info.get("address", ""), info.get("uptime", ""), ts, router, name))
                stat["online"] += 1
        return stat

    # ---- backup / export -------------------------------------------------------------------------------------
    def backup(self, dest):
        with self.lock:
            out = sqlite3.connect(dest)
            self.cx.backup(out)
            out.close()

    def restore(self, src):
        with self.lock:
            self.cx.close()
            shutil.copyfile(src, self.path)
            self._open()

    def export_csv(self, path, rows, cols):
        with open(path, "w", newline="", encoding="utf-8-sig") as f:      # utf-8-sig: opens correctly in Excel (Bangla)
            w = csv.writer(f)
            w.writerow(cols)
            for r in rows:
                w.writerow([r.get(c, "") for c in cols])
