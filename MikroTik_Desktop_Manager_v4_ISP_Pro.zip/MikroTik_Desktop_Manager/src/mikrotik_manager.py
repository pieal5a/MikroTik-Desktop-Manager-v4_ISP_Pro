"""
MikroTik Desktop Manager v3 Pro — RouterPilot-style graphical manager with a full WinBox module,
built on the RouterOS API (v6/v7). Standard library only. Passwords are kept in memory only.
"""
import json
import os
import queue
import shlex
import socket
import ssl
import struct
import threading
import time
import traceback
import tkinter as tk
from collections import deque
from pathlib import Path
from tkinter import ttk, messagebox, simpledialog, filedialog

from routeros_api import RouterAPI
from menu_spec import MENU, NAV, WINBOX_TREE
from core import *                      # palette, fmt_bytes, Page, PAGE_KINDS
from ui_kit import GButton, lerp, BarList
from db import DB
from isp_app import ISPMixin
import isp_clients, isp_billing, isp_routers      # noqa: F401  (register ISP pages)
from isp_routers import DeviceDialog
from isp_common import BRAND

APP_NAME = "MikroTik Desktop Manager"
APP_VERSION = "v4.0 ISP Pro"
APP_DIR = Path(os.getenv("APPDATA", str(Path.home()))) / "MikroTikDesktopManager"
PROFILES_FILE = APP_DIR / "routers.json"
SETTINGS_FILE = APP_DIR / "settings.json"


def parse_console(line):
    """'/ip address print =.proplist=name' or '/ip/address/print' -> (path, args)."""
    toks = shlex.split(line)
    path_parts, args = [], []
    for t in toks:
        if args or "=" in t or t.startswith(("?", "=")):
            if not t.startswith(("=", "?", "!")):
                t = "=" + t
            args.append(t)
        else:
            path_parts.append(t.strip("/"))
    return "/" + "/".join(p for p in path_parts if p), args


# ----------------------------------------------------------------------------------
class FormDialog(tk.Toplevel):
    def __init__(self, app, title, fields, values, on_ok, extra=True):
        super().__init__(app)
        self.title(title)
        self.configure(bg=BG)
        self.transient(app)
        self.on_ok = on_ok
        self.entries = {}
        per = 8 if len(fields) > 8 else max(len(fields), 1)
        grid = tk.Frame(self, bg=BG)
        grid.pack(padx=14, pady=12)
        for i, name in enumerate(fields):
            r, c = i % per, (i // per) * 2
            tk.Label(grid, text=name, bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=r, column=c, sticky="w", padx=(8, 6), pady=5)
            e = app.entry(grid, 26)
            e.insert(0, values.get(name, ""))
            e.grid(row=r, column=c + 1, padx=(0, 14), pady=5)
            self.entries[name] = e
        self.extra = None
        if extra:
            tk.Label(self, text="Extra properties (one  key=value  per line)", bg=BG, fg=MUTED,
                     font=(FONT, 9)).pack(anchor="w", padx=22)
            self.extra = tk.Text(self, height=4, width=62, bg=PANEL2, fg=TEXT, insertbackground=CYAN,
                                 relief="flat", font=("Consolas", 9))
            self.extra.pack(padx=22, pady=(4, 8))
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", padx=22, pady=(0, 14))
        app.button(bar, "Apply", self._ok, True).pack(side="right")
        app.button(bar, "Cancel", self.destroy).pack(side="right", padx=8)
        first = next(iter(self.entries.values()), None) or self.extra
        if first:
            first.focus_set()
        self.bind("<Escape>", lambda _e: self.destroy())
        self.after(50, self._grab)

    def _grab(self):
        try:
            self.grab_set()
        except tk.TclError:
            pass

    def _ok(self):
        vals = {k: e.get().strip() for k, e in self.entries.items()}
        extra = {}
        if self.extra:
            for line in self.extra.get("1.0", "end").splitlines():
                if "=" in line:
                    k, v = line.split("=", 1)
                    if k.strip():
                        extra[k.strip()] = v.strip()
        self.destroy()
        self.on_ok(vals, extra)


# ----------------------------------------------------------------------------------
class TablePage(Page):
    FLAGS = (("disabled", "X"), ("invalid", "I"), ("dynamic", "D"), ("running", "R"))
    BYTE_COLS = ("rx-byte", "tx-byte", "bytes", "orig-bytes", "repl-bytes", "bytes-in", "bytes-out")

    def __init__(self, app, spec, auto=False):
        super().__init__(app, spec)
        self.auto_cols = auto
        self.path = spec.get("path", "")
        self.cols = list(spec.get("cols", []))
        self.fields = list(spec.get("fields", []))
        self.rows, self.data, self.after_id, self.sort = {}, [], None, None
        self.search = tk.StringVar()
        self.auto_var = tk.BooleanVar(value=False)
        self.search.trace_add("write", lambda *_: self._fill(self.data))
        self.visible = False
        self.path_var = tk.StringVar(value=self.path or "/ip/address")

        self.header(spec["title"], "" if auto else self.path)
        if auto:
            bar = tk.Frame(self, bg=BG)
            bar.pack(fill="x", pady=(0, 8))
            tk.Label(bar, text="API menu path", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left")
            pe = app.entry(bar, 42)
            pe.configure(textvariable=self.path_var)
            pe.pack(side="left", padx=8)
            pe.bind("<Return>", lambda _e: self._load_path())
            app.button(bar, "Load", self._load_path, True).pack(side="left")
            tk.Label(bar, text="e.g. /ip/address, /system/script, /interface/bridge/port", bg=BG, fg=MUTED,
                     font=(FONT, 8)).pack(side="left", padx=10)

        tb = tk.Frame(self, bg=BG)
        tb.pack(fill="x", pady=(0, 8))
        ro = spec.get("ro", False)
        add = lambda text, fn, primary=False: app.button(tb, text, fn, primary).pack(side="left", padx=(0, 6))
        add("⟳ Refresh", self.refresh, True)
        if not ro:
            if not spec.get("noadd"):
                add("+ Add", self.add)
            if self.fields or auto:
                add("✎ Edit", self.edit)
            if not spec.get("nodel"):
                add("− Remove", self.remove)
            if not spec.get("notoggle"):
                add("✓ Enable", lambda: self.toggle(True))
                add("⦸ Disable", lambda: self.toggle(False))
            add("✉ Comment", self.comment)
            for label, sub in spec.get("extra", []):
                add(label, lambda s=sub: self.run_sub(s))
            if spec.get("order"):
                add("▲", lambda: self.move(-1))
                add("▼", lambda: self.move(1))
        tk.Checkbutton(tb, text="Auto refresh", variable=self.auto_var, bg=BG, fg=MUTED, selectcolor=PANEL2,
                       activebackground=BG, activeforeground=CYAN, command=self._tick_reset).pack(side="right")
        se = app.entry(tb, 22)
        se.configure(textvariable=self.search)
        se.pack(side="right", padx=8)
        tk.Label(tb, text="Find:", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="right")

        wrap = tk.Frame(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        wrap.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(wrap, show="headings", selectmode="extended")
        ys = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        xs = ttk.Scrollbar(wrap, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=ys.set, xscrollcommand=xs.set)
        ys.pack(side="right", fill="y")
        xs.pack(side="bottom", fill="x")
        self.tree.pack(fill="both", expand=True)
        self.tree.tag_configure("odd", background="#0e1f3d")
        self.tree.tag_configure("disabled", foreground="#6c8397")
        self.tree.tag_configure("dynamic", foreground="#9ec5e0")
        self.tree.tag_configure("invalid", foreground=RED)
        self.tree.bind("<Double-1>", lambda _e: self.edit() if (self.fields or auto) and not ro else None)
        self.count = tk.Label(self, text="", bg=BG, fg=MUTED, anchor="w", font=(FONT, 9))
        self.count.pack(fill="x", pady=(6, 0))
        self._setup_columns()

    # -- columns / data ----------------------------------------------------
    def _setup_columns(self):
        ids = ["flags"] + [f"c{i}" for i in range(len(self.cols))]
        self.tree.configure(columns=ids)
        self.tree.heading("flags", text="")
        self.tree.column("flags", width=46, stretch=False, anchor="center")
        for i, name in enumerate(self.cols):
            self.tree.heading(f"c{i}", text=name.upper(), command=lambda n=name: self._sort(n))
            w = 520 if name == "message" else 190 if name in ("comment", "on-event", "source") else 125
            self.tree.column(f"c{i}", width=w, anchor="w", stretch=True)

    def _sort(self, name):
        rev = bool(self.sort and self.sort[0] == name and not self.sort[1])
        self.sort = (name, rev)
        self._fill(self.data)

    @staticmethod
    def _key(v):
        try:
            return (0, float(v), "")
        except (TypeError, ValueError):
            return (1, 0, str(v).lower())

    def _fill(self, rows):
        self.data = rows
        if self.auto_cols:
            keys = []
            for r in rows:
                for k in r:
                    if k not in keys and k not in (".id", ".nextid", ".about"):
                        keys.append(k)
            keys = keys[:14]
            if keys != self.cols:
                self.cols = keys
                self._setup_columns()
        q = self.search.get().strip().lower()
        items = [r for r in rows if not q or any(q in str(v).lower() for v in r.values())]
        if self.sort and self.sort[0] in self.cols:
            items.sort(key=lambda r: self._key(r.get(self.sort[0], "")), reverse=self.sort[1])
        keep = {self.rows[i].get(".id") for i in self.tree.selection() if i in self.rows}
        self.tree.delete(*self.tree.get_children())
        self.rows = {}
        reselect = []
        for i, r in enumerate(items):
            iid = str(i)
            self.rows[iid] = r
            flags = "".join(ch for key, ch in self.FLAGS if r.get(key) == "true")
            vals = [flags]
            for c in self.cols:
                v = r.get(c, "")
                vals.append(fmt_bytes(v) if c in self.BYTE_COLS and str(v).isdigit() else v)
            tags = tuple(t for t in ("disabled", "invalid", "dynamic") if r.get(t) == "true") + (("odd",) if i % 2 else ())
            self.tree.insert("", "end", iid=iid, values=vals, tags=tags)
            if r.get(".id") in keep:
                reselect.append(iid)
        if reselect:
            self.tree.selection_set(reselect)
        self.count.configure(text=f"{len(items)} items" + (f"  (of {len(rows)})" if len(items) != len(rows) else ""))

    def _load_path(self):
        p = self.path_var.get().strip()
        if p:
            self.path = "/" + p.strip("/")
            self.cols = []
            self.refresh()

    # -- life cycle --------------------------------------------------------
    def on_show(self):
        self.visible = True
        if not self.auto_cols or self.path:
            self.refresh()
        self._tick_reset()

    def on_hide(self):
        self.visible = False
        if self.after_id:
            self.after_cancel(self.after_id)
            self.after_id = None

    def _tick_reset(self):
        if self.after_id:
            self.after_cancel(self.after_id)
            self.after_id = None
        if self.visible and self.auto_var.get():
            self.after_id = self.after(3000, self._tick)

    def _tick(self):
        self.after_id = None
        if self.visible and self.auto_var.get():
            if self.app.connected:
                self.refresh(quiet=True)
            self._tick_reset()

    def refresh(self, quiet=False):
        if not self.path:
            return
        if not self.app.connected:
            self.count.configure(text="Not connected — choose a router and press Connect.")
            return
        api = self.app.api
        self.app.run_async(lambda: api.print_rows(self.path), self._fill,
                           (lambda e: None) if quiet else self._load_error)

    def _load_error(self, e):
        self._fill([])
        self.count.configure(text=f"⚠ {e}", fg=RED)
        self.after(4000, lambda: self.count.configure(fg=MUTED))

    # -- actions -----------------------------------------------------------
    def selected(self):
        return [self.rows[i] for i in self.tree.selection() if i in self.rows]

    def _do(self, label, work):
        self.app.run_async(work, lambda _r: self.refresh(), lambda e: self.app.error(label, e))

    def add(self):
        api = self.app.require()
        if not api:
            return

        def ok(vals, extra):
            props = {k: v for k, v in vals.items() if v}
            props.update(extra)
            words = [f"={k}={v}" for k, v in props.items()]
            self._do("Add failed", lambda: api.command(self.path + "/add", *words))
        FormDialog(self.app, f"Add — {self.spec['title']}", self.fields, {}, ok)

    def edit(self):
        api = self.app.require()
        sel = self.selected()
        if not api or not sel:
            if api:
                messagebox.showinfo("Edit", "Select a row first.")
            return
        row = sel[0]

        def ok(vals, extra):
            changed = {k: v for k, v in vals.items() if v != row.get(k, "")}
            changed.update(extra)
            if not changed:
                return
            words = [f"=.id={row['.id']}"] + [f"={k}={v}" for k, v in changed.items()]
            self._do("Edit failed", lambda: api.command(self.path + "/set", *words))
        FormDialog(self.app, f"Edit — {self.spec['title']}", self.fields, row, ok)

    def remove(self):
        api, sel = self.app.require(), self.selected()
        if not api or not sel:
            return
        if not messagebox.askyesno("Remove", f"Remove {len(sel)} selected item(s)?"):
            return
        ids = ",".join(r[".id"] for r in sel if ".id" in r)
        self._do("Remove failed", lambda: api.command(self.path + "/remove", f"=.id={ids}"))

    def toggle(self, enable):
        api, sel = self.app.require(), self.selected()
        if not api or not sel:
            return
        ids = ",".join(r[".id"] for r in sel if ".id" in r)
        self._do("Enable/Disable failed",
                 lambda: api.command(self.path + ("/enable" if enable else "/disable"), f"=.id={ids}"))

    def comment(self):
        api, sel = self.app.require(), self.selected()
        if not api or not sel:
            return
        text = simpledialog.askstring("Comment", "Comment (empty clears it):", initialvalue=sel[0].get("comment", ""),
                                      parent=self.app)
        if text is None:
            return
        ids = ",".join(r[".id"] for r in sel if ".id" in r)
        self._do("Comment failed", lambda: api.command(self.path + "/set", f"=.id={ids}", f"=comment={text}"))

    def run_sub(self, sub):
        api, sel = self.app.require(), self.selected()
        if not api or not sel:
            return
        ids = ",".join(r[".id"] for r in sel if ".id" in r)
        self._do(f"{sub} failed", lambda: api.command(f"{self.path}/{sub}", f"=.id={ids}"))

    def move(self, direction):
        api, sel = self.app.require(), self.selected()
        if not api or len(sel) != 1 or self.search.get().strip():
            if api and self.search.get().strip():
                messagebox.showinfo("Move", "Clear the search box before reordering rules.")
            return
        order = [r.get(".id") for r in self.data]
        idx = order.index(sel[0][".id"])
        tgt = idx + direction
        if tgt < 0 or tgt >= len(order):
            return
        dest = order[tgt] if direction < 0 else (order[tgt + 1] if tgt + 1 < len(order) else None)
        words = [f"=numbers={sel[0]['.id']}"] + ([f"=destination={dest}"] if dest else [])
        self._do("Move failed", lambda: api.command(self.path + "/move", *words))


class AnyMenuPage(TablePage):
    def __init__(self, app, spec):
        spec = dict(spec, path="", cols=[], fields=[])
        super().__init__(app, spec, auto=True)


class SettingsPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.path, self.ro = spec["path"], spec.get("ro", False)
        self.header(spec["title"], self.path)
        tb = tk.Frame(self, bg=BG)
        tb.pack(fill="x", pady=(0, 8))
        app.button(tb, "⟳ Refresh", self.refresh, True).pack(side="left")
        tk.Label(tb, text="read-only" if self.ro else "Double-click a value to change it", bg=BG, fg=MUTED,
                 font=(FONT, 9)).pack(side="left", padx=12)
        wrap = tk.Frame(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        wrap.pack(fill="both", expand=True)
        self.tree = ttk.Treeview(wrap, columns=("k", "v"), show="headings")
        self.tree.heading("k", text="PROPERTY")
        self.tree.heading("v", text="VALUE")
        self.tree.column("k", width=260, stretch=False)
        self.tree.column("v", width=600)
        ys = ttk.Scrollbar(wrap, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=ys.set)
        ys.pack(side="right", fill="y")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", self.edit)
        self.msg = tk.Label(self, text="", bg=BG, fg=MUTED, anchor="w", font=(FONT, 9))
        self.msg.pack(fill="x", pady=(6, 0))
        self.multi = False

    def on_show(self):
        self.refresh()

    def refresh(self):
        if not self.app.connected:
            self.msg.configure(text="Not connected.")
            return
        api = self.app.api
        self.app.run_async(lambda: api.print_rows(self.path), self._fill,
                           lambda e: (self._fill([]), self.msg.configure(text=f"⚠ {e}", fg=RED)))

    def _fill(self, rows):
        self.tree.delete(*self.tree.get_children())
        self.msg.configure(fg=MUTED, text="")
        self.multi = len(rows) > 1
        if self.multi:  # e.g. /system/health in v7: name/value rows
            for r in rows:
                self.tree.insert("", "end", values=(r.get("name", ""), r.get("value", "") + " " + r.get("type", "")))
            return
        for r in rows[:1]:
            for k, v in r.items():
                if k not in (".id",):
                    self.tree.insert("", "end", values=(k, v))

    def edit(self, _e=None):
        sel = self.tree.selection()
        if self.ro or self.multi or not sel:
            return
        key, val = self.tree.item(sel[0], "values")
        new = simpledialog.askstring("Change value", f"{key}:", initialvalue=val, parent=self.app)
        if new is None or new == val:
            return
        api = self.app.api
        self.app.run_async(lambda: api.command(self.path + "/set", f"={key}={new}"),
                           lambda _r: self.refresh(), lambda e: self.app.error("Change failed", e))


class StreamTool(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header(spec["title"], spec["path"])
        form = tk.Frame(self, bg=BG)
        form.pack(fill="x", pady=(0, 8))
        self.entries = {}
        for label, key, default in spec["fields"]:
            tk.Label(form, text=label, bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(0, 4))
            e = app.entry(form, 14, show="•" if key == "password" else None)
            e.insert(0, default)
            e.pack(side="left", padx=(0, 10))
            self.entries[key] = e
        self.btn = app.button(form, "▶ Start", self.toggle, True)
        self.btn.pack(side="left", padx=4)
        app.button(form, "Clear", self.clear).pack(side="left")
        self.token = self.clone = self.last = None
        if isinstance(spec.get("cols"), str):
            spec["cols"] = spec["cols"].split()
        wrap = tk.Frame(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        wrap.pack(fill="both", expand=True)
        self.table = None
        if spec.get("cols"):
            self.table_rows = {}
            self.table = ttk.Treeview(wrap, columns=spec["cols"], show="headings")
            for c in spec["cols"]:
                self.table.heading(c, text=c.upper())
                self.table.column(c, width=130)
            self.table.pack(fill="both", expand=True)
        else:
            self.text = tk.Text(wrap, bg=PANEL, fg=TEXT, relief="flat", font=("Consolas", 10), wrap="none")
            self.text.pack(fill="both", expand=True)

    def clear(self):
        if self.table is not None:
            self.table.delete(*self.table.get_children())
            self.table_rows.clear()
        else:
            self.text.delete("1.0", "end")

    def toggle(self):
        self.stop() if self.token else self.start()

    def start(self):
        api = self.app.require()
        if not api:
            return
        args = [f"={k}={e.get().strip()}" for k, e in self.entries.items() if e.get().strip()]
        self.stop()
        self.clear()
        clone, token = api.clone(), object()
        self.clone, self.token, self.last = clone, token, None
        self.btn.configure(text="■ Stop")

        def worker():
            err = None
            try:
                clone.connect()
                clone.stream(self.spec["path"], args, lambda r: self.app.post(lambda: self._row(r, token)))
            except Exception as e:
                err = e
            self.app.post(lambda: self._done(token, err))
        threading.Thread(target=worker, daemon=True).start()

    def stop(self):
        self.token = None
        if self.clone:
            self.clone.close()
            self.clone = None
        self.btn.configure(text="▶ Start")

    def on_hide(self):
        self.stop()

    def _row(self, row, token):
        if token is not self.token:
            return
        self.last = row
        if self.table is not None:
            key = tuple(row.get(k, "") for k in self.spec.get("key", ())) or (len(self.table_rows),)
            vals = [row.get(c, "") for c in self.spec["cols"]]
            if key in self.table_rows:
                self.table.item(self.table_rows[key], values=vals)
            else:
                self.table_rows[key] = self.table.insert("", "end", values=vals)
        else:
            fmt = self.spec.get("fmt")
            line = fmt(row) if fmt else "  ".join(f"{k}={v}" for k, v in row.items())
            self.text.insert("end", line + "\n")
            self.text.see("end")

    def _done(self, token, err):
        if token is not self.token:
            return
        self.token = None
        self.btn.configure(text="▶ Start")
        if self.table is None:
            if err:
                self.text.insert("end", f"\n⚠ {err}\n")
            elif self.spec.get("summary") and self.last:
                self.text.insert("end", "\n" + self.spec["summary"](self.last) + "\n")
            self.text.see("end")
        elif err:
            self.app.error("Tool error", err)


class GraphPage(Page):
    N = 120

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Traffic Graph", "/interface/monitor-traffic")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 8))
        tk.Label(bar, text="Interface", bg=BG, fg=MUTED, font=(FONT, 9)).pack(side="left", padx=(0, 6))
        self.combo = ttk.Combobox(bar, state="readonly", width=24)
        self.combo.pack(side="left")
        self.btn = app.button(bar, "▶ Start", self.toggle, True)
        self.btn.pack(side="left", padx=8)
        self.canvas = tk.Canvas(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.bind("<Configure>", lambda _e: self._draw())
        self.rx, self.tx = deque(maxlen=self.N), deque(maxlen=self.N)
        self.token = self.clone = None

    def on_show(self):
        if self.app.connected:
            api = self.app.api
            self.app.run_async(lambda: api.print_rows("/interface", ["name"]), self._fill_ifs, lambda e: None)

    def _fill_ifs(self, rows):
        names = [r.get("name", "") for r in rows]
        self.combo["values"] = names
        if names and not self.combo.get():
            self.combo.set(names[0])

    def on_hide(self):
        self.stop()

    def toggle(self):
        self.stop() if self.token else self.start()

    def start(self):
        api = self.app.require()
        if not api or not self.combo.get():
            return
        self.stop()
        self.rx.clear()
        self.tx.clear()
        clone, token = api.clone(), object()
        self.clone, self.token = clone, token
        self.btn.configure(text="■ Stop")
        iface = self.combo.get()

        def row(r):
            self.app.post(lambda: self._sample(r, token))

        def worker():
            try:
                clone.connect()
                clone.stream("/interface/monitor-traffic", [f"=interface={iface}"], row)
            except Exception:
                pass
            self.app.post(lambda: self.stop() if token is self.token else None)
        threading.Thread(target=worker, daemon=True).start()

    def stop(self):
        self.token = None
        if self.clone:
            self.clone.close()
            self.clone = None
        self.btn.configure(text="▶ Start")

    def _sample(self, r, token):
        if token is not self.token:
            return
        self.rx.append(float(r.get("rx-bits-per-second", 0) or 0))
        self.tx.append(float(r.get("tx-bits-per-second", 0) or 0))
        self._draw()

    def _draw(self):
        c = self.canvas
        c.delete("all")
        w, h, left = c.winfo_width(), c.winfo_height(), 78
        if w < 200 or h < 120:
            return
        peak = max([max(self.rx, default=0), max(self.tx, default=0), 10_000.0]) * 1.1
        for i in range(5):
            y = h - 30 - (h - 60) * i / 4
            c.create_line(left, y, w - 12, y, fill=BORDER)
            c.create_text(left - 6, y, text=fmt_rate(peak * i / 4), fill=MUTED, anchor="e", font=(FONT, 8))
        for series, col in ((self.rx, CYAN), (self.tx, GREEN)):
            pts, n = [], len(series)
            for idx, v in enumerate(series):
                x = left + (w - left - 12) * (self.N - n + idx) / (self.N - 1)
                pts += [x, h - 30 - (h - 60) * v / peak]
            if len(pts) >= 4:
                c.create_line(*pts, fill=col, width=2)
        rx = fmt_rate(self.rx[-1]) if self.rx else "—"
        tx = fmt_rate(self.tx[-1]) if self.tx else "—"
        c.create_text(left, 12, anchor="w", fill=CYAN, font=(FONT, 10, "bold"), text=f"● RX {rx}")
        c.create_text(left + 190, 12, anchor="w", fill=GREEN, font=(FONT, 10, "bold"), text=f"● TX {tx}")


class TerminalPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Terminal (API)", "e.g.  /ip/address/print    or    /ip address print    or    /interface/set =.id=*1 =comment=hi")
        wrap = tk.Frame(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        wrap.pack(fill="both", expand=True)
        self.out = tk.Text(wrap, bg=PANEL, fg=TEXT, relief="flat", font=("Consolas", 10), wrap="word", state="disabled")
        ys = ttk.Scrollbar(wrap, command=self.out.yview)
        self.out.configure(yscrollcommand=ys.set)
        ys.pack(side="right", fill="y")
        self.out.pack(fill="both", expand=True)
        self.entry = app.entry(self, 80)
        self.entry.pack(fill="x", pady=(8, 0), ipady=5)
        self.entry.bind("<Return>", self.run)
        self.entry.bind("<Up>", lambda _e: self._hist(-1))
        self.entry.bind("<Down>", lambda _e: self._hist(1))
        self.history, self.hpos = [], 0
        self._write("Type an API command and press Enter.  'clear' clears the screen.\n"
                    "Arguments: =key=value (attributes), ?key=value (filters), =.proplist=a,b\n\n")

    def on_show(self):
        self.entry.focus_set()

    def _write(self, text):
        self.out.configure(state="normal")
        self.out.insert("end", text)
        self.out.see("end")
        self.out.configure(state="disabled")

    def _hist(self, d):
        if not self.history:
            return "break"
        self.hpos = min(max(self.hpos + d, 0), len(self.history))
        self.entry.delete(0, "end")
        if self.hpos < len(self.history):
            self.entry.insert(0, self.history[self.hpos])
        return "break"

    def run(self, _e=None):
        line = self.entry.get().strip()
        self.entry.delete(0, "end")
        if not line:
            return
        self.history.append(line)
        self.hpos = len(self.history)
        if line == "clear":
            self.out.configure(state="normal")
            self.out.delete("1.0", "end")
            self.out.configure(state="disabled")
            return
        api = self.app.require()
        if not api:
            return
        self._write(f"> {line}\n")
        try:
            path, args = parse_console(line)
        except ValueError as e:
            self._write(f"⚠ {e}\n\n")
            return

        def show(rows):
            for r in rows:
                self._write("\n".join(f"{k}={v}" for k, v in r.items()) + "\n\n")
            self._write(f"-- {len(rows)} row(s)\n\n")
        self.app.run_async(lambda: api.command(path, *args), show, lambda e: self._write(f"⚠ {e}\n\n"))


class SystemPage(Page):
    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Backup / Reboot / Updates")
        box = tk.Frame(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        box.pack(fill="x")
        row1 = tk.Frame(box, bg=PANEL)
        row1.pack(fill="x", padx=14, pady=14)
        tk.Label(row1, text="File name", bg=PANEL, fg=MUTED, font=(FONT, 9)).pack(side="left")
        self.name = app.entry(row1, 24)
        self.name.insert(0, "backup-" + time.strftime("%Y%m%d"))
        self.name.pack(side="left", padx=8)
        app.button(row1, "Create Backup (.backup)", lambda: self.cmd("/system/backup/save", [f"=name={self.name.get()}"])).pack(side="left", padx=4)
        app.button(row1, "Export Config (.rsc)", lambda: self.cmd("/export", [f"=file={self.name.get()}"])).pack(side="left", padx=4)
        row2 = tk.Frame(box, bg=PANEL)
        row2.pack(fill="x", padx=14, pady=(0, 14))
        app.button(row2, "Check for Updates", lambda: self.cmd("/system/package/update/check-for-updates")).pack(side="left", padx=(0, 6))
        app.button(row2, "Download & Install Updates",
                   lambda: self.cmd("/system/package/update/install", confirm="Download updates and REBOOT the router?")).pack(side="left", padx=6)
        app.button(row2, "Upgrade RouterBOARD Firmware",
                   lambda: self.cmd("/system/routerboard/upgrade", confirm="Upgrade firmware? A reboot is needed afterwards.")).pack(side="left", padx=6)
        row3 = tk.Frame(box, bg=PANEL)
        row3.pack(fill="x", padx=14, pady=(0, 14))
        app.button(row3, "↺ Restore backup", lambda: self.cmd("/system/backup/load", [f"=name={self.name.get()}"],
                   confirm="Restore the backup file named above? The router will REBOOT and replace its configuration.")).pack(side="left", padx=(0, 6))
        app.button(row3, "▤ Make Supout.rif", lambda: self.cmd("/system/sup-output", [f"=name={self.name.get()}"])).pack(side="left", padx=6)
        app.button(row3, "⟲ Reboot", lambda: self.cmd("/system/reboot", confirm="Reboot the router now?")).pack(side="left", padx=6)
        app.button(row3, "⏻ Shutdown", lambda: self.cmd("/system/shutdown", confirm="Shut the router down? You will need physical access to power it on.")).pack(side="left", padx=6)
        tk.Label(self, text="Backup/export files are created ON the router (see System → Files). "
                            "Download them with SFTP/FTP — the RouterOS API cannot transfer files.",
                 bg=BG, fg=MUTED, font=(FONT, 9), wraplength=900, justify="left").pack(anchor="w", pady=10)
        self.out = tk.Text(self, bg=PANEL, fg=TEXT, relief="flat", font=("Consolas", 10), height=12)
        self.out.pack(fill="both", expand=True)

    def cmd(self, path, args=(), confirm=None):
        api = self.app.require()
        if not api or (confirm and not messagebox.askyesno("Confirm", confirm)):
            return

        def show(rows):
            self.out.insert("end", f"✔ {path}\n" + "".join("   " + "  ".join(f"{k}={v}" for k, v in r.items()) + "\n" for r in rows))
            self.out.see("end")

        def fail(e):
            if isinstance(e, ConnectionError) and path in ("/system/reboot", "/system/shutdown", "/system/package/update/install", "/system/backup/load"):
                self.out.insert("end", f"✔ {path} — router closed the session (expected).\n")
                self.app.disconnect()
            else:
                self.out.insert("end", f"⚠ {path}: {e}\n")
        self.app.run_async(lambda: api.command(path, *args), show, fail)


class MndpPage(Page):
    TLV = {1: "mac", 5: "identity", 7: "version", 8: "platform", 10: "uptime", 11: "software-id", 12: "board",
           15: "ipv6", 16: "interface", 17: "address"}

    def __init__(self, app, spec):
        super().__init__(app, spec)
        self.header("Neighbor Discovery (MNDP, Layer-2)", "UDP 5678 broadcast — works without connecting")
        bar = tk.Frame(self, bg=BG)
        bar.pack(fill="x", pady=(0, 8))
        app.button(bar, "⟳ Discover (8 s)", self.scan, True).pack(side="left")
        self.info = tk.Label(bar, text="", bg=BG, fg=MUTED, font=(FONT, 9))
        self.info.pack(side="left", padx=12)
        cols = ("address", "mac", "identity", "platform", "version", "board", "interface", "uptime")
        wrap = tk.Frame(self, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        wrap.pack(fill="both", expand=True)
        self.cols = cols
        self.tree = ttk.Treeview(wrap, columns=cols, show="headings")
        for c in cols:
            self.tree.heading(c, text=c.upper())
            self.tree.column(c, width=130)
        self.tree.pack(fill="both", expand=True)

    def scan(self):
        self.tree.delete(*self.tree.get_children())
        self.info.configure(text="Listening…", fg=YELLOW)

        def work():
            found = {}
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
                s.bind(("", 5678))
                try:
                    s.sendto(b"\x00\x00\x00\x00", ("255.255.255.255", 5678))
                except OSError:
                    pass
                end = time.time() + 8
                while time.time() < end:
                    s.settimeout(max(end - time.time(), 0.1))
                    try:
                        data, addr = s.recvfrom(2048)
                    except socket.timeout:
                        break
                    rec = self._parse(data)
                    if rec.get("mac"):
                        rec.setdefault("address", addr[0])
                        found[rec["mac"]] = rec
            finally:
                s.close()
            return list(found.values())

        def done(rows):
            for r in rows:
                self.tree.insert("", "end", values=[r.get(c, "") for c in self.cols])
            self.info.configure(text=f"{len(rows)} device(s) found", fg=MUTED)
        self.app.run_async(work, done, lambda e: self.info.configure(text=f"⚠ {e}", fg=RED))

    def _parse(self, data):
        rec, pos = {}, 4
        while pos + 4 <= len(data):
            t, ln = struct.unpack(">HH", data[pos:pos + 4])
            val = data[pos + 4:pos + 4 + ln]
            pos += 4 + ln
            name = self.TLV.get(t)
            if not name:
                continue
            if name == "mac" and len(val) == 6:
                rec[name] = ":".join(f"{b:02X}" for b in val)
            elif name == "address" and len(val) == 4:
                rec[name] = ".".join(str(b) for b in val)
            elif name == "uptime" and len(val) == 4:
                s = struct.unpack("<I", val)[0]
                rec[name] = f"{s // 86400}d {s % 86400 // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}"
            elif name not in ("ipv6", "software-id"):
                rec[name] = val.decode("utf-8", "replace")
        return rec


import pro_pages  # noqa: E402,F401  (registers new page kinds in PAGE_KINDS)
from services import AlertCenter, Telemetry, DemoSource, Fleet, short_uptime  # noqa: E402
from sync import SyncManager  # noqa: E402

PAGE_KINDS.update({"table": TablePage, "settings": SettingsPage, "tool": StreamTool, "graph": GraphPage,
                   "terminal": TerminalPage, "system": SystemPage, "mndp": MndpPage, "any": AnyMenuPage})


def spec_key(spec):
    return f"{spec['kind']}|{spec.get('path', '')}|{spec['title']}"


# ----------------------------------------------------------------------------------
class Switch(tk.Canvas):
    def __init__(self, parent, value=True, command=None, bg=TOPBAR):
        super().__init__(parent, width=44, height=22, bg=bg, highlightthickness=0, cursor="hand2")
        self.value, self.command = value, command
        self.bind("<Button-1>", self.toggle)
        self.draw()

    def toggle(self, _e=None):
        self.value = not self.value
        self.draw()
        if self.command:
            self.command(self.value)

    def draw(self):
        self.delete("all")
        rrect(self, 1, 1, 43, 21, 10, fill=GREEN if self.value else "#334155", outline="")
        x = 33 if self.value else 11
        self.create_oval(x - 8, 3, x + 8, 19, fill="white", outline="")


from ui_kit import rrect, gradient  # noqa: E402


class Sidebar(tk.Frame):
    """Colourful WinBox-style navigation: top-level pages + expandable WinBox menu tree."""

    def __init__(self, parent, app):
        super().__init__(parent, bg=SIDEBAR, width=232)
        self.app, self.open, self.active = app, {"WinBox"}, None
        self.pack_propagate(False)
        logo = tk.Canvas(self, height=64, bg=SIDEBAR, highlightthickness=0)
        logo.pack(fill="x")
        gradient(logo, 14, 12, 58, 56, "#7c3aed", "#2563eb", 14, horizontal=False)
        logo.create_text(36, 34, text="◈", fill="white", font=(FONT, 22, "bold"))
        logo.create_text(68, 26, text="MikroTik", anchor="w", fill=TEXT, font=(FONT, 15, "bold"))
        logo.create_text(68, 46, text="by CloudCore Network", anchor="w", fill=MUTED, font=(FONT, 9))
        wrap = tk.Frame(self, bg=SIDEBAR)
        wrap.pack(fill="both", expand=True)
        self.cv = tk.Canvas(wrap, bg=SIDEBAR, highlightthickness=0)
        self.inner = tk.Frame(self.cv, bg=SIDEBAR)
        self.cv.create_window(0, 0, window=self.inner, anchor="nw", tags="in")
        self.cv.pack(fill="both", expand=True)
        self.cv.bind("<Configure>", lambda e: self.cv.itemconfigure("in", width=e.width))
        self.inner.bind("<Configure>", lambda _e: self.cv.configure(scrollregion=self.cv.bbox("all")))
        for w in (self.cv, self.inner):
            w.bind("<Enter>", lambda _e: self.cv.bind_all("<MouseWheel>", self._wheel))
            w.bind("<Leave>", lambda _e: self.cv.unbind_all("<MouseWheel>"))
        self.build()

    def _wheel(self, e):
        self.cv.yview_scroll(-1 if e.delta > 0 else 1, "units")

    def build(self):
        for w in self.inner.winfo_children():
            w.destroy()
        for title, glyph, color, node in NAV:
            if node == "WINBOX":
                self.row(0, title, glyph, color, None, f"g:{title}", self.open.__contains__(title))
                if title in self.open:
                    for t2, g2, c2, sub in WINBOX_TREE:
                        if isinstance(sub, dict):
                            self.row(1, t2, g2, c2, sub, spec_key(sub))
                            continue
                        self.row(1, t2, g2, c2, None, f"g:{t2}", t2 in self.open)
                        if t2 in self.open:
                            for sp in sub:
                                self.row(2, sp["title"], "•", c2, sp, spec_key(sp))
            else:
                self.row(0, title, glyph, color, node, spec_key(node))

    def row(self, level, title, glyph, color, spec, key, expanded=None):
        h = 30 if level == 2 else 38
        c = tk.Canvas(self.inner, height=h, bg=SIDEBAR, highlightthickness=0, cursor="hand2")
        c.pack(fill="x", padx=8, pady=1)
        group = spec is None
        state = {"hot": False}

        def draw(_e=None):
            w = c.winfo_width()
            c.delete("all")
            act = (not group) and key == self.active
            if act:
                gradient(c, 0, 1, w, h - 1, "#2f7bff", "#a855f7", 22)
            elif state["hot"]:
                rrect(c, 0, 1, w, h - 1, 8, fill="#0f2147", outline="")
            x = 12 + level * 16
            if level < 2:
                rrect(c, x, h / 2 - 12, x + 24, h / 2 + 12, 7, fill=color if not act else "#5b8def", outline="")
                c.create_text(x + 12, h / 2, text=glyph, fill="white", font=(FONT, 10 if len(glyph) < 3 else 7, "bold"))
                c.create_text(x + 34, h / 2, text=title, anchor="w", fill="white" if act else TEXT, font=(FONT, 10, "bold" if act else "normal"))
            else:
                c.create_text(x + 6, h / 2, text="•", fill=color, font=(FONT, 9))
                c.create_text(x + 20, h / 2, text=title, anchor="w", fill="white" if act else MUTED, font=(FONT, 9))
            if group:
                c.create_text(w - 14, h / 2, text="⌃" if expanded else "⌄", fill=MUTED, font=(FONT, 10, "bold"))
        c.bind("<Configure>", draw)

        def hot(v):
            state["hot"] = v
            draw()
        c.bind("<Enter>", lambda _e: hot(True))
        c.bind("<Leave>", lambda _e: hot(False))
        if group:
            name = key[2:]
            c.bind("<Button-1>", lambda _e: self.toggle(name))
        else:
            c.bind("<Button-1>", lambda e: self.app.open_spec(spec, key, window=bool(e.state & 0x1)))
            c.bind("<Button-3>", lambda e: self.menu(e, spec, key))

    def menu(self, e, spec, key):
        m = tk.Menu(self, tearoff=0, bg=CARD2, fg=TEXT, activebackground=BLUE)
        m.add_command(label="Open", command=lambda: self.app.open_spec(spec, key))
        m.add_command(label="Open in new WinBox window", command=lambda: self.app.open_spec(spec, key, window=True))
        m.tk_popup(e.x_root, e.y_root)

    def toggle(self, name):
        self.open.symmetric_difference_update({name})
        self.build()

    def set_active(self, key):
        self.active = key
        self.build()


class WinBoxWindow(tk.Toplevel):
    """A floating WinBox-style child window hosting any page."""

    def __init__(self, app, spec, n):
        super().__init__(app)
        self.app, self.spec = app, spec
        self.configure(bg=BG)
        self.geometry(f"980x620+{120 + n % 8 * 34}+{90 + n % 8 * 30}")
        self.minsize(560, 360)
        self.refresh_title()
        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill="both", expand=True, padx=10, pady=10)
        self.page = app.make_page(spec, self.body)
        self.page.pack(fill="both", expand=True)
        self.page.on_show()
        self.protocol("WM_DELETE_WINDOW", self.close)

    def refresh_title(self):
        p = self.app.cur_profile or {}
        who = f"{p.get('username', '?')}@{p.get('host', 'not connected')}"
        ident = self.app.telemetry.d.get("identity", "")
        self.title(f"{who} ({ident}) - WinBox - {self.spec['title']}" if p else f"WinBox - {self.spec['title']} (not connected)")

    def close(self):
        try:
            self.page.on_hide()
        except Exception:
            pass
        self.app.windows = [w for w in self.app.windows if w is not self]
        self.destroy()


# ----------------------------------------------------------------------------------
class App(ISPMixin, tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} {APP_VERSION}")
        self.geometry("1500x900")
        self.minsize(1280, 760)
        self.configure(bg=BG)
        self.api, self.connected, self.cur_profile, self.host = None, False, None, None
        self.auto = True
        self.q = queue.Queue()
        self.profiles = self.load_profiles()
        self.settings = self.load_settings()
        self.pages, self.active, self.active_key, self.windows = {}, None, None, []
        self.alerts, self.demo = AlertCenter(), DemoSource()
        self.db = DB(APP_DIR)
        self.sync = SyncManager(self)
        self.telemetry = Telemetry(self)
        self.telemetry.interval = float(self.settings.get("interval", 2))
        self.fleet = Fleet(self)
        self._style()
        self._build()
        self.alerts.subs.append(self._bell)
        self.telemetry.subscribe(self._footer)
        self.after(80, self._pump)
        self.after(300, self.fleet.start)
        self.after(1500, self.sync.start)
        self.bind("<F11>", lambda _e: self.attributes("-fullscreen", not self.attributes("-fullscreen")))
        self.bind("<Control-slash>", lambda _e: self.search.focus_set())
        self.bind("<Control-k>", lambda _e: self.search.focus_set())
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.open_spec(NAV[0][3], spec_key(NAV[0][3]))

    # -- helpers -----------------------------------------------------------
    def post(self, fn):
        self.q.put(fn)

    def _pump(self):
        try:
            while True:
                try:
                    self.q.get_nowait()()
                except queue.Empty:
                    break
                except Exception:
                    traceback.print_exc()
        finally:
            self.after(60, self._pump)

    def run_async(self, work, ok=None, err=None):
        def runner():
            try:
                res = work()
            except Exception as e:
                self.post(lambda e=e: self._on_err(err, e))
            else:
                if ok:
                    self.post(lambda: ok(res))
        threading.Thread(target=runner, daemon=True).start()

    def _on_err(self, err, e):
        if isinstance(e, (ConnectionError, ssl.SSLError)) and self.connected:
            self.disconnect(f"Connection lost: {e}")
            messagebox.showerror("Connection lost", str(e))
            return
        (err or (lambda x: self.error("Error", x)))(e)

    def error(self, title, e):
        messagebox.showerror(title, str(e))

    def require(self):
        if not self.connected or not self.api:
            messagebox.showinfo("Not connected", "Connect to a router first.")
            return None
        return self.api

    def entry(self, parent, width=20, show=None):
        return tk.Entry(parent, width=width, bg=PANEL2, fg=TEXT, insertbackground=CYAN, relief="flat",
                        highlightthickness=1, highlightbackground=BORDER, highlightcolor=CYAN,
                        font=(FONT, 10), show=show)

    def button(self, parent, text, command, primary=False):
        return tk.Button(parent, text=text, command=command, bg=BLUE if primary else PANEL2,
                         fg="white" if primary else TEXT, activebackground="#5aa5ff", activeforeground="white",
                         relief="flat", bd=0, padx=11, pady=6, cursor="hand2", font=(FONT, 9, "bold"))

    def _style(self):
        st = ttk.Style(self)
        st.theme_use("clam")
        st.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT, rowheight=28,
                     bordercolor=BORDER, borderwidth=0, font=(FONT, 10))
        st.configure("Treeview.Heading", background="#0e2142", foreground=CYAN, relief="flat", font=(FONT, 9, "bold"),
                     padding=(6, 6))
        st.map("Treeview", background=[("selected", "#1d4ed8")], foreground=[("selected", "white")])
        st.map("Treeview.Heading", background=[("active", "#143060")])
        st.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT, arrowcolor=CYAN,
                     bordercolor=BORDER, lightcolor=PANEL2, darkcolor=PANEL2, selectbackground=PANEL2,
                     selectforeground=TEXT)
        st.map("TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", TEXT)])
        self.option_add("*TCombobox*Listbox.background", PANEL2)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.option_add("*TCombobox*Listbox.selectBackground", BLUE)
        st.configure("TNotebook", background=BG, borderwidth=0)
        st.configure("TNotebook.Tab", background=PANEL2, foreground=MUTED, padding=(12, 7), font=(FONT, 9, "bold"), borderwidth=0)
        st.map("TNotebook.Tab", background=[("selected", BLUE)], foreground=[("selected", "white")])
        for o in ("Vertical", "Horizontal"):
            st.configure(f"{o}.TScrollbar", background="#16315f", troughcolor=PANEL, bordercolor=PANEL,
                         arrowcolor=CYAN, lightcolor="#16315f", darkcolor="#16315f")

    # -- layout --------------------------------------------------------------
    def _build(self):
        top = tk.Frame(self, bg=TOPBAR, height=58)
        top.pack(fill="x")
        top.pack_propagate(False)
        self.side_visible = True
        tk.Button(top, text="☰", bg=TOPBAR, fg=TEXT, relief="flat", bd=0, highlightthickness=0, font=(FONT, 16), cursor="hand2",
                  activebackground=TOPBAR, activeforeground=CYAN, command=self.toggle_sidebar).pack(side="left", padx=(14, 6))
        sw = tk.Frame(top, bg=PANEL, highlightbackground=BORDER, highlightthickness=1)
        sw.pack(side="left", pady=11, padx=6)
        tk.Label(sw, text="⌕", bg=PANEL, fg=MUTED, font=(FONT, 12)).pack(side="left", padx=(10, 2))
        self.sv = tk.StringVar()
        self.search = tk.Entry(sw, textvariable=self.sv, width=40, bg=PANEL, fg=TEXT, insertbackground=CYAN, relief="flat",
                               font=(FONT, 10), highlightthickness=0)
        self.search.pack(side="left", ipady=5, padx=(0, 10))
        self.search.bind("<KeyRelease>", self._suggest)
        self.search.bind("<Return>", lambda _e: self._pick_suggestion())
        self.search.bind("<Escape>", lambda _e: self._hide_sugg())
        self.search.bind("<Down>", lambda _e: (self.sugg.focus_set(), self.sugg.selection_set(0)) if self.sugg.winfo_ismapped() else None)
        tk.Label(sw, text="Ctrl+/", bg=PANEL, fg=DIM, font=(FONT, 8)).pack(side="left", padx=(0, 8))
        self.sugg = tk.Listbox(self, bg=PANEL2, fg=TEXT, selectbackground=BLUE, relief="flat", font=(FONT, 10),
                               highlightthickness=1, highlightbackground=BORDER, activestyle="none", height=8)
        self.sugg.bind("<Return>", lambda _e: self._pick_suggestion(True))
        self.sugg.bind("<Double-1>", lambda _e: self._pick_suggestion(True))
        self.sugg.bind("<Escape>", lambda _e: self._hide_sugg())
        self.sugg_items = []

        # right side (packed right → left)
        ub = tk.Frame(top, bg=TOPBAR)
        ub.pack(side="right", padx=(6, 16))
        av = tk.Canvas(ub, width=38, height=38, bg=TOPBAR, highlightthickness=0)
        gradient(av, 0, 0, 38, 38, "#a855f7", "#ec4899", 12)
        av.create_text(19, 19, text="A", fill="white", font=(FONT, 13, "bold"))
        av.pack(side="left", padx=(0, 8))
        ut = tk.Frame(ub, bg=TOPBAR)
        ut.pack(side="left")
        self.user_lbl = tk.Label(ut, text="Admin", bg=TOPBAR, fg=TEXT, font=(FONT, 10, "bold"))
        self.user_lbl.pack(anchor="w")
        self.role_lbl = tk.Label(ut, text="Not connected", bg=TOPBAR, fg=GREEN, font=(FONT, 8))
        self.role_lbl.pack(anchor="w")
        tk.Button(top, text="⚙", bg=TOPBAR, fg=MUTED, relief="flat", bd=0, highlightthickness=0, font=(FONT, 15), cursor="hand2", activebackground=TOPBAR,
                  command=lambda: self.navigate("Settings")).pack(side="right", padx=4)
        bell = tk.Frame(top, bg=TOPBAR)
        bell.pack(side="right", padx=6)
        tk.Button(bell, text="🔔", bg=TOPBAR, fg=MUTED, relief="flat", bd=0, highlightthickness=0, font=(FONT, 15), cursor="hand2", activebackground=TOPBAR,
                  command=lambda: self.navigate("Alerts & Notifications")).pack()
        self.badge = tk.Label(bell, text="0", bg=RED, fg="white", font=(FONT, 7, "bold"), padx=3)
        tk.Button(top, text="⛶", bg=TOPBAR, fg=MUTED, relief="flat", bd=0, highlightthickness=0, font=(FONT, 15), cursor="hand2", activebackground=TOPBAR,
                  command=lambda: self.attributes("-fullscreen", not self.attributes("-fullscreen"))).pack(side="right", padx=4)
        tk.Label(top, text="Auto Refresh", bg=TOPBAR, fg=TEXT, font=(FONT, 9)).pack(side="right", padx=(8, 4))
        Switch(top, True, lambda v: setattr(self, "auto", v)).pack(side="right")
        # router toolbar (second row)
        tbar = tk.Frame(self, bg="#0a1730", height=42)
        tbar.pack(fill="x")
        tbar.pack_propagate(False)
        tk.Label(tbar, text="ROUTER", bg="#0a1730", fg=DIM, font=(FONT, 8, "bold")).pack(side="left", padx=(18, 8))
        self.combo = ttk.Combobox(tbar, state="readonly", width=26)
        self.combo.pack(side="left")
        self._refresh_profiles()
        for text, fn in (("＋", lambda: self.profile_dialog(False)), ("✎", lambda: self.profile_dialog(True)),
                         ("✕", self.delete_profile)):
            tk.Button(tbar, text=text, command=fn, bg=PANEL2, fg=TEXT, relief="flat", bd=0, width=3, cursor="hand2",
                      font=(FONT, 9, "bold")).pack(side="left", padx=(5, 0), ipady=2)
        GButton(tbar, "ϟ Connect", self.connect_dialog, "blue", 96, 28, bg="#0a1730").pack(side="left", padx=(14, 6))
        GButton(tbar, "Disconnect", lambda: self.disconnect(), "red", 96, 28, bg="#0a1730").pack(side="left")
        self.status = tk.Label(tbar, text="● DISCONNECTED", bg="#0a1730", fg=RED, font=(FONT, 9, "bold"))
        self.status.pack(side="left", padx=16)
        wm = tk.Menubutton(tbar, text="❐ WinBox Windows ▾", bg=PANEL2, fg=TEXT, relief="flat", font=(FONT, 9, "bold"),
                           cursor="hand2", activebackground=BLUE, activeforeground="white")
        self.wmenu = tk.Menu(wm, tearoff=0, bg=CARD2, fg=TEXT, activebackground=BLUE, postcommand=self._win_menu)
        wm["menu"] = self.wmenu
        wm.pack(side="right", padx=16, ipady=3)
        tk.Label(tbar, text="Shift+click a menu item (or right-click) opens it in its own window",
                 bg="#0a1730", fg=DIM, font=(FONT, 8)).pack(side="right", padx=8)

        foot = tk.Frame(self, bg=TOPBAR, height=28)
        foot.pack(fill="x", side="bottom")
        foot.pack_propagate(False)
        self.copy_lbl = tk.Label(foot, text=f"{APP_NAME} {APP_VERSION}   |   © 2026",
                                 bg=TOPBAR, fg=MUTED, font=(FONT, 8))
        self.copy_lbl.pack(side="left", padx=16)
        self.brand_lbl = tk.Label(foot, text="", bg=TOPBAR, fg=CYAN, font=(FONT, 8, "bold"), cursor="hand2")
        self.brand_lbl.pack(side="right", padx=16)
        self.brand_lbl.bind("<Button-1>", lambda _e: __import__("webbrowser").open("https://" + BRAND["site"]))
        self.update_branding()
        self.foot_r = tk.Label(foot, text="● API Disconnected", bg=TOPBAR, fg=RED, font=(FONT, 8, "bold"))
        self.foot_r.pack(side="right", padx=16)
        self.footer = self.copy_lbl

        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True)
        self.sidebar = Sidebar(body, self)
        self.sidebar.pack(side="left", fill="y")
        tk.Frame(body, bg=BORDER, width=1).pack(side="left", fill="y")
        self.content = tk.Frame(body, bg=BG)
        self.content.pack(side="left", fill="both", expand=True, padx=14, pady=12)
        self.body = body

    def update_branding(self):
        co = self.settings.get("company", BRAND["company"])
        self.brand_lbl.configure(text=f"MikroTik Manager by {BRAND['owner']} • {BRAND['title']}, {co} • {BRAND['site']}")

    def toggle_sidebar(self):
        if self.side_visible:
            self.sidebar.pack_forget()
        else:
            self.sidebar.pack(side="left", fill="y", before=self.content.master.winfo_children()[1])
        self.side_visible = not self.side_visible

    # -- navigation ----------------------------------------------------------
    def make_page(self, spec, host=None):
        self.host = host
        try:
            return PAGE_KINDS[spec["kind"]](self, spec)
        finally:
            self.host = None

    def open_spec(self, spec, key, window=False):
        in_tree = key not in {spec_key(n[3]) for n in NAV if isinstance(n[3], dict)}
        if window or (self.settings.get("winbox_mode") and in_tree):
            self.open_window(spec)
            return
        if self.active:
            self.active.pack_forget()
            self.active.on_hide()
        if key not in self.pages:
            self.pages[key] = self.make_page(spec)
        self.active, self.active_key = self.pages[key], key
        self.active.pack(fill="both", expand=True)
        self.active.on_show()
        self.sidebar.set_active(key)

    def open_window(self, spec):
        w = WinBoxWindow(self, spec, len(self.windows))
        self.windows.append(w)
        w.lift()

    def all_specs(self):
        out = [(n[0], n[3]) for n in NAV if isinstance(n[3], dict)]
        for t, _g, _c, sub in WINBOX_TREE:
            for sp in ([sub] if isinstance(sub, dict) else sub):
                out.append((sp["title"] if isinstance(sub, dict) else f"{t} › {sp['title']}", sp))
        return out

    def navigate(self, title):
        for label, sp in self.all_specs():
            if label == title or sp["title"] == title:
                self.open_spec(sp, spec_key(sp))
                return
        messagebox.showinfo("Not found", f"No page named {title!r}.")

    def all_pages(self):
        yield from self.pages.values()
        for w in self.windows:
            yield w.page

    def winbox_launcher(self):
        self.navigate("Quick Connect")

    def _win_menu(self):
        m = self.wmenu
        m.delete(0, "end")
        m.add_command(label="Cascade", command=self.cascade)
        m.add_command(label="Tile", command=self.tile)
        m.add_command(label="Close all windows", command=self.close_windows)
        m.add_separator()
        for w in self.windows:
            m.add_command(label=w.spec["title"], command=lambda w=w: (w.deiconify(), w.lift()))

    def cascade(self):
        for i, w in enumerate(self.windows):
            w.geometry(f"980x620+{120 + i % 8 * 34}+{90 + i % 8 * 30}")
            w.lift()

    def tile(self):
        n = len(self.windows)
        if not n:
            return
        cols = 2 if n > 1 else 1
        rows = (n + cols - 1) // cols
        W, H = self.winfo_screenwidth() // cols, (self.winfo_screenheight() - 80) // rows
        for i, w in enumerate(self.windows):
            w.geometry(f"{W - 10}x{H - 40}+{i % cols * W}+{i // cols * H}")

    def close_windows(self):
        for w in list(self.windows):
            w.close()

    # -- search palette -------------------------------------------------------
    def _suggest(self, e=None):
        if e and e.keysym in ("Return", "Escape", "Down", "Up"):
            return
        q = self.sv.get().strip().lower()
        if not q:
            return self._hide_sugg()
        items = [(f"▣  {lab}", lambda sp=sp: self.open_spec(sp, spec_key(sp))) for lab, sp in self.all_specs() if q in lab.lower()]
        for r in self.fleet_rows(force_real=True):
            if q in f"{r['name']} {r['ip']}".lower():
                items.append((f"▤  {r['name']}  ({r['ip']})", lambda r=r: self.connect_row(r)))
        for i in self.telemetry.d.get("ifaces", []):
            if q in i["name"].lower():
                items.append((f"⇆  interface {i['name']}", lambda: self.navigate("Interfaces")))
        self.sugg_items = items[:8]
        self.sugg.delete(0, "end")
        for t, _ in self.sugg_items:
            self.sugg.insert("end", t)
        if self.sugg_items:
            self.update_idletasks()
            x = self.search.winfo_rootx() - self.winfo_rootx() - 30
            y = self.search.winfo_rooty() - self.winfo_rooty() + 34
            self.sugg.place(x=x, y=y, width=470)
            self.sugg.configure(height=len(self.sugg_items))
            self.sugg.lift()
        else:
            self._hide_sugg()

    def _hide_sugg(self):
        self.sugg.place_forget()

    def _pick_suggestion(self, from_list=False):
        idx = self.sugg.curselection()[0] if from_list and self.sugg.curselection() else 0
        if self.sugg_items:
            fn = self.sugg_items[idx][1]
            self._hide_sugg()
            self.sv.set("")
            fn()

    # -- profiles ------------------------------------------------------------
    def load_profiles(self):
        try:
            data = json.loads(PROFILES_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except Exception:
            return []

    def save_profiles(self):
        APP_DIR.mkdir(parents=True, exist_ok=True)
        PROFILES_FILE.write_text(json.dumps(self.profiles, indent=2), encoding="utf-8")

    def load_settings(self):
        try:
            return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {"demo": True}

    def apply_settings(self):
        self.telemetry.interval = float(self.settings.get("interval", 2))
        APP_DIR.mkdir(parents=True, exist_ok=True)
        SETTINGS_FILE.write_text(json.dumps(self.settings, indent=2), encoding="utf-8")

    def refresh_profiles(self, select=None):
        self._refresh_profiles(select)
        self.on_fleet()
        self.fleet.probe_now()

    def _refresh_profiles(self, select=None):
        names = [p["name"] for p in self.profiles]
        self.combo["values"] = names
        if select in names:
            self.combo.set(select)
        elif names and not self.combo.get():
            self.combo.set(names[0])
        elif not names:
            self.combo.set("")

    def current_profile(self):
        return next((p for p in self.profiles if p["name"] == self.combo.get()), None)

    def on_fleet(self):
        for pg in list(self.all_pages()):
            if hasattr(pg, "on_fleet"):
                pg.on_fleet()

    def fleet_rows(self, force_real=False):
        if not force_real and not self.connected and self.settings.get("demo", True):
            return [dict(name=n, type=t, ip=ip, status=s, uptime=u, cpu=c, mem=m, txrx=x, loc=l, profile=None)
                    for n, t, ip, s, u, c, m, x, l in DemoSource.DEVICES]
        rows, d = [], self.telemetry.d
        for p in self.profiles:
            st = self.fleet.status.get(p["name"])
            row = dict(name=p["name"], type="Router", ip=p["host"], status=st["state"] if st else "checking",
                       uptime="—", cpu=None, mem=None, txrx="—", loc=p.get("location", "—") or "—", profile=p)
            if self.connected and self.cur_profile and self.cur_profile["name"] == p["name"] and d:
                row.update(status="warning" if d["cpu"] >= 80 or d["mem_pct"] >= 90 else "online",
                           uptime=short_uptime(d["uptime"]), cpu=d["cpu"], mem=int(d["mem_pct"]),
                           txrx=f"{BarList._s(d['rx'])} / {BarList._s(d['tx'])}")
            rows.append(row)
        return rows

    def connect_row(self, row):
        p = row.get("profile")
        if not p:
            messagebox.showinfo("Demo data", "This row is demo data. Add a real device first (＋ Add Device).")
            return
        self.combo.set(p["name"])
        self.connect_dialog()

    def delete_row(self, row):
        p = row.get("profile")
        if p and messagebox.askyesno("Delete", f"Delete device '{p['name']}'?"):
            self.profiles.remove(p)
            self.save_profiles()
            self.combo.set("") if self.combo.get() == p["name"] else None
            self.refresh_profiles()

    def add_device(self):
        self.profile_dialog(False)

    def profile_dialog(self, edit, cur=None, prefill=None):
        cur = cur or (self.current_profile() if edit else None)
        if edit and not cur:
            messagebox.showinfo("Edit router", "Select a router profile first.")
            return
        DeviceDialog(self, cur, prefill)

    def delete_profile(self):
        cur = self.current_profile()
        if cur and messagebox.askyesno("Delete", f"Delete profile '{cur['name']}'?"):
            self.profiles.remove(cur)
            self.save_profiles()
            self.combo.set("")
            self.refresh_profiles()

    # -- network scan --------------------------------------------------------------
    def scan_network_dialog(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("10.255.255.255", 1))
            guess = s.getsockname()[0].rsplit(".", 1)[0] + ".0/24"
            s.close()
        except Exception:
            guess = "192.168.88.0/24"
        cidr = simpledialog.askstring("Scan Network", "Range to scan (CIDR, max 1024 hosts).\n"
                                      "Looks for open RouterOS API (8728) / WinBox (8291) ports:", initialvalue=guess,
                                      parent=self)
        if not cidr:
            return
        dlg = tk.Toplevel(self)
        dlg.title(f"Scan {cidr}")
        dlg.configure(bg=BG)
        dlg.geometry("460x380")
        dlg.transient(self)
        info = tk.Label(dlg, text="Scanning…", bg=BG, fg=YELLOW, font=(FONT, 10))
        info.pack(pady=10)
        lb = tk.Listbox(dlg, selectmode="extended", bg=PANEL, fg=TEXT, selectbackground=BLUE, relief="flat", font=(MONO, 10))
        lb.pack(fill="both", expand=True, padx=14)
        found = []

        def add_sel():
            existing = {p["host"] for p in self.profiles}
            for i in lb.curselection():
                r = found[i]
                if r["host"] not in existing:
                    self.profiles.append({"name": r["host"], "host": r["host"], "port": r["port"], "username": "admin",
                                          "ssl": False, "location": ""})
            self.save_profiles()
            self.refresh_profiles()
            dlg.destroy()
        self.button(dlg, "Add selected as devices", add_sel, True).pack(pady=10)

        def progress(i, n):
            self.post(lambda: info.winfo_exists() and info.configure(text=f"Scanning… {i}/{n}"))

        def done(res):
            found.extend(res)
            for r in res:
                lb.insert("end", f"{r['host']:<16} port {r['via']}")
            info.configure(text=f"{len(res)} host(s) with RouterOS ports found", fg=GREEN)
        self.run_async(lambda: Fleet.sweep(cidr, progress=progress), done, lambda e: info.configure(text=f"⚠ {e}", fg=RED))

    # -- quick actions -----------------------------------------------------------------
    def quick_action(self, kind):
        api = self.require()
        if not api:
            return
        stamp = time.strftime("%Y%m%d-%H%M")
        if kind == "export":
            name = simpledialog.askstring("Export Config", "File name (created on the router):", initialvalue=f"export-{stamp}", parent=self)
            work = lambda: api.command("/export", f"=file={name}")
        elif kind == "backup":
            name = simpledialog.askstring("Backup", "Backup name (created on the router):", initialvalue=f"backup-{stamp}", parent=self)
            work = lambda: api.command("/system/backup/save", f"=name={name}")
        elif kind == "restore":
            name = simpledialog.askstring("Restore", "Backup file on the router to restore (e.g. backup-20260101.backup):", parent=self)
            if name and not messagebox.askyesno("Restore", f"Restore '{name}'? The router will REBOOT and replace its configuration."):
                return
            work = lambda: api.command("/system/backup/load", f"=name={name}")
        else:
            name = "x"
            if not messagebox.askyesno("Reboot", "Reboot the router now?"):
                return
            work = lambda: api.command("/system/reboot")
        if not name:
            return

        def fail(e):
            if isinstance(e, ConnectionError):
                self.disconnect("Router closed the session (expected)")
            else:
                self.error(f"{kind} failed", e)
        self.run_async(work, lambda _r: messagebox.showinfo("Done", f"✔ {kind} command sent."), fail)

    # -- connection ------------------------------------------------------------
    def connect_dialog(self):
        p = self.current_profile()
        if not p:
            messagebox.showinfo("Choose a router", "Add or select a router profile first.")
            return
        if p.get("proto", "api") not in ("api", "api-ssl"):
            messagebox.showinfo("WinBox pages need the API", f"'{p['name']}' is set to {p.get('proto', '').upper()}.\n\n"
                                "The WinBox-style pages, live dashboard and terminal use the RouterOS API (8728 / 8729).\n"
                                "This device is still synced (clients, health, traffic) from the Router Sync page.\n"
                                "To use WinBox pages too, add the same router again with “API”.")
            return
        saved = self.get_router_password(p, ask=False)
        if saved is not None:
            self.connect_with(p, saved)
            return
        dlg = tk.Toplevel(self)
        dlg.title("Router credentials")
        dlg.configure(bg=BG)
        dlg.transient(self)
        dlg.resizable(False, False)
        tk.Label(dlg, text=f"Connect to {p['name']}  ({p['host']}:{p['port']}, user {p['username']})", bg=BG,
                 fg=CYAN, font=(FONT, 10, "bold")).grid(row=0, column=0, columnspan=2, padx=16, pady=(14, 6))
        tk.Label(dlg, text="Password", bg=BG, fg=MUTED, font=(FONT, 9)).grid(row=1, column=0, padx=16, pady=8, sticky="w")
        pw = self.entry(dlg, 26, show="•")
        pw.grid(row=1, column=1, padx=16, pady=8)

        def go(_e=None):
            password = pw.get()
            dlg.destroy()
            self.connect_with(p, password)
        self.button(dlg, "Connect", go, True).grid(row=3, column=0, columnspan=2, padx=16, pady=14, sticky="ew")
        pw.bind("<Return>", go)
        pw.focus_set()
        dlg.after(50, lambda: dlg.grab_set() if dlg.winfo_exists() else None)

    def connect_with(self, p, password):
        if self.connected:
            self.disconnect()
        self._set_status("CONNECTING", YELLOW)
        self.copy_lbl.configure(text=f"Connecting to {p['host']}:{p['port']} …")
        verify = bool(self.settings.get("verify_tls", False))
        threading.Thread(target=self._connect_worker, args=(dict(p), password, verify), daemon=True).start()

    def _connect_worker(self, p, password, verify):
        api = RouterAPI(p["host"], p["port"], p["username"], password, p.get("ssl", False), verify_tls=verify)
        try:
            api.connect()
            ident = api.command("/system/identity/print")
            self.post(lambda: self._connected(api, p, ident[0].get("name", p["name"]) if ident else p["name"]))
        except Exception as e:
            api.close()
            self.post(lambda: (self._set_status("DISCONNECTED", RED), self.copy_lbl.configure(text="Connection failed"),
                               messagebox.showerror("Router connection failed", str(e) or e.__class__.__name__)))

    def _connected(self, api, p, ident):
        self.api, self.connected, self.cur_profile = api, True, p
        self._set_status("CONNECTED", GREEN)
        self.user_lbl.configure(text=p["username"].capitalize())
        self.role_lbl.configure(text=f"{ident}")
        self.copy_lbl.configure(text=f"Connected to {ident} ({p['host']}:{p['port']})  |  password kept in memory only")
        self.telemetry.start(api)
        for w in self.windows:
            w.refresh_title()
        if self.active:
            self.active.on_show()
        self.on_fleet()

    def disconnect(self, note="Disconnected"):
        self.telemetry.stop()
        self.telemetry.reset()
        if self.api:
            self.api.close()
        self.api, self.connected, self.cur_profile = None, False, None
        self._set_status("DISCONNECTED", RED)
        self.user_lbl.configure(text="Admin")
        self.role_lbl.configure(text="Not connected")
        self.copy_lbl.configure(text=note)
        self.foot_r.configure(text="● API Disconnected", fg=RED)
        for pg in self.all_pages():
            if isinstance(pg, (StreamTool, GraphPage)):
                pg.stop()
        self.on_fleet()

    def _set_status(self, text, color):
        self.status.configure(text="● " + text, fg=color)

    def _bell(self):
        n = self.alerts.unread
        if n:
            self.badge.configure(text=str(min(n, 99)))
            self.badge.place(relx=.55, rely=.0)
        else:
            self.badge.place_forget()

    def _footer(self, d):
        if self.connected:
            self.foot_r.configure(text=f"● API Connected   |   RouterOS v{d.get('version', '').split(' ')[0]}   |   "
                                       f"Uptime: {d.get('uptime', '')}", fg=GREEN)

    def on_close(self):
        self.sync.stop()
        self.close_windows()
        self.disconnect()
        self.destroy()


from ui_kit import fmt_rate as rate  # noqa: E402

if __name__ == "__main__":
    App().mainloop()
