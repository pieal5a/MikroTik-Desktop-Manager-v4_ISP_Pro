"""Multi-router sync engine: every device (API / API-SSL / SSH / Telnet / SNMP) is polled in the background, its
PPP secrets / active sessions are merged into the client database, health numbers are kept for the Router Sync page,
and (optionally) overdue clients are suspended on the router."""
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import secret
from db import month_now
from transport import open_link, snmp_extras, NotSupported


class SyncManager:
    def __init__(self, app):
        self.app = app
        self.status = {}                       # profile name -> dict
        self.busy = set()
        self.pool = ThreadPoolExecutor(max_workers=6)
        self.stop_evt = threading.Event()
        self.last_round = 0

    # -- scheduling ---------------------------------------------------------------------------------------
    def start(self):
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        time.sleep(4)
        while not self.stop_evt.is_set():
            mins = max(float(self.app.settings.get("sync_minutes", 5)), 0.5)
            if self.app.settings.get("auto_sync", True) and self.app.auto:
                self.sync_all(auto=True)
                self._monthly_bills()
            self.stop_evt.wait(mins * 60)

    def _monthly_bills(self):
        if self.app.settings.get("auto_bills", True):
            try:
                if self.app.db.generate_bills(month_now()):
                    self.app.post(self.app.on_sync)
            except Exception:
                pass

    def stop(self):
        self.stop_evt.set()

    def sync_all(self, auto=False):
        n = 0
        for p in list(self.app.profiles):
            if auto and not p.get("auto_sync", True):
                continue
            if self.sync(p, auto=auto):
                n += 1
        return n

    def sync(self, p, password=None, import_new=True, auto=False):
        """Queue a sync. `password` overrides the saved one. Returns False if skipped."""
        name = p["name"]
        if name in self.busy:
            return False
        pw = password
        if pw is None and p.get("proto") != "snmp":
            if p.get("save_pw") or p.get("pw") is not None:
                pw = secret.unprotect(p.get("pw", ""))
            else:
                self.status[name] = dict(state="no-password", ts=time.time(), msg="No saved password — edit the device and tick “Save password”.", proto=p.get("proto", "api"))
                self.app.post(self.app.on_sync)
                return False
        self.busy.add(name)
        self.status.setdefault(name, {})["state"] = "syncing"
        self.app.post(self.app.on_sync)
        self.pool.submit(self._run, dict(p), pw, import_new, auto)
        return True

    # -- worker ---------------------------------------------------------------------------------------------
    def _run(self, p, pw, import_new, auto):
        name, app, db = p["name"], self.app, self.app.db
        prev = self.status.get(name, {}).get("state")
        link = None
        try:
            link = open_link(p, pw or "", verify_tls=bool(app.settings.get("verify_tls", False)))
            snap = link.snapshot()
            try:
                secrets = link.secrets()
            except NotSupported:
                secrets = None
            extras = {}
            try:
                extras = snmp_extras(p)
            except Exception as e:
                extras = dict(snmp_ok=False, snmp_err=str(e))
            active = {a["name"]: a for a in snap.get("ppp_active", []) if a.get("name")}
            stat = db.apply_router_state(name, secrets, active, import_new=import_new and secrets is not None)
            suspended = self._enforce(link, p, secrets) if secrets is not None and app.settings.get("auto_suspend") else 0
            snap.update(extras)
            snap.update(state="ok", ts=time.time(), proto=p.get("proto", "api"), stat=stat, msg=self._msg(stat, suspended, secrets),
                        auto_suspended=suspended, ppp_active_n=len(active))
            snap.pop("ifaces_raw", None)
            self.status[name] = snap
            if prev == "error":
                app.post(lambda: app.alerts.add("info", f"sync-ok:{name}", f"{name}: back online", 60))
            db.log("sync", f"{name} [{p.get('proto', 'api')}] new={stat['new']} online={stat['online']}")
        except Exception as e:
            self.status[name] = dict(state="error", ts=time.time(), msg=str(e) or e.__class__.__name__, proto=p.get("proto", "api"))
            if prev != "error":
                app.post(lambda e=e: app.alerts.add("critical", f"sync-err:{name}", f"{name}: sync failed — {e}", 600))
        finally:
            if link:
                try:
                    link.close()
                except Exception:
                    pass
            self.busy.discard(name)
            app.post(app.on_sync)

    @staticmethod
    def _msg(stat, suspended, secrets):
        if secrets is None:
            return f"online users {stat['online']} (SNMP: health & traffic only)"
        s = f"new {stat['new']} • changed {stat['updated']} • missing {stat['missing']} • online {stat['online']}"
        return s + (f" • auto-suspended {suspended}" if suspended else "")

    # -- auto suspend overdue ---------------------------------------------------------------------------------
    def overdue_ids(self, router):
        due_day, today = int(self.app.settings.get("due_day", 10)), time.localtime()
        cur = month_now()
        rows = self.app.db.q(
            "SELECT c.id, c.pppoe_id FROM clients c WHERE c.router=? AND c.status='active' AND c.on_router=1 AND EXISTS("
            "SELECT 1 FROM bills b WHERE b.client_id=c.id AND b.amount-b.discount-b.paid>0 AND (b.month<? OR (b.month=? AND ?>?)))",
            (router, cur, cur, today.tm_mday, due_day))
        return rows

    def _enforce(self, link, p, secrets):
        n = 0
        for c in self.overdue_ids(p["name"]):
            try:
                link.secret_enable(c["pppoe_id"], False)
                link.kick(c["pppoe_id"])
                self.app.db.set_status(c["id"], "suspended")
                self.app.db.log("auto-suspend", f"{c['pppoe_id']} on {p['name']}")
                n += 1
            except Exception:
                continue
        return n

    # -- one-off router operations (used by the Clients page) -----------------------------------------------------
    def with_link(self, p, password, fn):
        pw = password if password is not None else secret.unprotect(p.get("pw", ""))
        link = open_link(p, pw, verify_tls=bool(self.app.settings.get("verify_tls", False)))
        try:
            return fn(link)
        finally:
            link.close()
