"""One interface for every way a router can be reached: RouterOS API (8728) / API-SSL (8729), SSH (22),
Telnet (23) and SNMP (161).  `open_link(profile, password)` returns a Link with the same methods for all of them;
operations a protocol cannot do (e.g. SNMP cannot read PPP secrets) raise NotSupported."""
import re

import snmp as snmplib
from clitools import TelnetSession, SshSession, parse_terse, quote
from routeros_api import RouterAPI

PROTOS = {   # label -> (key, default port)
    "API (8728)": ("api", 8728), "API-SSL (8729)": ("api-ssl", 8729), "SSH (22)": ("ssh", 22),
    "Telnet (23)": ("telnet", 23), "SNMP (161)": ("snmp", 161)}
DEFAULT_PORT = {k: p for k, p in PROTOS.values()}
PROTO_LABEL = {k: lbl for lbl, (k, _p) in PROTOS.items()}
PHYS = ("ether", "wlan", "wifi", "lte", "sfp", "sfpplus", "wg", "bridge", "vlan", "bonding")


class NotSupported(Exception):
    pass


def _i(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return 0


def normalise(res, identity, ifs, active, total, board=""):
    """RouterOS-style dicts (API or parsed CLI) -> common snapshot."""
    tm, fm = _i(res.get("total-memory")), _i(res.get("free-memory"))
    td, fd = _i(res.get("total-hdd-space")), _i(res.get("free-hdd-space"))
    return dict(identity=identity, version=res.get("version", ""), board=board or res.get("board-name", ""),
                uptime=res.get("uptime", ""), cpu=_i(res.get("cpu-load")),
                mem_pct=(tm - fm) * 100 / tm if tm else 0, disk_pct=(td - fd) * 100 / td if td else 0,
                ifaces=[dict(name=r.get("name", ""), type=r.get("type", ""), running=r.get("running") == "true",
                             disabled=r.get("disabled") == "true", rxb=_i(r.get("rx-byte")), txb=_i(r.get("tx-byte")))
                        for r in ifs if r.get("dynamic") != "true" or r.get("type") in PHYS],
                ppp_active=[dict(name=r.get("name", ""), address=r.get("address", ""), uptime=r.get("uptime", ""),
                                 caller=r.get("caller-id", "")) for r in active],
                ppp_total=total, temp=None, volt=None)


class Link:
    kind = "?"
    def snapshot(self): raise NotImplementedError
    def secrets(self): raise NotSupported(f"{self.kind.upper()} cannot read PPP secrets — use API, SSH or Telnet.")
    def profiles(self): raise NotSupported(f"{self.kind.upper()} cannot read PPP profiles.")
    def secret_add(self, name, password, profile="", comment="", service="pppoe"): raise NotSupported(self.kind)
    def secret_set(self, name, **kw): raise NotSupported(self.kind)
    def secret_remove(self, name): raise NotSupported(self.kind)
    def secret_enable(self, name, enable): raise NotSupported(self.kind)
    def kick(self, name): raise NotSupported(self.kind)
    def close(self): pass


# ---------------------------------------------------------------------------------------------------------
class ApiLink(Link):
    kind = "api"

    def __init__(self, api):
        self.api = api

    def _id(self, name):
        rows = self.api.command("/ppp/secret/print", "=.proplist=.id", f"?name={name}")
        if not rows:
            raise LookupError(f"PPP secret '{name}' not found on router")
        return rows[0][".id"]

    def snapshot(self):
        a = self.api
        res = (a.command("/system/resource/print") or [{}])[0]
        ident = ((a.command("/system/identity/print") or [{}])[0]).get("name", "")
        ifs = a.command("/interface/print", "=.proplist=name,type,running,disabled,rx-byte,tx-byte,dynamic")
        act = a.command("/ppp/active/print", "=.proplist=name,address,uptime,caller-id")
        total = len(a.command("/ppp/secret/print", "=.proplist=.id"))
        try:
            board = ((a.command("/system/routerboard/print") or [{}])[0]).get("model", "")
        except Exception:
            board = ""
        return normalise(res, ident, ifs, act, total, board)

    def secrets(self):
        return self.api.command("/ppp/secret/print")

    def profiles(self):
        return self.api.command("/ppp/profile/print", "=.proplist=name,rate-limit")

    def secret_add(self, name, password, profile="", comment="", service="pppoe"):
        args = [f"=name={name}", f"=password={password}", f"=service={service}"]
        if profile:
            args.append(f"=profile={profile}")
        if comment:
            args.append(f"=comment={comment}")
        self.api.command("/ppp/secret/add", *args)

    def secret_set(self, name, **kw):
        self.api.command("/ppp/secret/set", f"=.id={self._id(name)}", *[f"={k}={v}" for k, v in kw.items()])

    def secret_remove(self, name):
        self.api.command("/ppp/secret/remove", f"=.id={self._id(name)}")

    def secret_enable(self, name, enable):
        self.api.command("/ppp/secret/" + ("enable" if enable else "disable"), f"=.id={self._id(name)}")

    def kick(self, name):
        for r in self.api.command("/ppp/active/print", "=.proplist=.id", f"?name={name}"):
            self.api.command("/ppp/active/remove", f"=.id={r['.id']}")

    def close(self):
        self.api.close()


class CliLink(Link):
    """Telnet / SSH: drive the RouterOS console and parse `print terse`."""

    def __init__(self, sess, kind):
        self.s, self.kind = sess, kind

    def _terse(self, cmd):
        return parse_terse(self.s.run(f"{cmd} terse without-paging"))

    def _single(self, cmd):
        rows = self._terse(cmd)
        if rows:
            return rows[0]
        d = {}
        for ln in self.s.run(f"{cmd} without-paging").splitlines():
            k, sep, v = ln.partition(":")
            if sep:
                d[k.strip()] = v.strip()
        return d

    def snapshot(self):
        res = self._single("/system resource print")
        ident = self._single("/system identity print").get("name", "")
        ifs = self._terse("/interface print stats")
        act = self._terse("/ppp active print")
        total = len(self._terse("/ppp secret print"))
        return normalise(res, ident, ifs, act, total)

    def secrets(self):
        return self._terse("/ppp secret print")

    def profiles(self):
        return self._terse("/ppp profile print")

    def _run(self, cmd):
        out = self.s.run(cmd)
        if re.search(r"failure:|bad command|syntax error|expected end of command|no such item", out, re.I):
            raise RuntimeError(out.strip().splitlines()[-1])
        return out

    def secret_add(self, name, password, profile="", comment="", service="pppoe"):
        cmd = f"/ppp secret add name={quote(name)} password={quote(password)} service={service}"
        if profile:
            cmd += f" profile={quote(profile)}"
        if comment:
            cmd += f" comment={quote(comment)}"
        self._run(cmd)

    def secret_set(self, name, **kw):
        sets = " ".join(f"{k}={quote(v)}" for k, v in kw.items())
        self._run(f"/ppp secret set [find name={quote(name)}] {sets}")

    def secret_remove(self, name):
        self._run(f"/ppp secret remove [find name={quote(name)}]")

    def secret_enable(self, name, enable):
        self._run(f"/ppp secret {'enable' if enable else 'disable'} [find name={quote(name)}]")

    def kick(self, name):
        self._run(f"/ppp active remove [find name={quote(name)}]")

    def close(self):
        self.s.close()


class SnmpLink(Link):
    kind = "snmp"

    def __init__(self, p):
        self.p = p

    def snapshot(self):
        p = self.p
        d = snmplib.collect(p["host"], p.get("snmp_community", "public"), p.get("port", 161), p.get("snmp_version", "2c"))
        d["ppp_total"] = len(d.get("ppp_active", []))
        return d


# ---------------------------------------------------------------------------------------------------------
def open_link(p, password, verify_tls=False, timeout=8):
    proto = p.get("proto", "ssl" if p.get("ssl") else "api")
    if proto == "ssl":
        proto = "api-ssl"
    host, port = p["host"], int(p.get("port") or DEFAULT_PORT.get(proto, 8728))
    if proto in ("api", "api-ssl"):
        api = RouterAPI(host, port, p["username"], password, proto == "api-ssl", timeout=timeout, verify_tls=verify_tls)
        api.connect()
        return ApiLink(api)
    if proto == "ssh":
        s = SshSession(host, port, p["username"], password, timeout)
        s.connect()
        return CliLink(s, "ssh")
    if proto == "telnet":
        s = TelnetSession(host, port, p["username"], password, timeout)
        s.connect()
        return CliLink(s, "telnet")
    if proto == "snmp":
        return SnmpLink(p)
    raise ValueError(f"Unknown protocol {proto!r}")


def snmp_extras(p, timeout=2.0):
    """Optional SNMP companion for API/SSH/Telnet devices: temperature, voltage, per-user PPPoE counters."""
    comm = p.get("snmp_community")
    if not comm:
        return {}
    d = snmplib.collect(p["host"], comm, p.get("snmp_port", 161), p.get("snmp_version", "2c"), timeout)
    return dict(temp=d.get("temp"), volt=d.get("volt"), snmp_pppoe=d.get("ppp_active", []), snmp_ok=True)
